import { Component } from '@angular/core';
import { TenantDTO } from '../models/tenant.model';
import { NotificationService } from '../services/notification';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { TenantService } from '../services/tenant-service';
import { CommonModule } from '@angular/common';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { ErrorInfo } from '../services/error-handler.service';
import { LoadingService } from '../services/loading.service';

@Component({
  selector: 'app-tenant-list',
  imports: [CommonModule, FormsModule],
  templateUrl: './tenant-list.html',
  styleUrl: './tenant-list.css'
})
export class TenantList {
  tenants: TenantDTO[] = [];
  loading = true;
  error = '';

  // Pagination
  itemsPerPage = 10;
  currentPage = 1;
  paginatedTenants: TenantDTO[] = [];

  showForm = false;
  formMode: 'create' | 'edit' = 'create';
  selectedTenant: TenantDTO | null = null;

  constructor(
    private tenantService: TenantService, 
    private tenantSelectionService: TenantSelectionService,
    private router: Router,
    private notification: NotificationService,
    private loadingService: LoadingService
  ) { }

  ngOnInit(): void {
    this.reload();
  }


  reload(): void {
    this.loading = true;
    this.loadingService.show();
    
    this.tenantService.getAllTenants().subscribe({
      next: (rows) => {
        this.tenants = rows;
        this.currentPage = 1;
        this.updatePaginatedTenants();
        this.loading = false;
        this.loadingService.hide();
      },
      error: (errorInfo: ErrorInfo) => {
        this.error = errorInfo.message;
        this.loading = false;
        this.loadingService.hide();
        this.notification.showError(errorInfo.message);
      }
    });
  }

  updatePaginatedTenants(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedTenants = this.tenants.slice(startIndex, endIndex);
  }

  onPageChange(page: number): void {
    const maxPage = Math.ceil(this.tenants.length / this.itemsPerPage);
    if (page >= 1 && page <= maxPage) {
      this.currentPage = page;
      this.updatePaginatedTenants();
    }
  }

  goToFirstPage(): void {
    this.onPageChange(1);
  }

  goToLastPage(): void {
    const maxPage = Math.ceil(this.tenants.length / this.itemsPerPage);
    this.onPageChange(maxPage);
  }

  goToPreviousPage(): void {
    this.onPageChange(this.currentPage - 1);
  }

  goToNextPage(): void {
    this.onPageChange(this.currentPage + 1);
  }

  get totalPages(): number {
    return Math.ceil(this.tenants.length / this.itemsPerPage);
  }

  get startItem(): number {
    return this.tenants.length === 0 ? 0 : (this.currentPage - 1) * this.itemsPerPage + 1;
  }

  get endItem(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.tenants.length);
  }

  onAddTenant(): void {
    this.tenantSelectionService.clearTenant(); 
    this.router.navigate(['/tenant/add']); 
  }

  onEdit(tenant: TenantDTO): void {
    this.tenantSelectionService.setTenant(tenant); 
    this.router.navigate([`/tenant/${tenant.id}`]); 
  }


}
