export const environment = {
  production: false,
  keycloak: {
    url: 'https://convozoom.com:8443/auth',
    realm: 'master',
    clientId: 'convo-front-clientid'
  }
};
