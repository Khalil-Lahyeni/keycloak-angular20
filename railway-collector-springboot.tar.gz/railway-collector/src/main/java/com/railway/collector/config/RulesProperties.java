package com.railway.collector.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "rules")
public class RulesProperties {

    private int heartbeatTimeoutSeconds = 60;

    private List<String> criticalStatuses = List.of("error", "nok");

    private List<String> knownPacisStatuses = List.of("ok", "error", "degraded", "unknown");

    private List<String> knownCctvStatuses = List.of("ok", "partially_ok", "nok", "unknown");

    private int fleetOverviewIntervalSeconds = 10;
}
