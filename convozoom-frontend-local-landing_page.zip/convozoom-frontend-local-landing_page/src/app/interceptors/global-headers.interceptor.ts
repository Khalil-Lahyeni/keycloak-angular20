import { HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { from } from 'rxjs';
import { mergeMap } from 'rxjs/operators';
import { AuthService } from '../auth/auth.service';
import { AppConfigService } from '../config/app-config.service';
import { TenantSelectionService } from '../services/tenant-selection-service';

/**
 * Global HTTP Headers Interceptor
 * 
 * Automatically injects authentication and tenant headers into all HTTP requests.
 * This eliminates the need for manual header injection in individual services.
 * 
 * Headers added:
 * - Authorization: Bearer token from Keycloak
 * - X-User: Current username
 * - X-Tenant: Tenant code
 * - X-Tenant-Id: Tenant ID
 */
export const globalHeadersInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const appConfigService = inject(AppConfigService);
  const tenantSelectionService = inject(TenantSelectionService);

  // Get tenant information
  const selected = tenantSelectionService.selectedTenant?.();
  const tenantId = selected?.id || tenantSelectionService.getTenantId();
  
  let tenantCode = selected?.code || tenantSelectionService.getTenantCode();
  appConfigService.getKeycloakRealm().subscribe(realm => {
    if (realm && realm === 'convo-trial') {
      tenantCode = realm;
    }
  });
  
  // Get username (synchronously from cached profile if available)
  let username = '';
  try {
    const profile = authService.getUserProfile?.();
    if (profile && typeof profile === 'object' && 'username' in profile) {
      username = (profile as any).username || '';
    }
  } catch {
    // Username not available yet, continue without it
  }

  // Get token asynchronously and check authentication
  return from(Promise.all([authService.isAuthenticated(), authService.getToken()])).pipe(
    mergeMap(([isAuth, token]) => {
      const finalReq = isAuth
        ? req.clone({
            setHeaders: {
              'Authorization': token ? `Bearer ${token}` : '',
              'X-User': username,
              'X-Tenant': tenantCode,
              'X-Tenant-Id': tenantId
            }
          })
        : req;

      return next(finalReq);
    })
  );
};

