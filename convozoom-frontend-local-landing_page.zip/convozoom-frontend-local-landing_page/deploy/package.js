#!/usr/bin/env node

/**
 * Package Script
 * Creates a deployment package after building
 */

const fs = require('fs');
const path = require('path');

function createPackage() {
  const packageDir = 'deploy-package';
  
  // Remove existing package directory
  if (fs.existsSync(packageDir)) {
    fs.rmSync(packageDir, { recursive: true, force: true });
  }
  
  // Create package directory
  fs.mkdirSync(packageDir, { recursive: true });
  
  // Copy built application
  const distDir = 'dist/convozoom-front';
  if (fs.existsSync(distDir)) {
    copyDir(distDir, packageDir);
  } else {
    console.error('Build directory not found. Please run build first.');
    process.exit(1);
  }
  
  // Copy the inject-env.sh script to the package root
  const injectScriptSrc = path.join('deploy', 'inject-env.sh');
  const injectScriptDest = path.join(packageDir, 'inject-env.sh');
  if (fs.existsSync(injectScriptSrc)) {
    fs.copyFileSync(injectScriptSrc, injectScriptDest);
    console.log('Copied inject-env.sh to package');
  }
  
  // Copy deployment files
  const deployFiles = [
    'env.example',
    'nginx.conf',
    'docker-compose.yml',
    'Dockerfile.serve'
  ];
  
  deployFiles.forEach(file => {
    const srcPath = path.join('deploy', file);
    const destPath = path.join(packageDir, file);
    
    if (fs.existsSync(srcPath)) {
      fs.copyFileSync(srcPath, destPath);
      console.log(`Copied ${file} to package`);
    }
  });
  
  // Create README
  const readmeContent = `# ConvoZoom Frontend Deployment Package

This package contains a production-ready build of the ConvoZoom frontend.

## Quick Start

1. Copy \`env.example\` to \`.env\` and configure your environment variables:
   - KEYCLOAK_URL: Your Keycloak server URL
   - KEYCLOAK_REALM: Your Keycloak realm
   - KEYCLOAK_CLIENT_ID: Your Keycloak client ID
   - API_BASE_URL: Your backend API URL

2. For Docker deployment:
   \`\`\`bash
   docker-compose up -d
   \`\`\`

3. For manual deployment:
   - Serve the files using any web server (nginx, Apache, etc.)
   - Make sure to serve the \`config-injector.js\` file from \`/assets/\`

## Configuration

The application uses runtime configuration injection. The \`config-injector.js\`
file in the assets folder contains the environment-specific configuration.

## Environment Variables

- KEYCLOAK_URL: Keycloak server URL
- KEYCLOAK_REALM: Keycloak realm name
- KEYCLOAK_CLIENT_ID: Keycloak client ID
- API_BASE_URL: Backend API base URL
- ENVIRONMENT: Environment name (production, staging, etc.)
- DEBUG_MODE: Enable debug mode (true/false)
`;
  
  fs.writeFileSync(path.join(packageDir, 'README.md'), readmeContent);
  
  console.log('\\nDeployment package created successfully!');
  console.log('Location: deploy-package/');
  console.log('\\nNext steps:');
  console.log('1. Copy the deploy-package folder to your server');
  console.log('2. Configure the .env file with your environment settings');
  console.log('3. Deploy using Docker or your preferred web server');
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }
  
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

createPackage();
