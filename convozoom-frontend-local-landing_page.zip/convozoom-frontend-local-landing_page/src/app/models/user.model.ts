export interface UserDTO {
  id?: string;
  email: string;
  firstname: string;
  lastname: string;
  language?: string;
  tenantId?: string;
  tenantName?: string;
}


