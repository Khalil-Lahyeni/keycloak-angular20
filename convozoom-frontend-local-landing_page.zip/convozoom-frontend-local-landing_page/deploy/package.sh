#!/bin/bash

# Production Package Script for Linux/Mac
# This script creates a production-ready deployment package

set -e

echo "Creating production deployment package..."

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "Error: .env file not found!"
    echo "Please copy deploy/.env.example to .env and configure your settings."
    exit 1
fi

# Load environment variables from .env file
export $(grep -v '^#' .env | xargs)

# Build the application
echo "Building Angular application..."
npm run build:prod

# Inject configuration
echo "Injecting configuration..."
node deploy/build.js

# Create deployment package
echo "Creating deployment package..."
rm -rf deploy-package
mkdir -p deploy-package

# Copy built application
cp -r dist/convozoom-front/* deploy-package/

# Copy deployment files
cp deploy/.env.example deploy-package/
cp deploy/nginx.conf deploy-package/
cp deploy/docker-compose.yml deploy-package/
cp deploy/Dockerfile.serve deploy-package/

# Create README for deployment
cat > deploy-package/README.md << 'EOF'
# ConvoZoom Frontend Deployment Package

This package contains a production-ready build of the ConvoZoom frontend.

## Quick Start

1. Copy `.env.example` to `.env` and configure your environment variables:
   - KEYCLOAK_URL: Your Keycloak server URL
   - KEYCLOAK_REALM: Your Keycloak realm
   - KEYCLOAK_CLIENT_ID: Your Keycloak client ID
   - API_BASE_URL: Your backend API URL

2. For Docker deployment:
   ```bash
   docker-compose up -d
   ```

3. For manual deployment:
   - Serve the files using any web server (nginx, Apache, etc.)
   - Make sure to serve the `config-injector.js` file from `/assets/`

## Configuration

The application uses runtime configuration injection. The `config-injector.js`
file in the assets folder contains the environment-specific configuration.

## Environment Variables

- KEYCLOAK_URL: Keycloak server URL
- KEYCLOAK_REALM: Keycloak realm name
- KEYCLOAK_CLIENT_ID: Keycloak client ID
- API_BASE_URL: Backend API base URL
- ENVIRONMENT: Environment name (production, staging, etc.)
- DEBUG_MODE: Enable debug mode (true/false)
EOF

echo ""
echo "Deployment package created successfully!"
echo "Location: deploy-package/"
echo ""
echo "Next steps:"
echo "1. Copy the deploy-package folder to your server"
echo "2. Configure the .env file with your environment settings"
echo "3. Deploy using Docker or your preferred web server"
echo ""
