package com.railway.collector.service.normalizer;

import com.railway.collector.config.RulesProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Couche 2 — Normalisation & Validation.
 * Valide les schémas, normalise timestamps, statuts et IPs.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class NormalizerService {

    private final RulesProperties rulesProperties;

    private static final Pattern IP_PATTERN =
            Pattern.compile("^((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$");

    // ─── Timestamp ───

    public String normalizeTimestamp(String isoTimestamp) {
        if (isoTimestamp == null || isoTimestamp.isBlank()) {
            return Instant.now().toString();
        }
        try {
            return Instant.parse(isoTimestamp).toString();
        } catch (DateTimeParseException e) {
            log.warn("Invalid timestamp '{}', using current time", isoTimestamp);
            return Instant.now().toString();
        }
    }

    // ─── Status ───

    public String normalizeStatus(String value, List<String> knownValues) {
        if (value == null || value.isBlank()) {
            return "unknown";
        }
        String normalized = value.trim().toLowerCase();
        if (!knownValues.contains(normalized)) {
            log.info("Unknown status value '{}', mapping to 'unknown'", value);
            return "unknown";
        }
        return normalized;
    }

    // ─── IP Address ───

    public String normalizeIp(String ip) {
        if (ip == null || ip.isBlank()) {
            return null;
        }
        String trimmed = ip.trim();
        if (IP_PATTERN.matcher(trimmed).matches()) {
            return trimmed;
        }
        log.warn("Invalid IP address: {}", ip);
        return null;
    }

    // ─── Normalize Train Status ───

    public Map<String, Object> normalizeStatus(Map<String, Object> data) {
        data.put("lastSeen", normalizeTimestamp((String) data.get("lastSeen")));

        data.put("pacisStatus", normalizeStatus(
                (String) data.get("pacisStatus"),
                rulesProperties.getKnownPacisStatuses()));

        data.put("cctvStatus", normalizeStatus(
                (String) data.get("cctvStatus"),
                rulesProperties.getKnownCctvStatuses()));

        data.put("rearViewStatus", normalizeStatus(
                (String) data.get("rearViewStatus"),
                List.of("ok", "nok", "unknown")));

        data.put("_normalizedAt", Instant.now().toString());
        return data;
    }

    // ─── Normalize Configuration ───

    public Map<String, Object> normalizeConfiguration(Map<String, Object> data) {
        data.put("ccu1Ip", normalizeIp((String) data.get("ccu1Ip")));
        data.put("ccu2Ip", normalizeIp((String) data.get("ccu2Ip")));
        data.put("visible", Boolean.TRUE.equals(data.get("visible")));
        data.put("_normalizedAt", Instant.now().toString());
        return data;
    }

    // ─── Normalize Media Database ───

    @SuppressWarnings("unchecked")
    public Map<String, Object> normalizeMediaDatabase(Map<String, Object> data) {
        List<Map<String, Object>> versions =
                (List<Map<String, Object>>) data.get("versions");
        if (versions != null) {
            for (Map<String, Object> v : versions) {
                v.put("activation_date",
                        normalizeTimestamp((String) v.get("activation_date")));
            }
        }
        data.put("_normalizedAt", Instant.now().toString());
        return data;
    }

    // ─── Normalize Message ───

    public Map<String, Object> normalizeMessage(Map<String, Object> data) {
        String type = (String) data.get("messageType");
        data.put("messageType", type != null ? type.trim().toUpperCase() : "UNKNOWN");
        data.put("_normalizedAt", Instant.now().toString());
        return data;
    }
}
