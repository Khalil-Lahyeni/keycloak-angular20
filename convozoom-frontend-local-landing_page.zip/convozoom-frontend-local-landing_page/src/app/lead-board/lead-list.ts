import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Lead, LeadStatus } from '../models/lead.model';
import { LeadService } from '../services/lead-service';
import { UserService } from '../services/user-service';
import { UserDTO } from '../models/user.model';
import { AuthService } from '../auth/auth.service';


export interface HistoryItem {
  type: 'created' | 'modified';
  performedBy: string;
  date: string;
  icon: string;
}

export interface ConversationMessage {
  id: string;
  sender: string;
  content: string;
  type: 'user' | 'assistant';
  timestamp?: string;
}
  // Precomputed GMT offsets from -12 to +14 (no city names)
const GMT_OFFSETS: string[] = Array.from({ length: 27 }, (_v, i) => {
  const offset = -12 + i; // -12, -11, ..., +14
  const sign = offset >= 0 ? '+' : '-';
  const hours = Math.abs(offset).toString().padStart(2, '0');
  return `GMT${sign}${hours}:00`;
});

@Component({
  selector: 'app-lead-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './lead-list.html',
  styleUrls: ['./lead-list.css']
})


export class LeadList implements OnInit, OnChanges {
  @Input() groupedLeads: { key: string, items: Lead[] }[] = [];
  @Input() leads: Lead[] = [];
  @Input() query = '';
  @Output() openLead = new EventEmitter<string>();

  protected readonly LeadStatus = LeadStatus;

  @Input() sortBy: 'Updated' | 'Created' | 'Name' | 'Status' = 'Updated';
  @Input() groupBy: 'Status' | 'Source' | null = null;

  // Track which groups are expanded
  expandedGroups = new Set<string>();


  
  // Drawer state
  isDrawerOpen = false;
  selectedLead: Lead | null = null;
  drawerActiveTab: 'Summary' | 'Conversation' | 'History' = 'Summary';
  isDrawerFullscreen = false;
  // Local inputs for name parts mapped to fullName
  firstNameInput: string = '';
  lastNameInput: string = '';

  // Form change tracking
  hasFormChanges = false;
  originalLeadData: any = null;
  showUnsavedChangesModal = false;
  pendingAction: (() => void) | null = null;

  // Dropdown states
  isTagDropdownOpen = false;
  isStatusDropdownOpen = false;
  isAssigneeDropdownOpen = false;
  isSourceDropdownOpen = false;
  isTimezoneDropdownOpen = false;
  timezoneSearchQuery = '';
  
  // Dropdown options
  tagOptions: string[] = [];
  statusOptions = [LeadStatus.NEW, LeadStatus.CONTACTED, LeadStatus.QUALIFIED, LeadStatus.CONVERTED];
  assigneeOptions: UserDTO[] = [];
  sourceOptions: string[] = [];
  timezoneOptions: string[] = GMT_OFFSETS;

  private assigneeTenantId: string | null = null;
  currentUserEmail: string = '';
  isEmailMatched: boolean = false;

  

  constructor(
    private leadService: LeadService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  get filtered(): Lead[] {
    const q = (this.query || '').toLowerCase().trim();
    if (!q) return this.leads;
    return this.leads.filter(l =>
      (l.fullName || '').toLowerCase().includes(q) ||
      (l.company || '').toLowerCase().includes(q) ||
      (l.email || '').toLowerCase().includes(q) ||
      (l.source || '').toLowerCase().includes(q) ||
      (l.assignedTo || '').toLowerCase().includes(q)
    );
  }

  ngOnInit() {
    this.loadCurrentUserEmail();

    // Initialize all groups as expanded
    if (this.groupBy) {
      this.grouped.forEach(g => this.expandedGroups.add(g.key));
    }

    // Preload assignees for the first tenant if available
    const tenantId = this.leads?.[0]?.tenantId;
    if (tenantId) {
      this.loadAssignees(tenantId);
    }
  }

  private checkEmailMatch() {
    if (!this.selectedLead || !this.currentUserEmail) {
      this.isEmailMatched = false;
      return;
    }

    // If no assignee or "Unassigned", allow editing
    const assignedToName = this.selectedLead.assignedTo || '';
    if (!assignedToName || assignedToName === 'Unassigned') {
      this.isEmailMatched = true;
      return;
    }

    const matchingUser = this.assigneeOptions.find(u =>
      `${u.firstname} ${u.lastname}`.trim() === assignedToName
    );

    if (matchingUser && matchingUser.email) {
      this.isEmailMatched = matchingUser.email.toLowerCase() === this.currentUserEmail.toLowerCase();
    } else {
      // If can't find user, allow editing
      this.isEmailMatched = true;
    }
  }

  trackById(_idx: number, item: Lead) {
    return item.id || _idx;
  }

  onRowClick(lead?: Lead) {
    if (lead) {
      if (this.hasFormChanges && this.selectedLead) {
        // Show confirmation modal before switching leads
        this.pendingAction = () => {
          this.selectedLead = lead;
          this.isDrawerOpen = true;
          this.hasFormChanges = false;
          this.originalLeadData = { ...lead };
        };
        this.showUnsavedChangesModal = true;
      } else {
        this.selectedLead = lead;
        this.isDrawerOpen = true;
        this.hasFormChanges = false;
        this.originalLeadData = { ...lead };
        // Initialize local name inputs from fullName
        const { firstName, lastName } = this.splitFullName(lead.fullName || '');
        this.firstNameInput = firstName;
        this.lastNameInput = lastName;
        this.loadAssignees(lead.tenantId);
        this.checkEmailMatch();
      }
    }
  }

  closeDrawer() {
    if (this.hasFormChanges) {
      // Show confirmation modal before closing
      this.pendingAction = () => {
        this.isDrawerOpen = false;
        this.selectedLead = null;
        this.hasFormChanges = false;
        this.originalLeadData = null;
      };
      this.showUnsavedChangesModal = true;
    } else {
      this.isDrawerOpen = false;
      this.selectedLead = null;
      this.hasFormChanges = false;
      this.originalLeadData = null;
      this.firstNameInput = '';
      this.lastNameInput = '';
    }
  }

  setDrawerTab(tab: 'Summary' | 'Conversation' | 'History') {
    if (this.hasFormChanges && tab !== this.drawerActiveTab && tab !== 'Summary') {
      // Show confirmation modal before switching tabs
      this.pendingAction = () => {
        this.drawerActiveTab = tab;
      };
      this.showUnsavedChangesModal = true;
    } else {
      this.drawerActiveTab = tab;
    }
  }

  toggleDrawerFullscreen() {
    this.isDrawerFullscreen = !this.isDrawerFullscreen;
  }

  // Track form changes
  onFormChange() {
    this.hasFormChanges = true;
  }

  // Recommended approach: explicit setters to mutate selectedLead
  setStatus(status: LeadStatus | string) {
    if (!this.selectedLead) return;
    const newStatus = typeof status === 'string' ? (status as LeadStatus) : status;
    if (this.selectedLead.status !== newStatus) {
      this.selectedLead = { ...this.selectedLead, status: newStatus };
      this.onFormChange();
    }
  }

  setAssignee(assignee: UserDTO | null) {
    if (!this.selectedLead) return;
    const displayName = assignee ? `${assignee.firstname || ''} ${assignee.lastname || ''}`.trim() : '';
    if ((this.selectedLead.assignedTo || '') !== (displayName || '')) {
      this.selectedLead = { ...this.selectedLead, assignedTo: displayName || undefined };
      this.onFormChange();
    }
  }

  setSource(source: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.source || '') !== (source || '')) {
      this.selectedLead = { ...this.selectedLead, source };
      this.onFormChange();
    }
  }

  setTags(tags: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.tags || '') !== (tags || '')) {
      this.selectedLead = { ...this.selectedLead, tags };
      this.onFormChange();
    }
  }

  setFullName(fullName: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.fullName || '') !== (fullName || '')) {
      this.selectedLead = { ...this.selectedLead, fullName };
      this.onFormChange();
    }
  }

  // Helper: split and compose fullName for first/last name inputs
  private splitFullName(fullName: string): { firstName: string; lastName: string } {
    const parts = (fullName || '').trim().split(/\s+/);
    if (parts.length === 0) return { firstName: '', lastName: '' };
    if (parts.length === 1) return { firstName: parts[0], lastName: '' };
    return { firstName: parts[0], lastName: parts.slice(1).join(' ') };
  }

  setFirstNameInput(val: string) {
    this.firstNameInput = val || '';
    const fullName = `${this.firstNameInput} ${this.lastNameInput}`.trim();
    this.setFullName(fullName);
  }

  setLastNameInput(val: string) {
    this.lastNameInput = val || '';
    const fullName = `${this.firstNameInput} ${this.lastNameInput}`.trim();
    this.setFullName(fullName);
  }

  setEmail(email: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.email || '') !== (email || '')) {
      this.selectedLead = { ...this.selectedLead, email };
      this.onFormChange();
    }
  }

  setCompany(company: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.company || '') !== (company || '')) {
      this.selectedLead = { ...this.selectedLead, company };
      this.onFormChange();
    }
  }

  setCustomFields(customFields: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.customFields || '') !== (customFields || '')) {
      this.selectedLead = { ...this.selectedLead, customFields };
      this.onFormChange();
    }
  }

  // Update lead data
  onUpdateLead() {
    if (!this.hasFormChanges || !this.selectedLead || !this.selectedLead.id) return;

    this.leadService.updateLead(this.selectedLead.id, this.selectedLead).subscribe({
      next: (updatedLead) => {
        // Update drawer state
        this.selectedLead = { ...updatedLead };
        this.hasFormChanges = false;
        this.originalLeadData = { ...updatedLead };

        // Persist changes in local list (input array) so UI reflects updates
        const idx = this.leads.findIndex(l => l.id === updatedLead.id);
        if (idx !== -1) {
          // Replace item to trigger change detection
          this.leads[idx] = { ...updatedLead } as Lead;
          // Also recreate array reference to ensure parent detects change
          this.leads = [...this.leads];
        }
      },
      error: (err) => {
        console.error('Error updating lead:', err);
      }
    });
  }

  // Confirmation modal actions
  confirmUnsavedChanges() {
    this.showUnsavedChangesModal = false;
    this.hasFormChanges = false;
    if (this.pendingAction) {
      this.pendingAction();
      this.pendingAction = null;
    }
  }

  cancelUnsavedChanges() {
    this.showUnsavedChangesModal = false;
    this.pendingAction = null;
  }

  saveAndContinue() {
    this.onUpdateLead();
    this.showUnsavedChangesModal = false;
    if (this.pendingAction) {
      this.pendingAction();
      this.pendingAction = null;
    }
  }

  toggleDropdown(dropdown: string) {
    switch (dropdown) {
      case 'tag': this.isTagDropdownOpen = !this.isTagDropdownOpen; break;
      case 'status': this.isStatusDropdownOpen = !this.isStatusDropdownOpen; break;
      case 'assignee': this.isAssigneeDropdownOpen = !this.isAssigneeDropdownOpen; break;
      case 'source': this.isSourceDropdownOpen = !this.isSourceDropdownOpen; break;
      case 'timezone': 
        this.isTimezoneDropdownOpen = !this.isTimezoneDropdownOpen;
        if (!this.isTimezoneDropdownOpen) this.timezoneSearchQuery = '';
        break;
    }
  }

  closeAllDropdowns() {
    this.isTagDropdownOpen = false;
    this.isStatusDropdownOpen = false;
    this.isAssigneeDropdownOpen = false;
    this.isSourceDropdownOpen = false;
    this.isTimezoneDropdownOpen = false;
    this.timezoneSearchQuery = '';
  }

  // Timezone methods
  get filteredTimezones(): string[] {
    if (!this.timezoneSearchQuery) return this.timezoneOptions.slice(0, 50);
    const query = this.timezoneSearchQuery.toLowerCase();
    return this.timezoneOptions.filter(tz => tz.toLowerCase().includes(query)).slice(0, 50);
  }

  setTimezone(timezone: string) {
    if (!this.selectedLead) return;
    if ((this.selectedLead.timezone || '') !== timezone) {
      this.selectedLead = { ...this.selectedLead, timezone };
      this.onFormChange();
    }
  }

  getRelativeDate(dateString: string): { time: string; date: string } {
    const date = new Date(dateString);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const leadDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    const time = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

    let dateLabel: string;
    if (leadDate.getTime() === today.getTime()) {
      dateLabel = 'today';
    } else if (leadDate.getTime() === yesterday.getTime()) {
      dateLabel = 'yesterday';
    } else {
      dateLabel = date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    return { time, date: dateLabel };
  }



  // Map lead status to PatternFly label color classes
  getStatusClass(status: LeadStatus | string): string {
    const statusStr = typeof status === 'string' ? status : status;
    switch (statusStr) {
      case LeadStatus.NEW:
      case 'New':
        return 'pf-m-blue';
      case LeadStatus.CONTACTED:
      case 'Contacted':
        return 'pf-m-orange';
      case LeadStatus.QUALIFIED:
      case 'Qualified':
        return 'pf-m-purple';
      case LeadStatus.CONVERTED:
      case 'Converted':
        return 'pf-m-green';
      default:
        return '';
    }
  }

  // Sorted list based on selected sortBy option
  get sorted(): Lead[] {
    const items = [...this.filtered];
    const any = (l: Lead) => l as any;
    switch (this.sortBy) {
      case 'Created':
        items.sort((a, b) => this.toDate(b.createdAt) - this.toDate(a.createdAt));
        break;
      case 'Name':
        items.sort((a, b) => (a.fullName || '').localeCompare(b.fullName || ''));
        break;
      case 'Status':
        items.sort((a, b) => this.statusOrder(a.status) - this.statusOrder(b.status));
        break;
      case 'Updated':
      default:
        items.sort((a, b) => this.toDate(any(b).updatedAt || b.createdAt) - this.toDate(any(a).updatedAt || a.createdAt));
        break;
    }
    return items;
  }

  // Grouped sections for Status or Source based on sorted list
  get grouped(): Array<{ key: string; items: Lead[] }> {
    if (!this.groupBy) return [];
    const list = this.sorted;
    const map = new Map<string, Lead[]>();
    for (const l of list) {
      const key = this.groupBy === 'Status' ? (l.status as unknown as string) : (l.source || '—');
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(l);
    }
    let keys = Array.from(map.keys());
    if (this.groupBy === 'Status') {
      const order = [LeadStatus.NEW, LeadStatus.CONTACTED, LeadStatus.QUALIFIED, LeadStatus.CONVERTED].map(String);
      keys.sort((a, b) => order.indexOf(a) - order.indexOf(b));
    } else {
      keys.sort((a, b) => a.localeCompare(b));
    }
    return keys.map(k => ({ key: k, items: map.get(k)! }));
  }

  private toDate(val?: string): number {
    try { return val ? new Date(val).getTime() : 0; } catch { return 0; }
  }

  // (Budget sorting helper removed)

  private statusOrder(status: LeadStatus): number {
    const order = [LeadStatus.NEW, LeadStatus.CONTACTED, LeadStatus.QUALIFIED, LeadStatus.CONVERTED];
    const idx = order.indexOf(status);
    return idx === -1 ? Number.MAX_SAFE_INTEGER : idx;
  }

  toggleGroup(key: string) {
    if (this.expandedGroups.has(key)) {
      this.expandedGroups.delete(key);
    } else {
      this.expandedGroups.add(key);
    }
  }

  isGroupExpanded(key: string): boolean {
    return this.expandedGroups.has(key);
  }

  // Initialize all groups as expanded
  private loadCurrentUserEmail() {
    this.authService.getUserProfile().then(profile => {
      if (profile?.email) {
        this.currentUserEmail = profile.email;
        if (this.isDrawerOpen && this.selectedLead) {
          this.checkEmailMatch();
        }
      }
    }).catch(err => console.error('Error loading current user email:', err));
  }

  // Initialize all groups as expanded
  ngOnChanges(changes: SimpleChanges) {
    if (changes['groupedLeads'] && this.groupedLeads?.length) {
      this.expandedGroups.clear();
      this.groupedLeads.forEach(g => this.expandedGroups.add(g.key));
    } else if (changes['leads'] || changes['groupBy']) {
      this.expandedGroups.clear();
      this.grouped.forEach(g => this.expandedGroups.add(g.key));
    }
  }

  getHistoryItems(): HistoryItem[] {
    if (!this.selectedLead) return [];

    const items: HistoryItem[] = [];

    if (this.selectedLead.lastModifiedBy && this.selectedLead.lastModifiedDate) {
      items.push({
        type: 'modified',
        performedBy: this.selectedLead.lastModifiedBy,
        date: this.selectedLead.lastModifiedDate,
        icon: 'assets/lead/progress.svg'
      });
    }

    if (this.selectedLead.createdBy && this.selectedLead.createdDate) {
      items.push({
        type: 'created',
        performedBy: this.selectedLead.createdBy,
        date: this.selectedLead.createdDate,
        icon: 'assets/lead/checkmark.svg'
      });
    }

    return items;
  }


  formatHistoryDate(dateString: string): string {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString().slice(-2);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${day}.${month}.${year} - ${hours}:${minutes}`;
  }

  // Get conversation messages for selected lead
  getConversationMessages(): ConversationMessage[] {
    if (!this.selectedLead) return [];
    // Pas d'API existante pour la conversation → retourner vide pour le moment
    return [];
  }

  getAssigneeName(user: UserDTO): string {
    const name = `${user?.firstname || ''} ${user?.lastname || ''}`.trim();
    return name || user?.email || '—';
  }

  private loadAssignees(tenantId: string) {
    if (!tenantId || tenantId === this.assigneeTenantId) return;
    this.assigneeTenantId = tenantId;
    this.userService.getUsersByTenant(tenantId).subscribe({
      next: (users) => {
        this.assigneeOptions = users || [];
      },
      error: (err) => {
        console.error('Error loading assignees', err);
      }
    });
  }

  get hasResults(): boolean {
    if (this.groupBy) {
      return this.grouped.some(g => g.items.length > 0);
    }
    return this.sorted.length > 0;
  }


}
