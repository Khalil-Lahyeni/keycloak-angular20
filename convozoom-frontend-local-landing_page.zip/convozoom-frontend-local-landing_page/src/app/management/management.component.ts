import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { RoleService } from '../auth/role.service';

@Component({
	selector: 'app-management',
	standalone: true,
	imports: [CommonModule, RouterLink],
	template: `
		<div class="mgmt-container">
			<h1>{{ displayRole }} Management</h1>
			<p>Only visible for users with appropriate management roles.</p>

			<div class="card" *ngIf="user">
				<h3>User Information</h3>
				<div class="row"><label>Username:</label><span>{{ user.username }}</span></div>
				<div class="row"><label>Email:</label><span>{{ user.email }}</span></div>
				<div class="row"><label>First Name:</label><span>{{ user.firstName }}</span></div>
				<div class="row"><label>Last Name:</label><span>{{ user.lastName }}</span></div>
			</div>

			<div class="card">
				<h3>Roles</h3>
				<ul class="roles">
					<li *ngFor="let r of roles">{{ r }}</li>
				</ul>
			</div>

			<div class="nav">
				<a routerLink="/home" class="nav-link">Back to Home</a>
			</div>
		</div>
	`,
	styles: [`
		.mgmt-container { max-width: 800px; margin: 0 auto; padding: 2rem; }
		h1 { margin: 0 0 1rem 0; }
		.card { background: #fff; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.08); padding: 1.25rem; margin: 1rem 0; }
		.row { display: flex; justify-content: space-between; padding: .5rem 0; border-bottom: 1px solid #f1f3f5; }
		.row:last-child { border-bottom: none; }
		label { font-weight: 600; color: #495057; }
		.roles { margin: 0; padding-left: 1.25rem; }
		.nav { margin-top: 1rem; display: flex; gap: 1rem; }
		.nav-link { padding: .5rem 1rem; background: #6c757d; color: #fff; border-radius: 6px; text-decoration: none; }
		.nav-link:hover { background: #5a6268; }
	`]
})
export class ManagementComponent {
	private authService = inject(AuthService);
	private roleService = inject(RoleService);

	user: any = null;
	roles: string[] = [];
	displayRole = '';

	constructor() {
		this.load();
	}

	private async load() {
		this.user = await this.authService.getUserProfile();
		this.roles = await this.roleService.getAllRoles();
		const primary = await this.roleService.getPrimaryDisplayableRole();
		this.displayRole = this.roleService.getDisplayLabel(primary);
	}
}


