import { Component, OnInit, Output, EventEmitter, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { LeadService } from '../../../services/lead-service';
import { Lead } from '../../../models/lead.model';

interface LeadItem {
  id: string;
  name: string;
  location: string;
  status: string;
  statusColor: string;
  value: string;
}

@Component({
  selector: 'app-my-leads-widget',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './my-leads-widget.html',
  styleUrl: './my-leads-widget.css'
})
export class MyLeadsWidgetComponent implements OnInit {
  private leadService = inject(LeadService);
  
  @Input() editMode: boolean = false;
  @Output() remove = new EventEmitter<void>();
  @Output() leadClick = new EventEmitter<string>();
  
  leads: LeadItem[] = [];
  isLoading: boolean = true;

  // Color mapping for statuses
  private statusColors: { [key: string]: string } = {
    'New': '#7B61FF',
    'Contacted': '#9B7DFF',
    'Qualified': '#5E4DB2',
    'Converted': '#403294'
  };

  ngOnInit(): void {
    this.loadData();
  }

  private loadData(): void {
    this.isLoading = true;
    this.leadService.getAllLeads().subscribe({
      next: (leads) => {
        const sortedLeads = leads
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 5);
        
        this.leads = sortedLeads.map(lead => this.mapLead(lead));
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading leads:', err);
        this.isLoading = false;
      }
    });
  }

  private mapLead(lead: Lead): LeadItem {
    const status = lead.status || 'New';
    const estimatedValue = lead.estimatedValue || 0;
    
    // Format value (e.g., 1500000 -> "1.5 M")
    let valueStr = '0';
    if (estimatedValue >= 1000000) {
      valueStr = (estimatedValue / 1000000).toFixed(1) + ' M';
    } else if (estimatedValue >= 1000) {
      valueStr = (estimatedValue / 1000).toFixed(1) + ' K';
    } else if (estimatedValue > 0) {
      valueStr = estimatedValue.toString();
    }

    return {
      id: lead.id || '',
      name: lead.fullName,
      location: lead.location || lead.company || 'Unknown',
      status,
      statusColor: this.statusColors[status] || '#8B8B8B',
      value: valueStr
    };
  }

  onRemove(): void {
    this.remove.emit();
  }

  onLeadClick(leadId: string): void {
    this.leadClick.emit(leadId);
  }
}
