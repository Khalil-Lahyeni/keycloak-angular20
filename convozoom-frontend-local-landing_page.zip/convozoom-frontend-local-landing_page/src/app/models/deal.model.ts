import { Lead } from './lead.model';

export enum DealStage {
    PROSPECTING = 'Prospecting',
    NEGOTIATION = 'Negotiation',
    CLOSED_WON = 'ClosedWon'
}


export interface Deal {
    id?: string;
    tenantId: string;
    title?: string;
    amount?: number;
    currency?: string;
    stage?: DealStage;
    expectedCloseDate?: string;
    actualCloseDate?: string;
    probability?: number;
    assignedTo?: string | null;
    createdAt: string;
    customFields?: string;
    lead: Lead;
    createdBy?: string;
    createdDate?: string;
    lastModifiedBy?: string;
    lastModifiedDate?: string;

}
