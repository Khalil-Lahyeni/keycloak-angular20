import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cta',
  imports: [],
  templateUrl: './cta.html',
  styleUrl: './cta.scss'
})
export class Cta {
  constructor(private router: Router) {}

  startFreeTrial() {
    this.router.navigate(['/free-trial']);
  }
}
