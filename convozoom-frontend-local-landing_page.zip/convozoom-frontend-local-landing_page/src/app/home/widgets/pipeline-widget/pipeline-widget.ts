import { Component, OnInit, Output, EventEmitter, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeadService } from '../../../services/lead-service';
import { Lead } from '../../../models/lead.model';

interface StatusPipeline {
  status: string;
  value: number;
  percentage: number;
  color: string;
}

@Component({
  selector: 'app-pipeline-widget',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pipeline-widget.html',
  styleUrl: './pipeline-widget.scss'
})
export class PipelineWidgetComponent implements OnInit {
  private leadService = inject(LeadService);
  
  @Input() editMode: boolean = false;
  @Output() remove = new EventEmitter<void>();
  
  totalValue: number = 0;
  totalValueFormatted: string = '0';
  percentageChange: number = 0;
  isPositive: boolean = false;
  statusPipelines: StatusPipeline[] = [];
  isLoading: boolean = true;

  // Palette violette comme les autres widgets
  private statusColors: { [key: string]: string } = {
    'New': '#7B61FF',
    'Contacted': '#9B7DFF',
    'Qualified': '#5E4DB2',
    'Converted': '#403294',
    'Closed': '#403294',
    'Canceled': '#6A6E73'
  };

  // Mapping pour l'affichage
  private statusDisplayMap: { [key: string]: string } = {
    'New': 'New',
    'Contacted': 'Contacted',
    'Qualified': 'Qualified',
    'Converted': 'Closed',
    'Canceled': 'Canceled'
  };

  ngOnInit(): void {
    this.loadData();
  }

  private loadData(): void {
    this.isLoading = true;
    this.leadService.getAllLeads().subscribe({
      next: (leads) => {
        this.calculatePipeline(leads);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading leads:', err);
        this.isLoading = false;
      }
    });
  }

  private calculatePipeline(leads: Lead[]): void {
    // Calculer la valeur totale
    this.totalValue = leads.reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);
    this.totalValueFormatted = this.formatValue(this.totalValue);

    // Calculer par status
    const statusMap = new Map<string, number>();
    const statusOrder = ['New', 'Contacted', 'Qualified', 'Converted', 'Canceled'];
    
    leads.forEach(lead => {
      const status = lead.status || 'New';
      const value = lead.estimatedValue || 0;
      statusMap.set(status, (statusMap.get(status) || 0) + value);
    });

    // Construire les pipelines avec mapping pour l'affichage
    this.statusPipelines = statusOrder.map(status => {
      const value = statusMap.get(status) || 0;
      const percentage = this.totalValue > 0 ? (value / this.totalValue) * 100 : 0;
      const displayStatus = this.statusDisplayMap[status] || status;
      return {
        status: displayStatus,
        value,
        percentage: Math.round(percentage),
        color: this.statusColors[status] || '#6A6E73'
      };
    });

    // Calculer la variation (ce mois vs mois dernier)
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    
    const thisMonthValue = leads
      .filter(lead => new Date(lead.createdAt) >= thisMonth)
      .reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);
    
    const lastMonthValue = leads
      .filter(lead => {
        const createdAt = new Date(lead.createdAt);
        return createdAt >= lastMonth && createdAt < thisMonth;
      })
      .reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);

    if (lastMonthValue > 0) {
      this.percentageChange = ((thisMonthValue - lastMonthValue) / lastMonthValue) * 100;
    } else if (thisMonthValue > 0) {
      this.percentageChange = 100;
    } else {
      this.percentageChange = 0;
    }
    
    this.percentageChange = Math.round(this.percentageChange * 10) / 10;
    this.isPositive = this.percentageChange >= 0;
  }

  private formatValue(value: number): string {
    if (value >= 1000000) {
      return (value / 1000000).toFixed(1) + ' M';
    } else if (value >= 1000) {
      return (value / 1000).toFixed(1) + ' K';
    } else {
      return value.toString();
    }
  }

  formatStatusValue(value: number): string {
    return this.formatValue(value);
  }

  onRemove(): void {
    this.remove.emit();
  }
}
