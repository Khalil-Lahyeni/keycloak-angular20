import { Component, Input, Output, EventEmitter, ViewChild, ElementRef, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export type SortDirection = 'asc' | 'desc';

@Component({
  selector: 'app-toolbar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './toolbar-component.html',
  styleUrls: ['./toolbar-component.css']
})
export class ToolbarComponent<T = any> {
  @Input() viewMode: 'grid' | 'list' = 'grid';
  @Input() searchQuery: string = '';
  @Input() filters: { label: string, value: string }[] = [];
  @Input() sortFields: { label: string, value: string }[] = [];
  @Input() groupFields: { label: string, value: string }[] = [];
  @Input() newLabel = 'New';

  @Output() searchQueryChange = new EventEmitter<string>();
  @Output() sortChange = new EventEmitter<{ field: string, direction: SortDirection }>();
  @Output() filterSelected = new EventEmitter<string>();
  @Output() groupSelected = new EventEmitter<string>();
  @Output() viewModeChange = new EventEmitter<'grid' | 'list'>();
  @Output() newLeadClicked = new EventEmitter<void>(); // Nouvel événement
  @Output() newClicked = new EventEmitter<void>();

  @ViewChild('searchInput') searchInput?: ElementRef<HTMLInputElement>;


  isSortOpen = false;
  isGroupOpen = false;
  isSearchOpen = false;
  isFilterOpen = false;

  selectedField: string | null = null;
  sortDirection: SortDirection = 'asc';
  selectedGroup: string | null = null;

  // Recherche
  onSearchInputChange(value: string) {
    this.searchQueryChange.emit(value);
  }


  toggleSearch(event: Event) {
    event.stopPropagation();
    this.isSearchOpen = !this.isSearchOpen;

    if (this.isSearchOpen) {
      setTimeout(() => this.searchInput?.nativeElement.focus());
    }
  }


  // Filtre
  toggleFilter(event: Event) {
    event.stopPropagation();
    this.isFilterOpen = !this.isFilterOpen;
    if (this.isFilterOpen) {
      this.isSortOpen = false;
      this.isGroupOpen = false;
    }
  }

  selectFilter(field: string) {
    this.selectedField = field;
    this.filterSelected.emit(field);
    this.isFilterOpen = false;
    this.isSortOpen = true;
  }

  backToFilter() {
    this.isSortOpen = false;
    this.isFilterOpen = true;
  }

  // Tri
  toggleSort(event: Event) {
    event.stopPropagation();
    if (!this.selectedField) {
      // Si aucun filtre n'est sélectionné, ouvrir d'abord le filtre
      this.isFilterOpen = true;
      return;
    }
    this.isSortOpen = !this.isSortOpen;
    this.isFilterOpen = false;
    this.isGroupOpen = false;
  }

  selectSort(field: string, direction: SortDirection = 'asc') {
    this.selectedField = field;
    this.sortDirection = direction;
    this.sortChange.emit({ field, direction });
    this.isSortOpen = false;
  }

  // Helper pour obtenir le label d'un filtre
  getFilterLabel(value: string): string {
    const filter = this.filters.find(f => f.value === value);
    return filter ? filter.label : value;
  }

  // Group
  toggleGroup(event: Event) {
    event.stopPropagation();
    this.isGroupOpen = !this.isGroupOpen;
    this.isSortOpen = false;
    this.isFilterOpen = false;
  }

  selectGroup(value: string) {
    this.selectedGroup = value;
    this.groupSelected.emit(value);
    this.isGroupOpen = false;
  }

  // Changement de mode
  setViewMode(mode: 'grid' | 'list') {
    this.viewMode = mode;
    this.viewModeChange.emit(mode);
  }

  emitNewLead() {
    this.newLeadClicked.emit();
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.pf-v6-c-dropdown') && !target.closest('.filter-wrapper') && !target.closest('.sort-wrapper')) {
      this.isSortOpen = false;
      this.isGroupOpen = false;
      this.isFilterOpen = false;
    }
    if (!target.closest('.search-wrapper')) {
      this.isSearchOpen = false;
    }
  }
  emitNew() {
    this.newClicked.emit();
  }


}