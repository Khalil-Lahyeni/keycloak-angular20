# ConvoZoom Frontend

A modern Angular application with Keycloak authentication and environment-based configuration.

## Features

- **Angular 20** with standalone components
- **Keycloak Authentication** integration
- **Environment-based Configuration** with runtime injection
- **Production-ready** Docker deployment
- **Clean Architecture** with proper separation of concerns

## Quick Start

### Development

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm start
   ```

3. **Access the application:**
   - Open http://localhost:4200 in your browser

### Production Build

1. **Configure environment:**
   ```bash
   cp deploy/.env.example .env
   # Edit .env with your configuration
   ```

2. **Build and package:**
   ```bash
   npm run package
   ```

3. **Deploy:**
   - Copy the `deploy-package` folder to your server
   - Configure the `.env` file
   - Use Docker or any web server to serve the files

## Configuration

The application uses runtime configuration injection for environment-specific settings.

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `KEYCLOAK_URL` | Keycloak server URL | `http://localhost:8080` |
| `KEYCLOAK_REALM` | Keycloak realm name | `agency_01` |
| `KEYCLOAK_CLIENT_ID` | Keycloak client ID | `convozoom-frontEnd_client_01` |
| `API_BASE_URL` | Backend API base URL | `http://localhost:3000/api` |
| `ENVIRONMENT` | Environment name | `production` |
| `DEBUG_MODE` | Enable debug mode | `false` |

### Configuration Sources (in order of priority)

1. **Runtime Environment Variables** (Docker, system env)
2. **Config Injection** (from `config-injector.js`)
3. **Fallback Configuration** (hardcoded defaults)

## Deployment

### Docker Deployment

1. **Prepare environment:**
   ```bash
   cp deploy/.env.example .env
   # Configure your environment variables
   ```

2. **Deploy with Docker Compose:**
   ```bash
   cd deploy-package
   docker-compose up -d
   ```

3. **Access the application:**
   - Open http://localhost in your browser

### Manual Deployment

1. **Build the application:**
   ```bash
   npm run package
   ```

2. **Copy files to your server:**
   ```bash
   scp -r deploy-package/* user@server:/var/www/html/
   ```

3. **Configure web server:**
   - Use the provided `nginx.conf` as reference
   - Ensure `config-injector.js` is served from `/assets/`

## Project Structure

```
src/
├── app/
│   ├── auth/                 # Authentication components and services
│   ├── config/               # Configuration management
│   ├── home/                 # Home page component
│   ├── management/           # Management components
│   ├── profile/              # User profile components
│   ├── protected/            # Protected route components
│   ├── app.config.ts         # Application configuration
│   ├── app.routes.ts         # Application routes
│   └── app.ts                # Main application component
├── assets/
│   ├── config-injector.js    # Runtime configuration template
│   └── config.json           # Fallback configuration
└── environments/
    └── environment.ts        # Development environment

deploy/
├── build.js                  # Build script with config injection
├── package.js                # Package creation script
├── package.bat               # Windows package script
├── package.sh                # Linux/Mac package script
├── docker-compose.yml        # Docker Compose configuration
├── Dockerfile.serve          # Production Docker image
├── nginx.conf                # Nginx configuration
├── inject-env.sh             # Environment injection for Docker
└── .env.example              # Environment variables template
```

## Development

### Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for development
- `npm run build:prod` - Build for production
- `npm run build:deploy` - Build with configuration injection
- `npm run package` - Create deployment package
- `npm test` - Run tests

### Key Components

- **AppConfigService** - Manages application configuration
- **AuthService** - Handles Keycloak authentication
- **RoleService** - Manages user roles and permissions
- **AuthGuard** - Protects routes requiring authentication

## Security

- **CSP Headers** - Content Security Policy implemented
- **XSS Protection** - Cross-site scripting protection
- **Secure Headers** - Additional security headers in production
- **Environment Isolation** - Configuration separated from code

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is proprietary software. All rights reserved.