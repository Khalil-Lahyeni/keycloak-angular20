import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../config';
import { ErrorHandlerService } from './error-handler.service';
import { Lead } from '../models/lead.model';
import { catchError, Observable, throwError } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { ActivityService } from './activity-service';

@Injectable({
  providedIn: 'root'
})
export class LeadService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService, private activityService: ActivityService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllLeads(filter?: string): Observable<Lead[]> {
    let params = new HttpParams();
    if (filter) {
      params = params.set('filter', filter);
    }
    return this.http.get<Lead[]>(`${this.base}/leads`, { params }).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllLeads');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the lead');
        return throwError(() => errorInfo);
      })
    );
  }

  getLeadById(id: string): Observable<Lead> {
    return this.http.get<Lead>(`${this.base}/leads/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getLead');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the lead');
        return throwError(() => errorInfo);
      })
    );
  }

  createLead(body: Lead): Observable<Lead> {
    return this.http.post<Lead>(`${this.base}/leads`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createLead');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the lead');
        return throwError(() => errorInfo);
      })
    );
  }

  updateLead(id: string, body: Lead): Observable<Lead> {
    return this.http.put<Lead>(`${this.base}/leads/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateLead');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the lead');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateLead(id: string, body: Partial<Lead>): Observable<Lead> {
    return this.http.patch<Lead>(`${this.base}/leads/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateLead');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the lead');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteLead(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/leads/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteLead');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the lead');
        return throwError(() => errorInfo);
      })
    );
  }

  /**
   * Delete lead with all associated activities
   * First deletes all activities linked to the lead, then deletes the lead itself
   * @param id Lead ID
   * @returns Observable<void>
   */
  deleteLeadWithActivities(id: string): Observable<void> {
    return this.activityService.deleteActivitiesByLeadId(id).pipe(
      switchMap(() => this.deleteLead(id)),
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteLeadWithActivities');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the lead and associated activities');
        return throwError(() => errorInfo);
      })
    );
  }
}
