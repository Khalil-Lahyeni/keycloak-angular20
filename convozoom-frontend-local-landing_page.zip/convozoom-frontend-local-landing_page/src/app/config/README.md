# Dynamic Configuration System

This configuration system allows your Angular application to load configuration from `/assets/config.json` before initializing Keycloak and other services.

## How It Works

1. **App Initialization**: The `initializeApp` function loads configuration from `/assets/config.json` before any other services start
2. **Keycloak Initialization**: Keycloak is initialized using the loaded configuration instead of hardcoded environment values
3. **Fallback Support**: If `config.json` fails to load, the system falls back to default values

## Configuration File Structure

Place your configuration in `src/assets/config.json`:

```json
{
  "keycloak": {
    "url": "http://your-keycloak-server:8080",
    "realm": "your-realm",
    "clientId": "your-client-id"
  },
  "api": {
    "baseUrl": "http://your-api-server/api"
  },
  "features": {
    "debugMode": true,
    "analytics": false
  },
  "environment": "production"
}
```

## Usage in Components

```typescript
import { Component, OnInit } from '@angular/core';
import { AppConfigService } from '../config/app-config.service';

@Component({
  selector: 'app-example',
  template: '<div>Config loaded!</div>'
})
export class ExampleComponent implements OnInit {
  constructor(private configService: AppConfigService) {}

  ngOnInit() {
    // Get entire config
    this.configService.getConfig().subscribe(config => {
      console.log('Full config:', config);
    });

    // Get specific values
    this.configService.getKeycloakUrl().subscribe(url => {
      console.log('Keycloak URL:', url);
    });
  }
}
```

## Environment-Specific Configuration

For different environments, you can:

1. **Build-time**: Replace `config.json` during the build process
2. **Runtime**: Serve different config files based on environment
3. **Docker**: Mount different config files in containers

## Security Considerations

- The `config.json` file is publicly accessible in the `/assets` folder
- Sensitive information should not be stored in this file
- Use environment variables or secure backend endpoints for sensitive data

## Troubleshooting

- Check browser console for configuration loading errors
- Verify `config.json` is accessible at `/assets/config.json`
- Ensure the JSON format is valid
- Check that the configuration structure matches the `AppConfig` interface
