import { Component, OnInit, Output, EventEmitter, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeadService } from '../../../services/lead-service';
import { Lead } from '../../../models/lead.model';

interface LanguageData {
  x: string;
  y: number;
  percentage: number;
}

interface OriginData {
  x: string;
  y: number;
  percentage: number;
}

type TabType = 'language' | 'origin';

@Component({
  selector: 'app-demography-widget',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './demography-widget.html',
  styleUrl: './demography-widget.scss'
})
export class DemographyWidgetComponent implements OnInit {
  private leadService = inject(LeadService);
  
  @Input() editMode: boolean = false;
  @Output() remove = new EventEmitter<void>();
  
  activeTab: TabType = 'language';
  languageData: LanguageData[] = [];
  originData: OriginData[] = [];
  totalLeads: number = 0;
  isLoading: boolean = true;

  // Palette violette comme le widget "Total leads"
  private colorScale: string[] = [
    '#7B61FF',  // New
    '#9B7DFF',  // Contacted
    '#5E4DB2',  // Qualified
    '#403294'   // Converted
  ];

  ngOnInit(): void {
    this.loadData();
  }

  private loadData(): void {
    this.isLoading = true;
    this.leadService.getAllLeads().subscribe({
      next: (leads) => {
        this.processLanguageData(leads);
        this.processOriginData(leads);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading leads:', err);
        this.isLoading = false;
      }
    });
  }

  private processLanguageData(leads: Lead[]): void {
    this.totalLeads = leads.length;
    
    if (this.totalLeads === 0) {
      this.languageData = [];
      return;
    }

    // Compter les langues
    const languageMap = new Map<string, number>();
    leads.forEach(lead => {
      const language = lead.preferedLanguage || 'Unknown';
      languageMap.set(language, (languageMap.get(language) || 0) + 1);
    });

    // Trier par volume (desc)
    const sortedLanguages = Array.from(languageMap.entries())
      .sort((a, b) => b[1] - a[1]);

    // Si > 4 langues distinctes : TOP 3 + "Other"
    if (sortedLanguages.length > 4) {
      const top3 = sortedLanguages.slice(0, 3);
      const others = sortedLanguages.slice(3);
      const otherCount = others.reduce((sum, [, count]) => sum + count, 0);
      
      this.languageData = [
        ...top3.map(([lang, count]) => ({
          x: lang,
          y: count,
          percentage: Math.round((count / this.totalLeads) * 100)
        })),
        {
          x: 'Other',
          y: otherCount,
          percentage: Math.round((otherCount / this.totalLeads) * 100)
        }
      ];
    } else {
      // Sinon afficher toutes les langues
      this.languageData = sortedLanguages.map(([lang, count]) => ({
        x: lang,
        y: count,
        percentage: Math.round((count / this.totalLeads) * 100)
      }));
    }
  }

  private processOriginData(leads: Lead[]): void {
    this.totalLeads = leads.length;
    
    if (this.totalLeads === 0) {
      this.originData = [];
      return;
    }

    // Compter les locations/origines
    const locationMap = new Map<string, number>();
    leads.forEach(lead => {
      const location = lead.location || 'Unknown';
      locationMap.set(location, (locationMap.get(location) || 0) + 1);
    });

    // Trier par volume (desc)
    const sortedLocations = Array.from(locationMap.entries())
      .sort((a, b) => b[1] - a[1]);

    // Si > 4 locations distinctes : TOP 3 + "Other"
    if (sortedLocations.length > 4) {
      const top3 = sortedLocations.slice(0, 3);
      const others = sortedLocations.slice(3);
      const otherCount = others.reduce((sum, [, count]) => sum + count, 0);
      
      this.originData = [
        ...top3.map(([loc, count]) => ({
          x: loc,
          y: count,
          percentage: Math.round((count / this.totalLeads) * 100)
        })),
        {
          x: 'Other',
          y: otherCount,
          percentage: Math.round((otherCount / this.totalLeads) * 100)
        }
      ];
    } else {
      // Sinon afficher toutes les locations
      this.originData = sortedLocations.map(([loc, count]) => ({
        x: loc,
        y: count,
        percentage: Math.round((count / this.totalLeads) * 100)
      }));
    }
  }

  selectTab(tab: TabType): void {
    this.activeTab = tab;
  }

  onRemove(): void {
    this.remove.emit();
  }

  getSegmentColor(index: number): string {
    return this.colorScale[index % this.colorScale.length];
  }

  // Get total count for accurate angle calculations
  private getTotalCount(): number {
    const data = this.activeTab === 'language' ? this.languageData : this.originData;
    return data.reduce((sum, item) => sum + item.y, 0);
  }

  // Calcul des paths SVG pour le pie chart
  getPieSlicePath(index: number): string {
    const data = this.activeTab === 'language' ? this.languageData : this.originData;
    const radius = 140;
    const total = this.getTotalCount();
    
    // If only one segment (100%), draw a full circle
    if (data.length === 1) {
      return `M 0 ${-radius} A ${radius} ${radius} 0 1 1 0 ${radius} A ${radius} ${radius} 0 1 1 0 ${-radius} Z`;
    }
    
    // Commencer à -90° (en haut du cercle)
    let startAngle = -Math.PI / 2;
    
    // Calculer l'angle de départ using actual counts (not rounded percentages)
    for (let i = 0; i < index; i++) {
      startAngle += (data[i].y / total) * 2 * Math.PI;
    }
    
    const angle = (data[index].y / total) * 2 * Math.PI;
    const endAngle = startAngle + angle;
    
    const x1 = radius * Math.cos(startAngle);
    const y1 = radius * Math.sin(startAngle);
    const x2 = radius * Math.cos(endAngle);
    const y2 = radius * Math.sin(endAngle);
    
    const largeArc = angle > Math.PI ? 1 : 0;
    
    return `M 0 0 L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;
  }

  // Position du label sur le slice
  getLabelX(index: number): number {
    const data = this.activeTab === 'language' ? this.languageData : this.originData;
    const radius = 90;
    const total = this.getTotalCount();
    // Commencer à -90° (en haut du cercle)
    let startAngle = -Math.PI / 2;
    
    for (let i = 0; i < index; i++) {
      startAngle += (data[i].y / total) * 2 * Math.PI;
    }
    
    const angle = (data[index].y / total) * 2 * Math.PI;
    const midAngle = startAngle + angle / 2;
    
    return radius * Math.cos(midAngle);
  }

  getLabelY(index: number): number {
    const data = this.activeTab === 'language' ? this.languageData : this.originData;
    const radius = 90;
    const total = this.getTotalCount();
    // Commencer à -90° (en haut du cercle)
    let startAngle = -Math.PI / 2;
    
    for (let i = 0; i < index; i++) {
      startAngle += (data[i].y / total) * 2 * Math.PI;
    }
    
    const angle = (data[index].y / total) * 2 * Math.PI;
    const midAngle = startAngle + angle / 2;
    
    return radius * Math.sin(midAngle);
  }
}
