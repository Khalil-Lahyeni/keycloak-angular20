export interface AppConfig {
  keycloak: {
    url: string;
    realm: string;
    clientId: string;
  };
  api?: {
    baseUrl?: string;
    aiBaseUrl?: string;
  };
  features?: {
    [key: string]: boolean;
  };
  environment?: string;
  deployment?: {
    version?: string;
    buildDate?: string;
    gitCommit?: string;
  };
}

export interface EnvConfig {
  KEYCLOAK_URL?: string;
  KEYCLOAK_REALM?: string;
  KEYCLOAK_CLIENT_ID?: string;
  API_BASE_URL?: string;
  API_AI_BASE_URL?: string;
  ENVIRONMENT?: string;
  DEBUG_MODE?: string;
}
