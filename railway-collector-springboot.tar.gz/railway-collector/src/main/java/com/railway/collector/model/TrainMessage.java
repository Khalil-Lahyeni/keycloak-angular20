package com.railway.collector.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrainMessage {

    private int messageId;
    private String messageType;
    private String name;
}
