package com.railway.collector.config;

import com.railway.collector.handler.MqttMessageRouter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.paho.mqttv5.client.MqttConnectionOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.mqtt.core.Mqttv5ClientManager;
import org.springframework.integration.mqtt.inbound.Mqttv5PahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.outbound.Mqttv5PahoMessageHandler;
import org.springframework.messaging.MessageChannel;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class MqttIntegrationConfig {

    private final MqttProperties mqttProperties;

    // ─── Connection Options ───
    @Bean
    public MqttConnectionOptions mqttConnectionOptions() {
        MqttConnectionOptions options = new MqttConnectionOptions();
        options.setServerURIs(new String[]{mqttProperties.getBroker().getUrl()});
        options.setAutomaticReconnect(true);
        options.setCleanStart(true);
        options.setConnectionTimeout(10);
        options.setKeepAliveInterval(60);

        if (mqttProperties.getBroker().getUsername() != null
                && !mqttProperties.getBroker().getUsername().isEmpty()) {
            options.setUserName(mqttProperties.getBroker().getUsername());
            options.setPassword(mqttProperties.getBroker().getPassword().getBytes());
        }

        return options;
    }

    // ─── Client Manager (shared connection) ───
    @Bean
    public Mqttv5ClientManager mqttClientManager(MqttConnectionOptions options) {
        Mqttv5ClientManager manager = new Mqttv5ClientManager(
                options, mqttProperties.getClient().getId());
        return manager;
    }

    // ─── Channels ───
    @Bean
    public MessageChannel mqttInboundChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }

    // ─── Inbound: Subscribe to raw topics ───
    @Bean
    public Mqttv5PahoMessageDrivenChannelAdapter mqttInboundAdapter(
            Mqttv5ClientManager clientManager) {

        String[] topics = mqttProperties.getTopics().getRaw().toArray(new String[0]);

        Mqttv5PahoMessageDrivenChannelAdapter adapter =
                new Mqttv5PahoMessageDrivenChannelAdapter(clientManager, topics);
        adapter.setQos(1);
        adapter.setOutputChannel(mqttInboundChannel());

        log.info("MQTT Inbound adapter subscribed to: {}", (Object) topics);
        return adapter;
    }

    // ─── Inbound Flow: Route messages to handler ───
    @Bean
    public IntegrationFlow mqttInboundFlow(MqttMessageRouter router) {
        return IntegrationFlow.from(mqttInboundChannel())
                .handle(router, "handleMessage")
                .get();
    }

    // ─── Outbound: Publish processed messages ───
    @Bean
    public Mqttv5PahoMessageHandler mqttOutboundHandler(
            Mqttv5ClientManager clientManager) {

        Mqttv5PahoMessageHandler handler = new Mqttv5PahoMessageHandler(clientManager);
        handler.setAsync(true);
        handler.setDefaultQos(1);
        return handler;
    }

    @Bean
    public IntegrationFlow mqttOutboundFlow(Mqttv5PahoMessageHandler handler) {
        return IntegrationFlow.from(mqttOutboundChannel())
                .handle(handler)
                .get();
    }
}
