import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { PlanItemDTO } from '../models/plan-item.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({ providedIn: 'root' })
export class PlanItemService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllPlanItems(tenantId: string): Observable<PlanItemDTO[]> {
    return this.http.get<PlanItemDTO[]>(`${this.base}/plan-items/tenant/${tenantId}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllPlanItems');
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'get');
        return throwError(() => errorInfo);
      })
    );
  }

  create(body: PlanItemDTO): Observable<PlanItemDTO> {
    return this.http.post<PlanItemDTO>(`${this.base}/plan-items`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createPlanItem');
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'create');
        return throwError(() => errorInfo);
      })
    );
  }
}
