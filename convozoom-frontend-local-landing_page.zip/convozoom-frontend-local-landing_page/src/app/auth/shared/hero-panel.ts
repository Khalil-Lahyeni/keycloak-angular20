import { Component, Input } from '@angular/core';
import { NgOptimizedImage } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-hero-panel',
  standalone: true,
  imports: [NgOptimizedImage, RouterLink],
  templateUrl: './hero-panel.html',
  styleUrls: ['./hero-panel.scss']
})
export class HeroPanelComponent {
  @Input() title = '';
  @Input() subtitle = '';

  @Input() iconSrc: string = 'assets/sign-up/lock.svg';

  @Input() logoSrc: string = 'assets/sign-up/mindx-logo.svg';
  @Input() logoAlt: string = 'MINDix';
  @Input() logoWidth: number = 200;
  @Input() logoHeight: number = 32;
}
