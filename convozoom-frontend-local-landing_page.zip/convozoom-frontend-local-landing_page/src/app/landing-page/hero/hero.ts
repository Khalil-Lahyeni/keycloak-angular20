import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hero',
  imports: [],
  templateUrl: './hero.html',
  styleUrl: './hero.scss'
})
export class Hero {
  constructor(private router: Router) {}

  goToLogin() {
    this.router.navigate(['/home']);
  }
  
  startFreeTrial() {
    this.router.navigate(['/free-trial']);
  }
}
