package com.railway.collector.handler;

import com.railway.collector.service.CollectorStatsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Endpoint REST pour monitorer le Collector lui-même.
 * GET /api/collector/health  → état du service
 * GET /api/collector/stats   → compteurs de traitement
 */
@RestController
@RequestMapping("/api/collector")
@RequiredArgsConstructor
public class CollectorHealthController {

    private final CollectorStatsService stats;

    @GetMapping("/health")
    public Map<String, Object> health() {
        Map<String, Object> health = new LinkedHashMap<>();
        health.put("status", "UP");
        health.put("service", "Railway Collector");
        health.put("timestamp", Instant.now().toString());
        return health;
    }

    @GetMapping("/stats")
    public Map<String, Object> stats() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("messagesReceived", stats.getMessagesReceived());
        result.put("messagesProcessed", stats.getMessagesProcessed());
        result.put("messagesInvalid", stats.getMessagesInvalid());
        result.put("alertsGenerated", stats.getAlertsGenerated());
        result.put("timestamp", Instant.now().toString());
        return result;
    }
}
