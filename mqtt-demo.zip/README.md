# 🚀 MQTT Demo — Spring Boot + Mosquitto + Device Simulator

Mini projet d'intégration MQTT avec Spring Boot, un broker Mosquitto (Docker), 
et un simulateur de device IoT embarqué.

## Architecture

```
┌─────────────────┐     MQTT      ┌──────────────┐     MQTT      ┌─────────────────┐
│  Device          │ ──publish──▶  │  Mosquitto   │ ◀──subscribe──│  Spring Boot    │
│  Simulator       │              │  Broker       │               │  (Handler)      │
│  (Paho Client)   │              │  :1883        │               │                 │
└─────────────────┘               └──────────────┘               └─────────────────┘
                                                                        │
                                                                   Console Output
                                                                   (logs sensor data)
```

## Prérequis

- Java 17+
- Maven 3.8+
- Docker & Docker Compose

## Démarrage rapide

### 1. Lancer Mosquitto

```bash
cd mqtt-demo
docker-compose up -d
```

Vérifier que le broker tourne :
```bash
docker ps   # doit voir mosquitto-broker sur le port 1883
```

### 2. Lancer l'application Spring Boot + Simulateur

```bash
cd spring-mqtt
mvn spring-boot:run
```

C'est tout ! Le simulateur est embarqué et démarre automatiquement.

## Ce qui se passe

Le **Device Simulator** publie toutes les 3 secondes sur ces topics :

| Topic                  | Données                           |
|------------------------|-----------------------------------|
| `devices/temperature`  | Température (°C) avec alertes     |
| `devices/humidity`     | Humidité (%) avec alertes         |
| `devices/gps`          | Coordonnées GPS (autour de Gabès) |
| `devices/status`       | ONLINE / MAINTENANCE / ERROR      |

Le **Spring Boot Handler** reçoit et affiche en console avec :
- Parsing JSON → objet `SensorData`
- Alertes automatiques (temp > 40°C, humidity > 80%, status ERROR)
- Compteur de messages et stats

## Sortie console (exemple)

```
═══════════════════════════════════════════════
📨 MQTT Message Received  [#5]
📌 Topic   : devices/temperature
📦 Raw     : {"device_id":"DEVICE-001","sensor_type":"temperature","value":38.72,"unit":"°C",...}
🌡️  TEMPERATURE
   Device    : DEVICE-001
   Value     : 38.72 °C
   Timestamp : 2025-01-15T14:32:10
═══════════════════════════════════════════════
```

## Configuration

Tout dans `application.properties` :

```properties
# Désactiver le simulateur (pour utiliser un vrai device)
simulator.enabled=false

# Changer l'intervalle de publication
simulator.interval.ms=5000

# Changer le broker
mqtt.broker.url=tcp://192.168.1.100:1883
```

## Tester manuellement avec mosquitto-cli

```bash
# Publier un message
docker exec mosquitto-broker mosquitto_pub \
  -t "devices/temperature" \
  -m '{"device_id":"MANUAL-TEST","sensor_type":"temperature","value":42.5,"unit":"°C","timestamp":"2025-01-15T10:00:00"}'

# Écouter tous les topics devices
docker exec mosquitto-broker mosquitto_sub -t "devices/#" -v
```

## Structure du projet

```
mqtt-demo/
├── docker-compose.yml              # Mosquitto broker
├── mosquitto/
│   └── config/mosquitto.conf       # Config Mosquitto
└── spring-mqtt/
    ├── pom.xml
    └── src/main/java/com/actia/mqttdemo/
        ├── MqttDemoApplication.java       # Main
        ├── config/
        │   └── MqttConfig.java            # MQTT beans (in/out)
        ├── model/
        │   └── SensorData.java            # Data model
        ├── service/
        │   ├── MqttMessageHandler.java    # Receives & processes
        │   └── MqttPublisherService.java  # Sends messages
        └── simulator/
            └── DeviceSimulator.java       # Fake device
```

## Technologies

- **Spring Boot 3.2** + Spring Integration MQTT
- **Eclipse Paho** (MQTT client)
- **Mosquitto 2.0** (MQTT broker via Docker)
- **Jackson** (JSON serialization)
- **Lombok** (boilerplate reduction)
