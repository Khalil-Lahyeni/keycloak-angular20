import { Component, OnInit, OnDestroy } from '@angular/core';
import { Footer } from './footer/footer'; 
import { Features } from './features/features';
import { Cta } from './cta/cta';
import { Contacts } from './contacts/contacts';
import { Pricing } from './pricing/pricing';
import { Hero } from './hero/hero';

@Component({
  selector: 'app-landing-page',
  imports: [Hero, Features, Contacts, Cta, Footer, Pricing],
  templateUrl: './landing-page.html',
  styleUrl: './landing-page.scss'
})
export class LandingPage implements OnInit, OnDestroy {
  
  ngOnInit(): void {
    this.setupSmoothScrolling();
  }
  
  ngOnDestroy(): void {
  }
  
  private setupSmoothScrolling(): void {
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      const link = target.closest('a[href^="#"]') as HTMLAnchorElement;
      
      if (link && link.hash) {
        e.preventDefault();
        const targetElement = document.querySelector(link.hash);
        
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    });
  }
}
