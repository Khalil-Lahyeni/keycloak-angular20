# ConvoZoom Frontend Deployment Package

This package contains a production-ready build of the ConvoZoom frontend.

## Quick Start

1. Copy `env.example` to `.env` and configure your environment variables:
   - KEYCLOAK_URL: Your Keycloak server URL
   - KEYCLOAK_REALM: Your Keycloak realm
   - KEYCLOAK_CLIENT_ID: Your Keycloak client ID
   - API_BASE_URL: Your backend API URL

2. For Docker deployment:
   ```bash
   docker-compose up -d
   ```

3. For manual deployment:
   - Serve the files using any web server (nginx, Apache, etc.)
   - Make sure to serve the `config-injector.js` file from `/assets/`

## Configuration

The application uses runtime configuration injection. The `config-injector.js`
file in the assets folder contains the environment-specific configuration.

## Environment Variables

- KEYCLOAK_URL: Keycloak server URL
- KEYCLOAK_REALM: Keycloak realm name
- KEYCLOAK_CLIENT_ID: Keycloak client ID
- API_BASE_URL: Backend API base URL
- ENVIRONMENT: Environment name (production, staging, etc.)
- DEBUG_MODE: Enable debug mode (true/false)
