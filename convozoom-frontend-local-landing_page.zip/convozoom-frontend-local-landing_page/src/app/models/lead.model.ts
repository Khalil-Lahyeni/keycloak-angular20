export enum LeadStatus {
  NEW = 'New',
  CONTACTED = 'Contacted',
  QUALIFIED = 'Qualified',
  CONVERTED = 'Converted'
}

export interface Lead {
  id?: string;
  tenantId: string;
  guestId?: string | null;
  sourceRef?: string;
  source?: string;
  fullName: string;
  email?: string;
  phone?: string;
  status: LeadStatus;
  company?: string;
  tags?: string;
  assignedTo?: string | null;
  createdAt: string;
  customFields?: string | null;
  campaign?: string;
  title?: string;
  productInterest?: string;
  priority?: string;
  estimatedValue?: number;
  preferedLanguage?: string;
  timezone?: string;
  location?: string;
  notes?: string;
  createdBy?: string;
  createdDate?: string;
  lastModifiedBy?: string;
  lastModifiedDate?: string;
}


