package com.railway.collector.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Statistiques internes du Collector.
 * Log périodiquement les compteurs de traitement.
 */
@Slf4j
@Service
public class CollectorStatsService {

    private final AtomicLong messagesReceived = new AtomicLong(0);
    private final AtomicLong messagesProcessed = new AtomicLong(0);
    private final AtomicLong messagesInvalid = new AtomicLong(0);
    private final AtomicLong alertsGenerated = new AtomicLong(0);

    public void incrementReceived() {
        messagesReceived.incrementAndGet();
    }

    public void incrementProcessed() {
        messagesProcessed.incrementAndGet();
    }

    public void incrementInvalid() {
        messagesInvalid.incrementAndGet();
    }

    public void incrementAlerts(int count) {
        alertsGenerated.addAndGet(count);
    }

    @Scheduled(fixedRate = 30_000)
    public void logStats() {
        log.info("Stats: received={}, processed={}, invalid={}, alerts={}",
                messagesReceived.get(),
                messagesProcessed.get(),
                messagesInvalid.get(),
                alertsGenerated.get());
    }

    // Getters pour l'endpoint REST (monitoring)
    public long getMessagesReceived() { return messagesReceived.get(); }
    public long getMessagesProcessed() { return messagesProcessed.get(); }
    public long getMessagesInvalid() { return messagesInvalid.get(); }
    public long getAlertsGenerated() { return alertsGenerated.get(); }
}
