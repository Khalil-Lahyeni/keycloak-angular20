import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TemplateDTO, TemplateType } from '../models/template.model';
import { TemplateService } from '../services/template-service';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { NotificationService } from '../services/notification';
import { AppConfigService } from '../config/app-config.service';
import { ErrorInfo } from '../services/error-handler.service';
import { LoadingService } from '../services/loading.service';


@Component({
  selector: 'app-templates-table',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './template.html',
  styleUrl: './template.scss'
})
export class TemplatesTable implements OnInit {
  templates: TemplateDTO[] = [];
  error = '';

  showModal = false;
  isEditMode = false;
  editingTemplateId: string | null = null;
  templateTypes = Object.values(TemplateType);

  newTemplate: TemplateDTO = {
    code: '',
    name: '',
    type: TemplateType.Text,
    version: 1,
    textContent: '',
    attachedFile: '',
    attachedFileContentType:''
  };

  selectedFile: File | null = null;
  isDragOver = false;
  isDropdownOpen = false;


  private acceptedFileTypes = [
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel'
  ];

  private maxFileSize = 10 * 1024 * 1024;

  constructor(
    private templateService: TemplateService,
    private tenantSelection: TenantSelectionService,
    private notificationService: NotificationService,
    private appConfigService: AppConfigService,
    public loadingService: LoadingService
  ) {}

  ngOnInit(): void {
    this.loadTemplates();
  }

  loadTemplates() {
    this.loadingService.show();
    this.error = '';

    // Get tenant from signal (synchronous)
    const selected = this.tenantSelection.selectedTenant();
    const load = (tenantId: string) => {
      if (!tenantId || tenantId === 'undefined') {
        this.loadingService.hide();
        this.error = 'Tenant ID is not available. Please select a tenant.';
        this.notificationService.showError(this.error);
        this.templates = [];
        return;
      }

      this.templateService.getAllTemplates(tenantId).subscribe({
        next: (templates: TemplateDTO[]) => {
          this.templates = templates;
          this.loadingService.hide();
        },
        error: (errorInfo: ErrorInfo) => {
          this.error = errorInfo.message;
          this.loadingService.hide();
          this.notificationService.showError(errorInfo.message);
          this.templates = [];
        }
      });
    };

    // Call the loader using the selected tenant when available, otherwise fall back to realm
    if (selected?.id) {
      // Tenant is available from APP_INITIALIZER
      load(selected.id);
    } else {
      // Fallback: if no tenant, use realm as tenantId
      this.appConfigService.getKeycloakRealm().subscribe({
        next: (realm) => {
          if (realm && realm !== 'master' && realm !== 'convozoom') {
            load(realm);
          } else {
            this.loadingService.hide();
            this.error = 'Unable to determine tenant. Please select a tenant.';
            this.notificationService.showError(this.error);
            this.templates = [];
          }
        },
        error: (error) => {
          this.loadingService.hide();
          this.error = 'Failed to retrieve realm information.';
          this.notificationService.showError(this.error);
          this.templates = [];
        }
      });
    }
  }

  addTemplate() {
    this.isEditMode = false;
    this.editingTemplateId = null;
    this.showModal = true;
    this.resetForm();
  }

  editTemplate(template: TemplateDTO) {
    if (!template.id) {
      this.notificationService.showError('Template ID is missing.');
      return;
    }

    this.isEditMode = true;
    this.editingTemplateId = template.id;
    this.loadingService.show();


    this.templateService.getTemplate(template.id).subscribe({
      next: (templateDTO: TemplateDTO) => {
        this.newTemplate = { ...templateDTO };
        this.showModal = true;
        this.loadingService.hide();
      },
      error: (errorInfo: ErrorInfo) => {
        this.loadingService.hide();
        this.notificationService.showError(errorInfo.message || 'Failed to load template.');
      }
    });
  }

  deleteTemplate(template: TemplateDTO) {
    if (!template.id) {
      this.notificationService.showError('Template ID is missing.');
      return;
    }


    if (!confirm(`Are you sure you want to delete the template "${template.name}"?`)) {
      return;
    }

    this.loadingService.show();

    this.templateService.deleteTemplate(template.id).subscribe({
      next: () => {
        this.loadingService.hide();
        this.notificationService.showSuccess('Template deleted successfully!');
        this.loadTemplates();
      },
      error: (errorInfo: ErrorInfo) => {
        this.loadingService.hide();
        this.notificationService.showError(errorInfo.message || 'Failed to delete template.');
      }
    });
  }

  closeModal() {
    this.showModal = false;
    this.isEditMode = false;
    this.editingTemplateId = null;
    this.resetForm();
  }

  resetForm() {
    this.newTemplate = {
      code: '',
      name: '',
      type: TemplateType.Text,
      version: 1,
      textContent: '',
      attachedFile: '',
      attachedFileContentType:''
    };
    this.selectedFile = null;
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.processFile(input.files[0]);
    }
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver = true;
  }

  onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver = false;
  }

  onFileDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver = false;

    if (event.dataTransfer?.files && event.dataTransfer.files.length > 0) {
      this.processFile(event.dataTransfer.files[0]);
    }
  }

  private processFile(file: File) {
    if (!this.acceptedFileTypes.includes(file.type)) {
      this.notificationService.showError(
        'Only Word (.doc, .docx) and Excel (.xls, .xlsx) files are allowed.'
      );
      return;
    }

    if (file.size > this.maxFileSize) {
      this.notificationService.showError(
        `File size must not exceed ${this.maxFileSize / (1024 * 1024)}MB.`
      );
      return;
    }

    this.loadingService.show();
    this.encodeFileToBase64(file)
      .then(base64Content => {
        this.selectedFile = file;
        this.newTemplate.attachedFile = base64Content;
        this.newTemplate.attachedFileContentType = file.type;
        this.loadingService.hide();
      })
      .catch(error => {
        this.loadingService.hide();
        console.error('Error encoding file:', error);
        this.notificationService.showError('Failed to process the file.');
      });
  }

  private encodeFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  getFileIcon(contentType?: string): string {
    if (!contentType) return 'fa-file';

    if (contentType.includes('word')) return 'fa-file-word';
    if (contentType.includes('excel') || contentType.includes('spreadsheet')) return 'fa-file-excel';

    return 'fa-file';
  }

  onTypeChange() {

    if (this.newTemplate.type === TemplateType.Text) {
      this.selectedFile = null;
      this.newTemplate.attachedFile = '';
      this.newTemplate.attachedFileContentType = '';
    } else {
      this.newTemplate.textContent = '';
    }
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  selectType(type: TemplateType) {
    this.newTemplate.type = type;
    this.isDropdownOpen = false;
    this.onTypeChange();
  }

  downloadTemplate(template: TemplateDTO) {
        const byteCharacters = atob(template.attachedFile!);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        const blob = new Blob([byteArray], { type: template.attachedFileContentType || 'application/octet-stream' });

        let extension = this.getFileExtension(template.attachedFileContentType!);

        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${template.name}${extension}`;
        document.body.appendChild(link);
        link.click();

        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        this.notificationService.showSuccess('File downloaded successfully!');

  }

  getFileExtension(mimeType: string): string {
    const mimeToExtension: { [key: string]: string } = {
      'application/pdf': '.pdf',
      'application/msword': '.doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
      'application/vnd.ms-excel': '.xls',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
      'application/vnd.ms-powerpoint': '.ppt',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
      'image/jpeg': '.jpg',
      'image/png': '.png',
      'image/gif': '.gif',
      'text/plain': '.txt',
      'text/csv': '.csv',

    };
    return mimeToExtension[mimeType] || '';
  }

  saveTemplate() {
    if (!this.newTemplate.code || !this.newTemplate.name) {
      this.notificationService.showError('Please fill all the fields.');
      return;
    }

    if (this.newTemplate.type === TemplateType.Text && !this.newTemplate.textContent) {
      this.notificationService.showError('Please enter text content .');
      return;
    }

    if (this.newTemplate.type === TemplateType.File && !this.selectedFile && !this.isEditMode) {
      this.notificationService.showError('Please select a file .');
      return;
    }


    if (!this.newTemplate.version) {
      this.newTemplate.version = 1;
    }

    const tenant = this.tenantSelection.selectedTenant();
    if (tenant) {
      this.newTemplate.tenant = tenant;
    }

    this.loadingService.show();

    if (this.isEditMode && this.editingTemplateId) {

      this.templateService.updateTemplate(this.editingTemplateId, this.newTemplate).subscribe({
        next: (res) => {
          this.loadingService.hide();
          this.notificationService.showSuccess('Template updated successfully!');
          this.closeModal();
          this.loadTemplates();
        },
        error: (errorInfo: ErrorInfo) => {
          this.loadingService.hide();
          console.error('Error updating template', errorInfo);
          this.notificationService.showError(errorInfo.message || 'Failed to update template.');
        }
      });
    } else {

      this.templateService.createTemplate(this.newTemplate).subscribe({
        next: (res) => {
          this.loadingService.hide();
          this.notificationService.showSuccess('Template created successfully!');
          this.closeModal();
          this.loadTemplates();
        },
        error: (errorInfo: ErrorInfo) => {
          this.loadingService.hide();
          console.error('Error creating template', errorInfo);
          this.notificationService.showError(errorInfo.message || 'Failed to create template.');
        }
      });
    }
  }
}
