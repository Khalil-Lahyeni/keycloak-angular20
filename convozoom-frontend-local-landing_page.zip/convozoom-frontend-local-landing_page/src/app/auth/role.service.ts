import { Injectable, inject } from '@angular/core';
import { TokenService } from './token.service';
import { environment } from '../../environments/environment';

type KeycloakToken = {
	resource_access?: Record<string, { roles?: string[] }>;
	realm_access?: { roles?: string[] };
	[claim: string]: any;
};

@Injectable({
	providedIn: 'root'
})
export class RoleService {
	private tokenService = inject(TokenService);

	private normalize(name: string): string {
		return (name || '').toLowerCase().replace(/[\s_-]+/g, '-');
	}

	async getAllRoles(): Promise<string[]> {
		const token = await this.tokenService.getParsedToken<KeycloakToken>();
		if (!token) return [];

		const realmRoles = token.realm_access?.roles ?? [];
		const clientRoles = Object.values(token.resource_access ?? {})
			.flatMap(r => r.roles ?? []);

		const all = [...realmRoles, ...clientRoles];
		return Array.from(new Set(all));
	}

	private isTechnicalRole(role: string): boolean {
		const r = this.normalize(role);
		return (
			r === 'uma-authorization' ||
			r === 'offline-access' ||
			r.startsWith('default-roles') ||
			r === 'manage-account' ||
			r === 'manage-account-links' ||
			r === 'view-profile' ||
			r === 'view-users' ||
			r === 'account-reader'
		);
	}

	async getDisplayableRoles(): Promise<string[]> {
		const all = await this.getAllRoles();
		return all.filter(r => !this.isTechnicalRole(r));
	}

	async getPrimaryDisplayableRole(): Promise<string | null> {
		const token = await this.tokenService.getParsedToken<KeycloakToken>();
		if (!token) return null;

		const clientId = environment.keycloak.clientId;
		const clientRoles = token.resource_access?.[clientId]?.roles ?? [];
		const preferred = clientRoles.find(r => !this.isTechnicalRole(r));
		if (preferred) return preferred;

		const realmRoles = token.realm_access?.roles ?? [];
		const realmPreferred = realmRoles.find(r => !this.isTechnicalRole(r));
		return realmPreferred ?? null;
	}

	async getRealmRoles(): Promise<string[]> {
		const token = await this.tokenService.getParsedToken<KeycloakToken>();
		return token?.realm_access?.roles ?? [];
	}

	async getClientRoles(clientId: string): Promise<string[]> {
		const token = await this.tokenService.getParsedToken<KeycloakToken>();
		if (!token || !token.resource_access) return [];
		return token.resource_access[clientId]?.roles ?? [];
	}

	async hasRole(role: string): Promise<boolean> {
		const wanted = this.normalize(role);
		const roles = await this.getAllRoles();
		return roles.some(r => this.normalize(r) === wanted);
	}

	async hasAnyRole(rolesToCheck: string[]): Promise<boolean> {
		const wanted = rolesToCheck.map(r => this.normalize(r));
		const roles = (await this.getAllRoles()).map(r => this.normalize(r));
		return wanted.some(w => roles.includes(w));
	}

	async getPrimaryManagementRole(): Promise<string | null> {
		// Backward compatibility alias -> now uses generic displayable role resolution
		return this.getPrimaryDisplayableRole();
	}

	getDisplayLabel(role: string | null): string {
		if (!role) return '';
		return role
			.split(/[-_\s]+/)
			.map(p => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase())
			.join(' ');
	}
}


