import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private darkMode = false;

  constructor() {}

  isDarkMode(): boolean {
    return this.darkMode;
  }

  toggleDarkMode(enable?: boolean): void {
    if (enable === undefined) {
      enable = !this.darkMode;
    }

    this.darkMode = enable;

    if (this.darkMode) {
      document.body.classList.add('pf-theme-dark');
    } else {
      document.body.classList.remove('pf-theme-dark');
    }
  }
}