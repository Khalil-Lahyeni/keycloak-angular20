import { Component, inject ,HostListener} from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { CommonModule } from '@angular/common';
import { RoleService } from './auth/role.service';
import { LoadingSpinnerComponent } from './components/loading-spinner/loading-spinner.component';
import { ThemeService } from '../themes/theme.service';
import { AppConfigService } from './config';
import { TenantSelectionService } from './services/tenant-selection-service';
import { TenantService } from './services/tenant-service';
import { Sidebar } from './sidebar/sidebar';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, LoadingSpinnerComponent, Sidebar],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  private themeService = inject(ThemeService)
  private authService = inject(AuthService);
  private roleService = inject(RoleService);
  private tenantService = inject(TenantService);
  private tenatSelectionService = inject(TenantSelectionService);
  private configService = inject(AppConfigService)
  isAuthenticated = false;
  userProfile: any = null;
  isSalesManager = false;
  isTenantAdmin = false;
  isSuperAdmin = false;
  managementLabel = '';
  isTenantMenuOpen = false;
  constructor() {
    this.checkAuthStatus();
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(_: MouseEvent) {
    this.isTenantMenuOpen = false;
  }

  toggleTenantMenu(event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isTenantMenuOpen = !this.isTenantMenuOpen;
  }

  closeTenantMenu() {
    this.isTenantMenuOpen = false;
  }

  private async checkAuthStatus() {
    try {
      this.isAuthenticated = await this.authService.isAuthenticated();
      if (this.isAuthenticated) {
        this.loadUserProfile();
        this.checkRole();
        this.computeManagementLabel();
        this.tenatSelectionService.extractAndStoreTenantCodeFromUrl();
        this.configService.getKeycloakRealm().subscribe(realm => {
          if (realm && realm !== 'convozoom') {
          this.tenantService.getTenantByCode(this.tenatSelectionService.getTenantCode()).subscribe(tenant => {   
            this.tenatSelectionService.setTenant(tenant);
          });
          }
        });

      }
    } catch (error) {
      console.error('Error checking auth status:', error);
      this.isAuthenticated = false;
    }
  }

  private async loadUserProfile() {
    try {
      this.userProfile = await this.authService.getUserProfile();
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  }

  private async checkRole() {
    try {
      this.isSalesManager = await this.authService.isSalesManager();
      this.isTenantAdmin = await this.authService.isTenantAdmin();
      this.isSuperAdmin = await this.authService.isSuperAdmin();
    } catch (error) {
      this.isSalesManager = false;
      this.isTenantAdmin = false;
      this.isSuperAdmin = false;
    }
  }

  private async computeManagementLabel() {
    const primary = await this.roleService.getPrimaryManagementRole();
    this.managementLabel = this.roleService.getDisplayLabel(primary);
  }

  async logout() {
    try {
      await this.authService.logout();
    } catch (error) {
      console.error('Error during logout:', error);
    }
  }
   get isDarkMode(): boolean {
    return this.themeService.isDarkMode();
  }

  toggleTheme(): void {
    this.themeService.toggleDarkMode();
  }
}
