package com.actia.mqttdemo.simulator;

import com.actia.mqttdemo.model.SensorData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.time.LocalDateTime;
import java.util.Random;

@Component
@ConditionalOnProperty(name = "simulator.enabled", havingValue = "true")
public class DeviceSimulator {

    private static final Logger log = LoggerFactory.getLogger(DeviceSimulator.class);

    @Value("${simulator.device.id}")
    private String deviceId;

    @Value("${simulator.broker.url}")
    private String brokerUrl;

    private MqttClient client;
    private final ObjectMapper objectMapper;
    private final Random random = new Random();
    private int publishCount = 0;

    // Simulate gradual changes
    private double currentTemp = 22.0;
    private double currentHumidity = 55.0;
    private double currentLat = 33.8815;    // Gabès, Tunisia 🇹🇳
    private double currentLng = 10.0982;

    public DeviceSimulator() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @PostConstruct
    public void init() {
        try {
            client = new MqttClient(brokerUrl, deviceId + "-simulator", new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setAutomaticReconnect(true);
            client.connect(options);

            log.info("╔═══════════════════════════════════════════╗");
            log.info("║   🚀 Device Simulator Started             ║");
            log.info("║   Device ID : {}              ║", deviceId);
            log.info("║   Broker    : {}     ║", brokerUrl);
            log.info("╚═══════════════════════════════════════════╝");

            // Publish initial status
            publishStatus("ONLINE");

        } catch (Exception e) {
            log.error("❌ Simulator failed to connect: {}", e.getMessage());
        }
    }

    @Scheduled(fixedDelayString = "${simulator.interval.ms}")
    public void publishSensorData() {
        if (client == null || !client.isConnected()) {
            log.warn("⚠️ Simulator not connected, skipping...");
            return;
        }

        try {
            publishCount++;

            // Rotate through different sensor types
            switch (publishCount % 4) {
                case 0 -> publishTemperature();
                case 1 -> publishHumidity();
                case 2 -> publishGps();
                case 3 -> publishStatus(randomStatus());
            }
        } catch (Exception e) {
            log.error("❌ Simulator publish error: {}", e.getMessage());
        }
    }

    // ─── Publishers ──────────────────────────────────────────

    private void publishTemperature() throws Exception {
        // Simulate gradual temperature change with noise
        currentTemp += (random.nextDouble() - 0.48) * 2;  // slight upward bias
        currentTemp = Math.max(15, Math.min(50, currentTemp));

        SensorData data = SensorData.builder()
                .deviceId(deviceId)
                .sensorType("temperature")
                .value(Math.round(currentTemp * 100.0) / 100.0)
                .unit("°C")
                .timestamp(LocalDateTime.now())
                .build();

        publish("devices/temperature", data);
        log.info("🌡️  [SIM] Published temperature: {} °C", data.getValue());
    }

    private void publishHumidity() throws Exception {
        currentHumidity += (random.nextDouble() - 0.5) * 5;
        currentHumidity = Math.max(20, Math.min(95, currentHumidity));

        SensorData data = SensorData.builder()
                .deviceId(deviceId)
                .sensorType("humidity")
                .value(Math.round(currentHumidity * 100.0) / 100.0)
                .unit("%")
                .timestamp(LocalDateTime.now())
                .build();

        publish("devices/humidity", data);
        log.info("💧 [SIM] Published humidity: {} %", data.getValue());
    }

    private void publishGps() throws Exception {
        // Simulate small movement around Gabès
        currentLat += (random.nextDouble() - 0.5) * 0.001;
        currentLng += (random.nextDouble() - 0.5) * 0.001;

        SensorData data = SensorData.builder()
                .deviceId(deviceId)
                .sensorType("gps")
                .value(0)
                .latitude(Math.round(currentLat * 10000.0) / 10000.0)
                .longitude(Math.round(currentLng * 10000.0) / 10000.0)
                .timestamp(LocalDateTime.now())
                .build();

        publish("devices/gps", data);
        log.info("📍 [SIM] Published GPS: {}, {}", data.getLatitude(), data.getLongitude());
    }

    private void publishStatus(String status) {
        try {
            SensorData data = SensorData.builder()
                    .deviceId(deviceId)
                    .sensorType("status")
                    .value(0)
                    .status(status)
                    .timestamp(LocalDateTime.now())
                    .build();

            publish("devices/status", data);
            log.info("📊 [SIM] Published status: {}", status);
        } catch (Exception e) {
            log.error("❌ Failed to publish status: {}", e.getMessage());
        }
    }

    private void publish(String topic, SensorData data) throws Exception {
        String json = objectMapper.writeValueAsString(data);
        MqttMessage message = new MqttMessage(json.getBytes());
        message.setQos(1);
        message.setRetained(false);
        client.publish(topic, message);
    }

    // ─── Helpers ─────────────────────────────────────────────

    private String randomStatus() {
        String[] statuses = {"ONLINE", "ONLINE", "ONLINE", "MAINTENANCE", "ERROR"};
        return statuses[random.nextInt(statuses.length)];
    }

    @PreDestroy
    public void cleanup() {
        try {
            if (client != null && client.isConnected()) {
                publishStatus("OFFLINE");
                Thread.sleep(500); // let it send
                client.disconnect();
                log.info("🔌 Simulator disconnected");
            }
        } catch (Exception e) {
            log.error("Error during cleanup: {}", e.getMessage());
        }
    }
}
