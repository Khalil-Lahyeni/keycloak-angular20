import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Lead } from '../models/lead.model';

@Component({
  selector: 'app-lead-card',
  imports: [CommonModule],
  templateUrl: './lead-card.html',
  styleUrl: './lead-card.css'
})
export class LeadCard {
  @Input() lead!: Lead;
  @Input() color!: string;
  @Output() clicked = new EventEmitter<Lead>();

  onCardClick() {
    this.clicked.emit(this.lead);
  }
}
