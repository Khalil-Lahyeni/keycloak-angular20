import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

export const authGuard: CanActivateFn = async (route, state) => {
	const authService = inject(AuthService);
	const router = inject(Router);

	try {
		const authenticated = await authService.isAuthenticated();

		if (!authenticated) {
			await authService.loginRedirect(window.location.origin + state.url);
			return false;
		}

		const disallowRoles = (route.data && (route.data['disallowRoles'] as string[])) || [];
		const allowRoles = (route.data && (route.data['allowRoles'] as string[])) || [];
		if (disallowRoles.length) {
			const hasDisallowed = await authService.hasAnyRole(disallowRoles);
			if (hasDisallowed) {
				await router.navigate(['/home']);
				return false;
			}
		}

		if (allowRoles.length) {
			const hasAllowed = await authService.hasAnyRole(allowRoles);
			if (!hasAllowed) {
				await router.navigate(['/home']);
				return false;
			}
		}

		return true;
	} catch (error) {
		console.error('Auth guard error:', error);
		await authService.loginRedirect(window.location.origin + '/home');
		return false;
	}
};
