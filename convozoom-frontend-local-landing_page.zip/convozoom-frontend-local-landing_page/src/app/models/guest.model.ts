/**
 * Guest Data Transfer Object
 * Represents a guest user who will join a meeting via token link
 * Note: leadId and tenantId are now passed via URL query params, not in the DTO
 */
export interface GuestDTO {
  id?: string;
  name: string;
  accessToken: string;
  email: string;
  agenda?: AgendaDTO[];
}

/**
 * LiveKit Token Response from AI API
 */
export interface LiveKitTokenResponse {
  token: string;
  url: string;
  room_name: string;
}

/**
 * LiveKit Token Request Payload
 */
export interface LiveKitTokenRequest {
  lead_id: string;
  tenant_id: string;
  lead_name: string;
  ttl?: number;
  metadata?: { [key: string]: any };
}
export interface TranscriptionMessage {
  id: string;
  participantName: string;
  text: string;
  timestamp: Date;
  isFinal: boolean;
}

/**
 * Chat Message Interface
 * Represents a chat message sent/received via LiveKit Data Channel
 */
export interface ChatMessage {
  id: string;
  text: string;
  senderIdentity: string;
  senderName: string;
  timestamp: Date;
  isLocal: boolean;  // true if sent by current user
}
// Enum des statuts simplifiés pour la vue liste
export enum AgendaStatus {
  Planified = 'Planified',
  InProgress = 'InProgress',
  Closed = 'Closed'
}

/**
 * Agenda Data Transfer Object
 * Represents a scheduled appointment/meeting
 */
export interface AgendaDTO {
  id?: string;
  leadId?: string;
  tenantId?: string;
  roomId?: string;
  projectName?: string;
  tenantName?: string;
  date: string;        // Format ISO: "2025-11-15T14:30:00"
  type?: 'Call';       // Optional - default is Call
  state?: AgendaStatus; // Optional - default is Planified
  guest: GuestDTO;     // Required - guest information
}

