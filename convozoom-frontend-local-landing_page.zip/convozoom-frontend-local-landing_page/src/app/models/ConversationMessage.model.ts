
export interface ConversationMessage {
  id: string;
  sender: string;
  content: string;
  type: 'user' | 'assistant';
  timestamp?: string;
}