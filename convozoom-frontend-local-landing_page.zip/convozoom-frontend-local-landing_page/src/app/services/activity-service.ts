import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../config';
import { ErrorHandlerService } from './error-handler.service';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { catchError, Observable, throwError, forkJoin, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Activity } from '../models/activity.model';

@Injectable({
  providedIn: 'root'
})
export class ActivityService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllActivities(): Observable<Activity[]> {
    return this.http.get<Activity[]>(`${this.base}/activities`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllActivities');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving activity');
        return throwError(() => errorInfo);
      })
    );
  }

  getActivityById(id: string): Observable<Activity> {
    return this.http.get<Activity>(`${this.base}/activities/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getActivity');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the activity');
        return throwError(() => errorInfo);
      })
    );
  }

  createActivity(body: Activity): Observable<Activity> {
    return this.http.post<Activity>(`${this.base}/activities`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createActivity');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the activity');
        return throwError(() => errorInfo);
      })
    );
  }

  updateActivity(id: string, body: Activity): Observable<Activity> {
    return this.http.put<Activity>(`${this.base}/activities/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateActivity');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the activity');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteActivity(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/activities/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteActivity');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the activity');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateActivity(id: string, body: Partial<Activity>): Observable<Activity> {
    return this.http.patch<Activity>(`${this.base}/activities/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateActivity');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the activity');
        return throwError(() => errorInfo);
      })
    );
  }

  getActivitiesByLeadId(leadId: string): Observable<Activity[]> {
    let params = new HttpParams().set('leadId', leadId);
    return this.http.get<Activity[]>(`${this.base}/activities`, { params }).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getActivitiesByLeadId');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving activities for lead');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteActivitiesByLeadId(leadId: string): Observable<void> {
    return this.getActivitiesByLeadId(leadId).pipe(
      switchMap((activities: Activity[]) => {
        if (activities.length === 0) {
          return of(void 0);
        }
        const deleteRequests = activities.map(activity => 
          this.deleteActivity(activity.id || '')
        );
        return forkJoin(deleteRequests);
      }),
      switchMap(() => of(void 0)),
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteActivitiesByLeadId');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting activities');
        return throwError(() => errorInfo);
      })
    );
  }
}
