import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { AgendaDTO } from '../models/guest.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({ providedIn: 'root' })
export class AgendaService {
  private appConfigService = inject(AppConfigService);
  private apiBaseUrl: string = '';

  constructor(
    private http: HttpClient,
    private errorHandler: ErrorHandlerService
  ) {
    // Get API base URL from configuration
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.apiBaseUrl = url || '';
    });
  }

  /**
   * Creates a new agenda/appointment
   * @param agendaData - AgendaDTO with date and guest (required fields)
   * @returns Observable<AgendaDTO>
   */
  createAgenda(agendaData: AgendaDTO): Observable<AgendaDTO> {
    return this.http.post<AgendaDTO>(`${this.apiBaseUrl}/agenda`, agendaData).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createAgenda');
        return throwError(() => new Error('Failed to create appointment. Please try again.'));
      })
    );
  }

  /**
   * Gets all agenda/appointments
   * @returns Observable<AgendaDTO[]>
   */
  getAllAgenda(): Observable<AgendaDTO[]> {
    return this.http.get<AgendaDTO[]>(`${this.apiBaseUrl}/agenda`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllAgenda');
        return throwError(() => new Error('Failed to fetch appointments.'));
      })
    );
  }

  /**
   * Updates an existing agenda by id
   * Only pass the fields you want to modify (e.g. state, roomId)
   * @param id Agenda identifier
   * @param updates Partial agenda fields to update
   */
  updateAgenda(id: string, updates: Partial<AgendaDTO>): Observable<AgendaDTO> {
    if (!id) {
      return throwError(() => new Error('Agenda id is required for update'));
    }
    return this.http.put<AgendaDTO>(`${this.apiBaseUrl}/agenda/${id}`, updates).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, `updateAgenda ${id}`);
        return throwError(() => new Error('Failed to update agenda.'));
      })
    );
  }
}
