import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { TenantDTO, TenantType } from '../models/tenant.model';
import { catchError, map, Observable, of, throwError, tap } from 'rxjs';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({ providedIn: 'root' })
export class TenantService {
  appConfigService = inject(AppConfigService);
  private  base : string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) { 
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getTenantByCode(code: string): Observable<TenantDTO> {
    return this.http.get<TenantDTO>(`${this.base}/tenants/code/${code}`).pipe(
      tap(tenant => {
        if (tenant?.id) {
          // Persist tenantId for future refreshes
          if (typeof localStorage !== 'undefined') {
            try { localStorage.setItem('tenantId', tenant.id); } catch { /* ignore */ }
          }
        }
      }),
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, `getTenantByCode ${code}`);
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'get');
        return throwError(() => errorInfo);
      })
    );
  }


  getAllTenants(): Observable<TenantDTO[]> {

    return this.http.get<TenantDTO[]>(`${this.base}/tenants`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllTenants');
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'get');
        return throwError(() => errorInfo);
      })
    );
  }

  createTenant(tenant: TenantDTO): Observable<TenantDTO> {
    return this.http.post<TenantDTO>(`${this.base}/tenants`, tenant).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createTenant');
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'create');
        return throwError(() => errorInfo);
      })
    );
  }

  updateTenant(id: string, tenant: TenantDTO): Observable<TenantDTO> {
    return this.http.put<TenantDTO>(`${this.base}/tenants/${id}`, tenant).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, `updateTenant ${id}`);
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'update');
        return throwError(() => errorInfo);
      })
    );
  }
}
