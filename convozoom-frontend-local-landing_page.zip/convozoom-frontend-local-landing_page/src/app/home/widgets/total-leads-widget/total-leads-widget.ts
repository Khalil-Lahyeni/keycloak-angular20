import { Component, OnInit, Output, EventEmitter, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { LeadService } from '../../../services/lead-service';
import { Lead, LeadStatus } from '../../../models/lead.model';

interface StatusCount {
  status: string;
  count: number;
  color: string;
}

@Component({
  selector: 'app-total-leads-widget',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './total-leads-widget.html',
  styleUrl: './total-leads-widget.css'
})
export class TotalLeadsWidgetComponent implements OnInit {
  private leadService = inject(LeadService);
  
  @Input() editMode: boolean = false;
  @Output() remove = new EventEmitter<void>();
  
  totalLeads: number = 0;
  percentageChange: number = 0;
  isPositive: boolean = false;
  statusCounts: StatusCount[] = [];
  isLoading: boolean = true;

  // Color mapping for statuses
  private statusColors: { [key: string]: string } = {
    'New': '#7B61FF',
    'Contacted': '#9B7DFF',
    'Qualified': '#5E4DB2',
    'Converted': '#403294'
  };

  ngOnInit(): void {
    this.loadData();
  }

  private loadData(): void {
    this.isLoading = true;
    this.leadService.getAllLeads().subscribe({
      next: (leads) => {
        this.calculateStats(leads);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading leads:', err);
        this.isLoading = false;
      }
    });
  }

  private calculateStats(leads: Lead[]): void {
    this.totalLeads = leads.length;
    
    // Count leads by status
    const statusMap = new Map<string, number>();
    leads.forEach(lead => {
      const status = lead.status || 'New';
      statusMap.set(status, (statusMap.get(status) || 0) + 1);
    });

    // Build status counts array
    this.statusCounts = [];
    const statusOrder = ['New', 'Contacted', 'Qualified', 'Converted'];
    
    statusOrder.forEach(status => {
      const count = statusMap.get(status) || 0;
      if (count > 0 || status === 'New') {
        this.statusCounts.push({
          status,
          count,
          color: this.statusColors[status] || '#8B8B8B'
        });
      }
    });

    // Calculate percentage change (this month vs last month)
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    
    const thisMonthLeads = leads.filter(lead => new Date(lead.createdAt) >= thisMonth).length;
    const lastMonthLeads = leads.filter(lead => {
      const createdAt = new Date(lead.createdAt);
      return createdAt >= lastMonth && createdAt < thisMonth;
    }).length;

    if (lastMonthLeads > 0) {
      this.percentageChange = ((thisMonthLeads - lastMonthLeads) / lastMonthLeads) * 100;
    } else if (thisMonthLeads > 0) {
      this.percentageChange = 100;
    } else {
      this.percentageChange = 0;
    }
    
    this.percentageChange = Math.round(this.percentageChange * 10) / 10;
    this.isPositive = this.percentageChange >= 0;
  }

  getStatusWidth(count: number): number {
    if (this.totalLeads === 0) return 0;
    return (count / this.totalLeads) * 100;
  }

  onRemove(): void {
    this.remove.emit();
  }
}
