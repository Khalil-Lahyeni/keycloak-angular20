import { Component, inject } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
    <div class="profile-container">
      <h1>User Profile</h1>
      <p>Detailed information about the authenticated user.</p>

      <div class="profile-card" *ngIf="userProfile">
        <div class="profile-header">
          <h2>{{ userProfile.firstName }} {{ userProfile.lastName }}</h2>
          <span class="username">@{{ userProfile.username }}</span>
        </div>

        <div class="profile-details">
          <div class="detail-item">
            <label>Email:</label>
            <span>{{ userProfile.email }}</span>
          </div>

          <div class="detail-item">
            <label>First Name:</label>
            <span>{{ userProfile.firstName }}</span>
          </div>

          <div class="detail-item">
            <label>Last Name:</label>
            <span>{{ userProfile.lastName }}</span>
          </div>

          <div class="detail-item">
            <label>Email Verified:</label>
            <span [class]="userProfile.emailVerified ? 'verified' : 'not-verified'">
              {{ userProfile.emailVerified ? 'Yes' : 'No' }}
            </span>
          </div>
        </div>

        <div class="profile-actions">
          <button (click)="refreshProfile()" class="refresh-btn">Refresh Profile</button>
          <button (click)="logout()" class="logout-btn">Logout</button>
        </div>
      </div>

      <div class="navigation">
        <a routerLink="/home" class="nav-link">Back to Home</a>
        <a routerLink="/protected" class="nav-link">Protected Page</a>
      </div>
    </div>
  `,
  styles: [`
    .profile-container {
      padding: 2rem;
      text-align: center;
    }

    .profile-card {
      max-width: 500px;
      margin: 2rem auto;
      padding: 2rem;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      text-align: left;
    }

    .profile-header {
      text-align: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid #e9ecef;
    }

    .profile-header h2 {
      margin: 0 0 0.5rem 0;
      color: #333;
    }

    .username {
      color: #6c757d;
      font-size: 1.1rem;
    }

    .profile-details {
      margin-bottom: 2rem;
    }

    .detail-item {
      display: flex;
      justify-content: space-between;
      padding: 0.75rem 0;
      border-bottom: 1px solid #f8f9fa;
    }

    .detail-item label {
      font-weight: 600;
      color: #495057;
    }

    .verified {
      color: #28a745;
      font-weight: 600;
    }

    .not-verified {
      color: #dc3545;
      font-weight: 600;
    }

    .profile-actions {
      display: flex;
      gap: 1rem;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .refresh-btn {
      padding: 0.75rem 1.5rem;
      background: #17a2b8;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .refresh-btn:hover {
      background: #138496;
    }

    .logout-btn {
      padding: 0.75rem 1.5rem;
      background: #dc3545;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .logout-btn:hover {
      background: #c82333;
    }

    .navigation {
      display: flex;
      gap: 1rem;
      justify-content: center;
    }

    .nav-link {
      padding: 0.75rem 1.5rem;
      background: #6c757d;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      transition: background 0.3s;
    }

    .nav-link:hover {
      background: #5a6268;
    }
  `]
})
export class ProfileComponent {
  private authService = inject(AuthService);
  userProfile: any = null;

  constructor() {
    this.loadUserProfile();
  }

  async loadUserProfile() {
    try {
      this.userProfile = await this.authService.getUserProfile();
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  }

  async refreshProfile() {
    await this.loadUserProfile();
  }

  async logout() {
    try {
      await this.authService.logout();
    } catch (error) {
      console.error('Error during logout:', error);
    }
  }
}
