import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { ContactDTO } from '../models/contact.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({ providedIn: 'root' })
export class ContactService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllContacts(tenantId: string): Observable<ContactDTO[]> {
    return this.http.get<ContactDTO[]>(`${this.base}/contacts/tenant/${tenantId}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllContacts');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving contacts');
        return throwError(() => errorInfo);
      })
    );
  }

  createContact(body: ContactDTO): Observable<ContactDTO> {
    return this.http.post<ContactDTO>(`${this.base}/contacts`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createContact');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the contact');
        return throwError(() => errorInfo);
      })
    );
  }
}
