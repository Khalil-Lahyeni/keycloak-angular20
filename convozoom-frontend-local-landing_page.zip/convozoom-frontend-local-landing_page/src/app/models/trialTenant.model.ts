/**
 * Interface for trial tenant creation payload
 */
export interface TrialTenantPayload {
    id?: string;
    code?: string;
	firstname: string;
	lastname: string;
	email?: string;
	type: 'Agency' | 'Broker' | 'Developer' | 'Investor';
	password: string;
    url?: string;

}