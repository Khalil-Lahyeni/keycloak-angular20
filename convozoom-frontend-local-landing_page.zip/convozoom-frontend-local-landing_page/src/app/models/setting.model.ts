import { TenantDTO } from "./tenant.model";

export enum SettingKey {
  Language = 'Language',
  TemplatePath = 'TemplatePath',
  Realm = 'Realm',
  ClientId = 'ClientId',
  ClientSecret = 'ClientSecret',
}

export enum SettingType {
  Global = 'Global',
  CRM = 'CRM',
  DLD = 'DLD',
  Security = 'Security',
}

export interface SettingDTO {
  id?: string;
  key: SettingKey;
  value: string;
  type: SettingType;
  actionName?: string | null;
  actionDone?: boolean;
  system?: boolean;
  tenant?: TenantDTO;
}
