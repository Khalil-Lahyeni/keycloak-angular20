import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { HttpClient } from '@angular/common/http';
import { RouterLink, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { filter, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-protected',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
    <div class="protected-container">
      <h1>Protected Page</h1>
      <p>This page is only accessible to authenticated users.</p>

      <div class="user-info" *ngIf="userProfile">
        <h3>User Information</h3>
        <p><strong>Username:</strong> {{ userProfile.username }}</p>
        <p><strong>Email:</strong> {{ userProfile.email }}</p>
        <p><strong>First Name:</strong> {{ userProfile.firstName }}</p>
        <p><strong>Last Name:</strong> {{ userProfile.lastName }}</p>
      </div>

             <div class="test-api">
         <button (click)="testBackend()" class="test-btn">Test Backend API</button>
         <button (click)="testProxy()" class="test-btn" style="background: #ffc107; color: black;">Test Proxy</button>
         <div class="test-result" *ngIf="backendMessage">
           <strong>Response:</strong> {{ backendMessage }}
         </div>
         <div class="test-error" *ngIf="backendError">
           <strong>Error:</strong> {{ backendError }}
         </div>
       </div>

      <div class="rbac-test">
        <h3>Role-Based Access Control (RBAC) Testing</h3>
        <div *ngIf="isLoading" class="loading">
          <p>Loading user roles...</p>
        </div>
        <div *ngIf="!isLoading">
          <p><strong>Your Current Roles:</strong> {{ userRoles.join(', ') || 'None' }}</p>
          
          <div class="role-buttons">
            <button 
              *ngFor="let role of availableRoles" 
              (click)="testRoleAccess(role)"
              [class]="'role-btn ' + (userRoles.includes(role) ? 'has-role' : 'no-role')"
              [disabled]="!userRoles.includes(role)">
              Test {{ role | titlecase }}
            </button>
          </div>

          <div class="role-results">
            <div *ngFor="let result of roleResults" class="role-result">
              <strong>{{ result.role | titlecase }}:</strong>
              <span [class]="result.success ? 'success' : 'error'">
                {{ result.message }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div class="actions">
        <button (click)="logout()" class="logout-btn">Logout</button>
        <a routerLink="/home" class="nav-link">Back to Home</a>
      </div>
    </div>
  `,
  styles: [`
    .protected-container {
      padding: 2rem;
      text-align: center;
    }

    .user-info {
      margin: 2rem 0;
      padding: 1rem;
      background: #f8f9fa;
      border-radius: 8px;
      text-align: left;
      max-width: 400px;
      margin-left: auto;
      margin-right: auto;
    }

    .loading {
      padding: 1rem;
      color: #6c757d;
      font-style: italic;
    }

    .actions {
      margin-top: 2rem;
      display: flex;
      gap: 1rem;
      justify-content: center;
    }

    .logout-btn {
      padding: 0.75rem 1.5rem;
      background: #dc3545;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .logout-btn:hover {
      background: #c82333;
    }

    .nav-link {
      padding: 0.75rem 1.5rem;
      background: #6c757d;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      transition: background 0.3s;
    }

    .nav-link:hover {
      background: #5a6268;
    }

    .test-api {
      margin: 2rem 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.75rem;
    }

    .test-btn {
      padding: 0.75rem 1.5rem;
      background: #198754;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .test-btn:hover {
      background: #157347;
    }

    .test-result, .test-error {
      background: #f8f9fa;
      padding: 0.75rem 1rem;
      border-radius: 6px;
      max-width: 600px;
      width: 100%;
    }
    .test-error { color: #dc3545; }

    .rbac-test {
      margin: 2rem 0;
      padding: 1.5rem;
      background: #f8f9fa;
      border-radius: 8px;
      border: 1px solid #dee2e6;
    }

    .rbac-test h3 {
      margin: 0 0 1rem 0;
      color: #333;
    }

    .role-buttons {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin: 1rem 0;
    }

    .role-btn {
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.3s;
    }

    .role-btn.has-role {
      background: #198754;
      color: white;
    }

    .role-btn.has-role:hover {
      background: #157347;
    }

    .role-btn.no-role {
      background: #6c757d;
      color: white;
      cursor: not-allowed;
      opacity: 0.6;
    }

    .role-btn:disabled {
      cursor: not-allowed;
      opacity: 0.6;
    }

    .role-results {
      margin-top: 1rem;
    }

    .role-result {
      padding: 0.5rem;
      margin: 0.25rem 0;
      border-radius: 4px;
      background: white;
    }

    .role-result .success {
      color: #198754;
    }

    .role-result .error {
      color: #dc3545;
    }
  `]
})
export class ProtectedComponent implements OnInit, OnDestroy {
  private authService = inject(AuthService);
  private http = inject(HttpClient);
  private router = inject(Router);
  private destroy$ = new Subject<void>();
  
  userProfile: any = null;
  backendMessage: string | null = null;
  backendError: string | null = null;
  userRoles: string[] = [];
  availableRoles = ['auditor', 'marketing', 'sales_agent', 'sales_manager', 'tenant_admin'];
  roleResults: Array<{role: string, success: boolean, message: string}> = [];
  isLoading = true;

  constructor() {
    // Listen to navigation events to reload data when navigating to this component
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd),
      takeUntil(this.destroy$)
    ).subscribe(() => {
      // Check if we're on the protected route
      if (this.router.url.includes('/protected')) {
        this.loadUserProfile();
      }
    });
  }

  async ngOnInit() {
    await this.loadUserProfile();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  async loadUserProfile() {
    console.log('Loading user profile...');
    this.isLoading = true;
    try {
      this.userProfile = await this.authService.getUserProfile();
      this.userRoles = await this.authService.getUserRoles();
      console.log('Loaded user roles:', this.userRoles);
    } catch (error) {
      console.error('Error loading user profile:', error);
    } finally {
      this.isLoading = false;
      console.log('Finished loading user profile, isLoading:', this.isLoading);
    }
  }

  async logout() {
    try {
      await this.authService.logout();
    } catch (error) {
      console.error('Error during logout:', error);
    }
  }

    async testBackend() {
    this.backendMessage = null;
    this.backendError = null;

    try {
      const token = await this.authService.getToken();
      const headers = { 'Authorization': `Bearer ${token}` };

      this.http.get('/api/v1/business-test', { 
        responseType: 'text',
        headers: headers
      }).subscribe({
        next: (msg: string) => { alert('Success: ' + msg); this.backendMessage = msg + ' — the API calls succeed with 200.'; },
        error: (err) => { this.backendError = err?.error || 'Request failed'; }
      });
    } catch (error) {
      console.error('Error getting token:', error);
      this.backendError = 'Failed to get authentication token';
    }
  }

  async testRoleAccess(role: string) {
    const endpoint = `/api/v1/business-test/${role}`;
    
    try {
      const token = await this.authService.getToken();
      const headers = { 'Authorization': `Bearer ${token}` };

      // Add debug logging
      console.log('Making request to:', endpoint);
      console.log('With token:', token ? 'Token present' : 'No token');

      this.http.get(endpoint, { 
        responseType: 'text',
        headers: headers
      }).subscribe({
        next: (response: string) => {
          console.log('Success response:', response);
          this.updateRoleResult(role, true, response + ' — the API calls succeed with 200.');
        },
        error: (err) => {
          console.error(`Error testing ${role}:`, err);
          console.error('Full error details:', JSON.stringify(err, null, 2));
          const errorMsg = err?.error || err?.message || 'Access denied';
          this.updateRoleResult(role, false, errorMsg);
        }
      });
    } catch (error) {
      console.error('Error getting token:', error);
      this.updateRoleResult(role, false, 'Failed to get authentication token');
    }
  }

  // Add a simple proxy test method
  testProxy() {
    console.log('Testing proxy...');
    this.http.get('/api/v1/business-test', { responseType: 'text' })
      .subscribe({
        next: (response) => {
          console.log('Proxy test success:', response);
          alert('Proxy is working! Response: ' + response);
        },
        error: (err) => {
          console.error('Proxy test failed:', err);
          alert('Proxy test failed: ' + JSON.stringify(err));
        }
      });
  }

  private updateRoleResult(role: string, success: boolean, message: string) {
    // Remove existing result for this role
    this.roleResults = this.roleResults.filter(r => r.role !== role);
    // Add new result
    this.roleResults.push({ role, success, message });
  }
}
