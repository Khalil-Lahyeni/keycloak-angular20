import { Component, inject, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DragDropModule, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { TotalLeadsWidgetComponent } from '../widgets/total-leads-widget/total-leads-widget';
import { MyLeadsWidgetComponent } from '../widgets/my-leads-widget/my-leads-widget';

interface Widget {
  id: string;
  type: 'total-leads' | 'my-leads' | 'my-deals' | 'meetings' | 'demography' | 'pipeline';
  visible: boolean;
}

@Component({
  selector: 'app-dashboard-edit',
  standalone: true,
  imports: [
    RouterLink,
    CommonModule,
    DragDropModule,
    TotalLeadsWidgetComponent,
    MyLeadsWidgetComponent
  ],
  templateUrl: './dashboard-edit.html',
  styleUrl: './dashboard-edit.css'
})
export class DashboardEditComponent implements OnInit {
  private router = inject(Router);
  
  widgets: Widget[] = [];
  availableWidgets: Widget[] = [];

  ngOnInit(): void {
    this.loadWidgets();
  }

  private loadWidgets(): void {
    // Load from localStorage or use defaults
    const saved = localStorage.getItem('dashboard-widgets');
    if (saved) {
      const parsed = JSON.parse(saved);
      this.widgets = parsed.widgets || [];
      this.availableWidgets = parsed.availableWidgets || [];
    } else {
      // Default widgets
      this.widgets = [
        { id: 'total-leads', type: 'total-leads', visible: true },
        { id: 'my-leads', type: 'my-leads', visible: true }
      ];
      this.availableWidgets = [
        { id: 'my-deals', type: 'my-deals', visible: false },
        { id: 'meetings', type: 'meetings', visible: false },
        { id: 'demography', type: 'demography', visible: false },
        { id: 'pipeline', type: 'pipeline', visible: false }
      ];
    }
  }

  private saveWidgets(): void {
    localStorage.setItem('dashboard-widgets', JSON.stringify({
      widgets: this.widgets,
      availableWidgets: this.availableWidgets
    }));
  }

  onDrop(event: CdkDragDrop<Widget[]>): void {
    moveItemInArray(this.widgets, event.previousIndex, event.currentIndex);
    this.saveWidgets();
  }

  removeWidget(widgetId: string): void {
    const widget = this.widgets.find(w => w.id === widgetId);
    if (widget) {
      widget.visible = false;
      this.widgets = this.widgets.filter(w => w.id !== widgetId);
      this.availableWidgets.push(widget);
      this.saveWidgets();
    }
  }

  addWidget(widget: Widget): void {
    widget.visible = true;
    this.widgets.push(widget);
    this.availableWidgets = this.availableWidgets.filter(w => w.id !== widget.id);
    this.saveWidgets();
  }

  getWidgetLabel(type: string): string {
    const labels: { [key: string]: string } = {
      'total-leads': 'Total Leads',
      'my-leads': 'My Leads',
      'my-deals': 'My Deals',
      'meetings': 'Meetings',
      'demography': 'Demography',
      'pipeline': 'Pipeline Value'
    };
    return labels[type] || type;
  }

  done(): void {
    this.saveWidgets();
    this.router.navigate(['/home']);
  }
}
