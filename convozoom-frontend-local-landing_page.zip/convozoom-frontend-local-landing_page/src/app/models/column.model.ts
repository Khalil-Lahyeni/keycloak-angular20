export class Column<T> {
  status: string;
  tasks: T[] = [];
  bgColor: string;
  textColor: string;
  countColor: string;
  isEditing?: boolean;

  constructor(status: string, bgColor: string, textColor: string, countColor: string) {
    this.status = status;
    this.bgColor = bgColor;
    this.textColor = textColor;
    this.countColor = countColor; 
  }
}
