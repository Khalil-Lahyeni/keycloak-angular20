import { Injectable, inject } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';

@Injectable({
	providedIn: 'root'
})
export class TokenService {
	private keycloakService = inject(KeycloakService);

	async getRawToken(): Promise<string | null> {
		try {
			const token = await this.keycloakService.getToken();
			if (token) return token;
		} catch (_) {
			// ignore and fall back to local storage
		}
		const local = localStorage.getItem('keycloak_token');
		return local || null;
	}

	async getParsedToken<T extends Record<string, any> = any>(): Promise<T | null> {
		const raw = await this.getRawToken();
		if (!raw) return null;
		try {
			const payload = raw.split('.')[1] || '';
			const json = this.base64UrlDecode(payload);
			return JSON.parse(json) as T;
		} catch (error) {
			console.error('Failed to parse token payload', error);
			return null;
		}
	}

	private base64UrlDecode(input: string): string {
		// Replace URL-safe chars and pad
		let base64 = input.replace(/-/g, '+').replace(/_/g, '/');
		const padding = base64.length % 4;
		if (padding === 2) base64 += '==';
		else if (padding === 3) base64 += '=';
		else if (padding !== 0 && padding !== 2 && padding !== 3) {
			// invalid padding length
		}
		try {
			return decodeURIComponent(
				atob(base64)
					.split('')
					.map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
					.join('')
			);
		} catch (_) {
			// Fallback if decodeURIComponent fails
			return atob(base64);
		}
	}
}


