(function () {
  'use strict';

  function realmFromHostOrPath() {
    var host = window.location.hostname; 
    var parts = host.split('.');  
    const firstPart = parts[0];
    if (firstPart.startsWith('trial-')) {
      return 'convo-trial';
    }
    const realm = (firstPart !== 'convozoom' && firstPart !== 'auth' && firstPart !== 'localhost') ? firstPart : 'convozoom';
	  return realm;
  }

  window.__RUNTIME_CONFIG__ = {
    KEYCLOAK_URL: 'https://convozoom.com/auth',
    KEYCLOAK_REALM: realmFromHostOrPath(),
    KEYCLOAK_CLIENT_ID: 'convo-front-clientid',
    API_BASE_URL: 'https://convozoom.com/gatewayApi',
	  API_AI_BASE_URL: 'https://convozoom.com/aiApi',
    ENVIRONMENT: 'development',
    DEBUG_MODE: 'true'
  };
})();