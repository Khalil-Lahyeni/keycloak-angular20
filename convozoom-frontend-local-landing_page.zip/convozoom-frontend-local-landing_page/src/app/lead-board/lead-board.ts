import { Component, Input, ViewChild, ElementRef, HostListener } from '@angular/core';
import { Column } from '../models/column.model';
import { CdkDragDrop, DragDropModule, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Lead, LeadStatus } from '../models/lead.model';
import { LeadList } from './lead-list';
import { LeadModalComponent } from '../lead-modal-component/lead-modal-component';
import { LeadService } from '../services/lead-service';
import { ActivityService } from '../services/activity-service';
import { Activity, ActivityType } from '../models/activity.model';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { interval, Subscription } from 'rxjs';
import { CardComponent } from '../card-component/card-component';
import { ToolbarComponent } from '../toolbar-component/toolbar-component';

type SortByType = 'Name' | 'Status' | 'Updated' | 'Created';

@Component({
  selector: 'app-lead-board',
  imports: [CommonModule, FormsModule, DragDropModule, CardComponent, LeadModalComponent, LeadList, ToolbarComponent],
  templateUrl: './lead-board.html',
  styleUrl: './lead-board.css'
})
export class LeadBoard {
  @Input() lead: any;
  LeadStatus = LeadStatus;
  currentGroup: 'Status' | 'Source' | null = null;

  columns: Column<Lead>[] = [];
  // flatten leads for list view
  leadsAll: Lead[] = [];
  showQuickLead = false;
  targetColumn: Column<Lead> | null = null;
  showModal = false;
  quickLead: Lead = {} as Lead;
  showAddStatusCard: boolean = false;
  newStatusName: string = '';
  bgColorsVars = [
    'var(--color-blue-10, #E0F0FF)',
    '#F8AE5429',
    'var(--color-purple-10, #ECE6FF)',
    '#AFDC8F29'
  ];

  textColorsVars = [
    'var(--color-blue-60, #004D99)',
    'var(--color-orange-60, #9E4A06)',
    'var(--color-purple-60, #3D2785)',
    'var(--color-green-60, #3D7317)'
  ];

  countColorsVars = [
    'var(--color-blue-40, #4394E5)',
    'var(--color-orange-40, #F5921B)',
    'var(--color-purple-40, #876FD4)',
    'var(--color-green-40, #87BB62)',
  ];

  lastColorIndex = -1;
  addingStatus: boolean = false;
  nextColor: string = '';
  selectedLead: Lead = {} as Lead;
  isFormOnly = false;
  private refreshSubscription!: Subscription;
  newLeadIds: Set<string> = new Set();
  // UI state
  viewMode: 'grid' | 'list' = 'grid';
  searchQuery = '';

  sortBy: SortByType = 'Updated';
  grouped: { key: string, items: Lead[] }[] = [];
  expandedGroups: Set<string> = new Set();
  // Toolbar state
  isSortOpen = false;
  isGroupOpen = false;
  isSearchOpen = false;
  @ViewChild('searchInput') searchInput?: ElementRef<HTMLInputElement>;
  // Toolbar properties 
  sortFields = [
    { label: 'Updated', value: 'updatedAt' },
    { label: 'Created', value: 'createdAt' },
    { label: 'Name', value: 'fullName' },
    { label: 'Status', value: 'status' }
  ];

  groupFields = [
    { label: 'Status', value: 'Status' },
    { label: 'Source', value: 'Source' }
  ];

  filters = [
    { label: 'Name', value: 'fullName' },
    { label: 'Location', value: 'location' },
    { label: 'Budget', value: 'budget' },
    { label: 'Status', value: 'status' },
    { label: 'Priority', value: 'priority' },
    { label: 'Assign', value: 'assignedTo' },
    { label: 'Source', value: 'source' },
    { label: 'Updated', value: 'updatedAt' },
    { label: 'Created', value: 'createdAt' }
  ];

  selectedField: string | null = null;
  sortDirection: 'asc' | 'desc' = 'asc';
  isFilterOpen = false;
  selectedFilterField: string | null = null;
  filterValue: string = '';
  filterValues: { [key: string]: string } = {};
  activeFilters: { field: string, value: string, operator: string }[] = [];
  filterOperators = [
    { label: 'equals', value: 'equals' },
    { label: 'contains', value: 'contains' },
    { label: 'starts with', value: 'startsWith' },
    { label: 'ends with', value: 'endsWith' },
    { label: 'greater than', value: 'greaterThan' },
    { label: 'less than', value: 'lessThan' }
  ];
  selectedOperator: string = 'contains';

  private sortFieldMap: Record<string, SortByType> = {
    'updatedAt': 'Updated',
    'createdAt': 'Created',
    'fullName': 'Name',
    'status': 'Status'
  };
  @Input() groupedLeads: { key: string, items: Lead[] }[] = [];
  @Input() groupBy: 'Status' | 'Source' | null = null;

  // Champs inclus dans la recherche globale
  private readonly SEARCHABLE_FIELDS: (keyof Lead)[] = [
    'fullName',
    'email',
    'phone',
    'company',
    'location',
    'status',
    'source',
    'priority',
    'assignedTo',
    'tags',
    'campaign',
    'title',
    'productInterest'
  ];

  // Pour le regroupement
  statusOrder: LeadStatus[] = [
    LeadStatus.NEW,
    LeadStatus.CONTACTED,
    LeadStatus.CONVERTED,
    LeadStatus.QUALIFIED];

  groupByField: keyof Lead | null = null;

  /** Mapping entre dropdown et modèle Lead */
  private groupFieldMap: Record<string, keyof Lead> = {
    Status: 'status',
    Source: 'source'
  };
  getColumnsInOrder(): Column<Lead>[] {
    return this.statusOrder
      .map(status => this.columns.find(c => c.status === status))
      .filter(c => c !== undefined) as Column<Lead>[];
  }

  private matchesSearch(lead: Lead, query: string): boolean {
    if (!query || !query.trim()) return true;

    const q = query.toLowerCase();

    return this.SEARCHABLE_FIELDS.some(field => {
      const value = lead[field];
      if (value === null || value === undefined) return false;
      return String(value).toLowerCase().includes(q);
    });
  }

  onFilterSelected(field: string) {
    console.log('Filtre sélectionné:', field);
  }

  onViewModeChange(mode: 'grid' | 'list') {
    this.viewMode = mode;
  }

  constructor(
    private leadService: LeadService,
    private location: Location,
    private activityService: ActivityService,
    private tenantSelection: TenantSelectionService,
  ) {

  }
  ngOnInit() {
    this.initColumns();
    this.updateGroupedLeads();

    if (this.currentGrouping) {
      this.rebuildGroupedData();
    }

    this.getAllLeads();
    this.startAutoRefresh();
  }

  getAllLeads() {
    this.leadService.getAllLeads().subscribe(leads => {
      this.leadsAll = leads;

      this.columns.forEach(c => c.tasks = []);
      this.leadsAll.forEach(lead => {
        const column = this.columns.find(col => col.status === lead.status);
        if (column) column.tasks.push(lead);
      });

      if (this.currentGroup) {
        this.updateGroupedData();
      }
    });
  }
  startAutoRefresh() {
    if (this.refreshSubscription) this.refreshSubscription.unsubscribe();

    this.refreshSubscription = interval(60000).subscribe(() => this.checkForUpdates());
  }
  checkForUpdates() {
    if (this.showQuickLead || this.showModal) return;

    this.leadService.getAllLeads().subscribe(leads => {
      this.leadsAll = leads;
      let hasNewLead = false;

      leads.forEach(lead => {
        const col = this.columns.find(c => c.status === lead.status);
        if (!col) return;

        const exists = col.tasks.some(t => t.id === lead.id);
        if (!exists) {
          col.tasks.unshift(lead);
          hasNewLead = true;
        }
      });
    });
  }

  ngOnDestroy() {
    this.refreshSubscription?.unsubscribe();
  }

  initColumns() {
    this.columns = Object.values(LeadStatus).map((status, index) => {
      const colorIndex = index % this.bgColorsVars.length;
      return new Column(
        status,
        this.bgColorsVars[colorIndex],
        this.textColorsVars[colorIndex],
        this.countColorsVars[colorIndex]
      );
    });
  }



  setViewMode(mode: 'grid' | 'list') {
    this.viewMode = mode;
  }

  selectSort(value: 'Updated' | 'Created' | 'Name' | 'Status') {
    this.sortBy = value;
    this.isSortOpen = false;
  }



  selectGroup(value: 'Status' | 'Source') {
    this.groupBy = value;
    this.isGroupOpen = false;
  }

  toggleSearch(event: Event) {
    event.stopPropagation();
    this.isSearchOpen = !this.isSearchOpen;
    if (this.isSearchOpen) {
      setTimeout(() => this.searchInput?.nativeElement.focus(), 0);
    } else {
      this.searchQuery = '';
    }
  }

  createLead(lead: Lead, onComplete: () => void) {
    lead.tenantId = this.tenantSelection.selectedTenant()?.id || '';
    lead.id = Math.random().toString(36).substring(2, 18);
    lead.createdAt = new Date().toISOString();
    this.leadService.createLead(lead).subscribe(createdLead => {
      const col = this.columns.find(c => c.status === createdLead.status);
      col?.tasks.push(createdLead);
      onComplete();
    });
  }

  openQuickLead(column: Column<Lead>) {
    this.targetColumn = column;
    this.quickLead = { status: column.status as LeadStatus } as Lead;
    this.showQuickLead = true;
  }

  createLeadFromModal(lead: Lead) {
    this.createLead(lead, () => this.closeModal());
  }

  closeModal() {
    this.showModal = false;
  }

  submitQuickLead() {
    if (this.quickLead.fullName?.trim()) {
      const tempLead = { ...this.quickLead };
      this.createLead(tempLead, () => {
        this.cancelQuickLead();
      });
    }
  }

  cancelQuickLead() {
    this.quickLead = {} as Lead;
    this.showQuickLead = false;
    this.targetColumn = null;
  }


  openModal(leadId?: string, column?: Column<Lead>) {
    if (leadId) {
      this.leadService.getLeadById(leadId).subscribe({
        next: (lead) => {
          this.selectedLead = { ...lead };
          this.isFormOnly = false;
          this.showModal = true;
          this.location.replaceState('/lead-board');
              },
        error: (err) => console.error('Erreur récupération lead:', err)
      });
    } else {
      this.isFormOnly = true;
      this.selectedLead = { status: column ? (column.status as LeadStatus) : LeadStatus.NEW } as Lead;
      this.showModal = true;
    }
  }
  groupLeadsByStatus(): Record<string, Lead[]> {
    const result: Record<string, Lead[]> = {};
    this.columns.forEach(col => {
      result[col.status] = col.tasks.filter(lead =>
        this.matchesSearch(lead, this.searchQuery)
      );
    });
    return result;
  }


  getNextColor(): { bg: string, text: string } {
    this.lastColorIndex = (this.lastColorIndex + 1) % this.bgColorsVars.length;
    return {
      bg: this.bgColorsVars[this.lastColorIndex],
      text: this.textColorsVars[this.lastColorIndex]
    };
  }


  dropColumn(event: CdkDragDrop<Column<Lead>[]>) {
    moveItemInArray(this.columns, event.previousIndex, event.currentIndex);
  }

  getConnectedLists(currentCol: Column<Lead>): string[] {
    return this.columns
      .filter(c => c !== currentCol)
      .map(c => c.status);
  }

  enableEdit(col: Column<Lead>) {
    col.isEditing = true;
  }

  saveColumnStatus(col: Column<Lead>) {
    if (col.status && col.status.trim() !== '') {
      col.status = col.status.trim();
      col.isEditing = false;

      col.tasks.forEach(lead => {
        if (lead.id) {
          this.leadService.partialUpdateLead(lead.id, { status: col.status as LeadStatus })
            .subscribe({
              next: updatedLead => {
                lead.status = updatedLead.status;
              },
              error: err => console.error('Error updating lead status:', err)
            });
        }
      });
    } else {
      col.isEditing = false;
    }
  }

  onModalClosed() {
    this.showModal = false;
    this.selectedLead = {} as Lead;
    this.isFormOnly = false;
    this.getAllLeads();
  }

  createActivityForStatusChange(lead: Lead, newStatus: LeadStatus) {
    const newActivity: Activity = {
      id: Math.random().toString(36).substring(2, 18),
      tenantId: lead.tenantId,
      lead: lead,
      summary: `Status changed to ${newStatus}`,
      details: '',
      type: ActivityType.CALL,
      createdAt: new Date().toISOString(),
      dateTime: new Date().toISOString()
    };

    this.activityService.createActivity(newActivity).subscribe({
      next: created => {
        console.log('Activity created for status change:', created);
      },
      error: err => console.error('Error creating activity for status change:', err)
    });
  }

  toggleFilter(event: Event) {
    event.stopPropagation();
    this.isFilterOpen = !this.isFilterOpen;

    if (this.isFilterOpen) {
      this.isSortOpen = false;
    }

  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.pf-v6-c-dropdown') && !target.closest('.filter-wrapper')) {
      this.isSortOpen = false;
      this.isGroupOpen = false;
      this.isFilterOpen = true;
    }
    if (!target.closest('.search-wrapper')) {
      this.isSearchOpen = false;
    }
  }

  backToFilter() {
    this.isSortOpen = false;
    this.isFilterOpen = true;
    this.selectedField = null;
  }

  // Appliquer le tri
  applySort(direction: 'asc' | 'desc') {
    if (this.selectedField) {
      this.sortDirection = direction;
      this.sortColumn(this.selectedField, this.sortDirection);
      this.isSortOpen = false; // ferme dropdown tri après tri
    }
  }

  toggleSort(event: Event) {
    event.stopPropagation();
    if (!this.selectedField) return; // garde cette vérification si nécessaire
    this.isSortOpen = !this.isSortOpen;
    this.isFilterOpen = false;
  }



  sortColumn(field: string, direction: 'asc' | 'desc') {
    this.columns.forEach(col => {
      col.tasks.sort((a: any, b: any) => {
        let aValue = a[field];
        let bValue = b[field];
        if (typeof aValue === 'string') return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
        if (typeof aValue === 'number' || aValue instanceof Date) return direction === 'asc' ? (aValue > bValue ? 1 : -1) : (aValue < bValue ? 1 : -1);
        return 0;
      });
    });
  }

  // Méthode pour obtenir les listes connectées par source
  getConnectedListsForSource(col: Column<Lead>, source: string): string[] {
    // En mode groupé, connecter seulement les colonnes de la même source
    const connectedLists = [];

    for (const otherCol of this.columns) {
      if (otherCol !== col) {
        connectedLists.push(`${otherCol.status}-${source}`);
      }
    }

    return connectedLists;
  }





  // Déclarez ces propriétés dans votre classe
  currentGrouping: 'source' | 'status' | null = null;
  groupedData: {
    bySource?: Record<string, Record<string, Lead[]>>;
    byStatus?: Record<string, Lead[]>;
  } = {};

rebuildGroupedData() {
  if (!this.currentGrouping) {
    this.groupedData = {};
    // Utiliser leadsAll qui contient déjà les données du backend
    return;
  }

  if (this.currentGrouping === 'source') {
    this.groupedData.bySource = this.groupLeadsBySource();
    this.groupedData.byStatus = undefined;
  } else if (this.currentGrouping === 'status') {
    this.groupedData.byStatus = this.groupLeadsByStatus();
    this.groupedData.bySource = undefined;
  }

  // Mettre à jour leadsAll pour la vue list avec les données groupées
  this.leadsAll = this.getFlatLeads();
}


  groupLeadsBySource(): Record<string, Record<string, Lead[]>> {
    const result: Record<string, Record<string, Lead[]>> = {};

    this.columns.forEach(col => {
      col.tasks.forEach(lead => {

        if (!this.matchesSearch(lead, this.searchQuery)) return;

        const source = lead.source ?? 'Unknown';

        result[source] ??= {};
        result[source][col.status] ??= [];
        result[source][col.status].push(lead);
      });
    });

    return result;
  }


  getVisibleLeads(col: Column<Lead>): Lead[] {
    return col.tasks.filter(lead =>
      this.matchesSearch(lead, this.searchQuery)
    );
  }


  // Modifiez getUniqueSources pour être plus performant
  getUniqueSources(): string[] {
    const sources = new Set<string>();

    this.columns.forEach(col => {
      col.tasks.forEach(lead => {
        if (lead.source) {
          sources.add(lead.source);
        }
      });
    });

    return Array.from(sources).filter(source => source && source !== 'Unknown');
  }

  // Modifiez getTotalLeadsBySource pour utiliser les données groupées
  getTotalLeadsBySource(source: string): number {
    if (this.groupedData.bySource && this.groupedData.bySource[source]) {
      let total = 0;
      Object.values(this.groupedData.bySource[source]).forEach(leads => {
        total += leads.length;
      });
      return total;
    }
    return 0;
  }

  getLeadsBySourceAndStatus(source: string, status: string): Lead[] {
    if (this.groupedData.bySource && this.groupedData.bySource[source]) {
      return this.groupedData.bySource[source][status] ?? [];
    }
    return [];
  }




  // Modifiez dropTask pour mettre à jour les données groupées
  dropTask(event: CdkDragDrop<Lead[]>, column: Column<Lead>, source?: string) {
    let movedLead: Lead;

    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      return;
    } else {
      movedLead = event.previousContainer.data[event.previousIndex];

      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }

    if (movedLead && movedLead.id) {
      const newStatus = column.status as LeadStatus;
      const updates: any = { status: newStatus };

      // Si en mode groupé par source et source spécifiée
      if (this.currentGrouping === 'source' && source) {
        updates.source = source;
      }

      this.leadService.updateLead(movedLead.id, { ...movedLead, ...updates })
        .subscribe({
          next: (lead) => {
            movedLead!.status = lead.status;
            if (updates.source) {
              movedLead!.source = lead.source;
            }

            // Mettre à jour les données groupées
            this.rebuildGroupedData();

            this.createActivityForStatusChange(lead, newStatus);
          },
          error: err => console.error('Error updating lead:', err)
        });
    }
  }



  buildGroupBy(field: keyof Lead) {
    const map = new Map<string, Lead[]>();

    this.columns.forEach(col => {
      col.tasks.forEach(task => {
        const key = task[field] !== undefined ? String(task[field]) : 'Unknown';
        if (!map.has(key)) map.set(key, []);
        map.get(key)?.push(task);
      });
    });

    // Transformer le Map en tableau
    this.groupedLeads = Array.from(map.entries()).map(([key, items]) => ({ key, items }));
  }


  // Ajoutez cette méthode pour gérer la sélection du filtre
  selectFilter(field: string) {
    this.selectedFilterField = field;
    this.filterValue = this.filterValues[field] || '';
    this.isFilterOpen = false;
    this.isSortOpen = true;
  }

  // Ajoutez cette méthode pour appliquer le filtre
  applyFilter() {
    if (!this.selectedFilterField || !this.filterValue.trim()) {
      return;
    }

    // Ajouter ou mettre à jour le filtre
    const existingFilterIndex = this.activeFilters.findIndex(
      f => f.field === this.selectedFilterField
    );

    const newFilter = {
      field: this.selectedFilterField,
      value: this.filterValue.trim(),
      operator: this.selectedOperator
    };

    if (existingFilterIndex > -1) {
      this.activeFilters[existingFilterIndex] = newFilter;
    } else {
      this.activeFilters.push(newFilter);
    }

    // Appliquer les filtres
    this.filterLeads();
    this.isSortOpen = false;
  }
  filterLeads() {
    // Utiliser les données déjà chargées dans leadsAll
    let filteredLeads = [...this.leadsAll];

    // Appliquer recherche globale
    if (this.searchQuery.trim()) {
      const query = this.searchQuery.toLowerCase();
      filteredLeads = filteredLeads.filter(lead =>
        lead.fullName?.toLowerCase().includes(query) ||
        lead.email?.toLowerCase().includes(query) ||
        lead.company?.toLowerCase().includes(query) ||
        lead.location?.toLowerCase().includes(query) ||
        lead.phone?.toLowerCase().includes(query) ||
        lead.status?.toLowerCase().includes(query) ||
        lead.source?.toLowerCase().includes(query) ||
        lead.tags?.toLowerCase().includes(query)
      );
    }

    // Appliquer les filtres actifs
    if (this.activeFilters.length > 0) {
      filteredLeads = filteredLeads.filter(lead => {
        return this.activeFilters.every(filter => {
          const fieldValue = lead[filter.field as keyof Lead];
          if (fieldValue == null) return false;

          const valueStr = String(fieldValue).toLowerCase();
          const filterValueLower = filter.value.toLowerCase();

          switch (filter.operator) {
            case 'equals': return valueStr === filterValueLower;
            case 'contains': return valueStr.includes(filterValueLower);
            case 'startsWith': return valueStr.startsWith(filterValueLower);
            case 'endsWith': return valueStr.endsWith(filterValueLower);
            case 'greaterThan': return !isNaN(Number(valueStr)) && Number(valueStr) > Number(filter.value);
            case 'lessThan': return !isNaN(Number(valueStr)) && Number(valueStr) < Number(filter.value);
            default: return true;
          }
        });
      });
    }

    // Mettre à jour leadsAll (list view)
    this.leadsAll = filteredLeads;

    // Mettre à jour les colonnes (grid view)
    this.columns.forEach(c => c.tasks = []);
    this.leadsAll.forEach(lead => {
      const column = this.columns.find(col => col.status === lead.status);
      if (column) column.tasks.push(lead);
    });

    // Mettre à jour les données groupées si nécessaire
    if (this.currentGroup) {
      this.updateGroupedData();
    }
  }

  removeFilter(index: number) {
    this.activeFilters.splice(index, 1);
    this.filterLeads();
  }

clearAllFilters() {
  this.activeFilters = [];
  this.filterValues = {};
  this.searchQuery = '';

  this.columns.forEach(c => c.tasks = []);
  this.leadsAll.forEach(lead => {
    const column = this.columns.find(col => col.status === lead.status);
    if (column) column.tasks.push(lead);
  });

  if (this.currentGroup) {
    this.updateGroupedData();
  }
}


  getLeadsByStatus(status: string) {
    return this.groupedData.byStatus?.[status] ?? [];
  }

  getAllConnectedLists() {
    return this.getColumnsInOrder().map(c => c.status);
  }

  getFlatLeads(): Lead[] {
    if (this.groupByField === 'status' && this.groupedData.byStatus) {
      return Object.values(this.groupedData.byStatus).flat();
    }
    if (this.groupByField === 'source' && this.groupedData.bySource) {
      return Object.values(this.groupedData.bySource)
        .map(obj => Object.values(obj).flat())
        .flat();
    }
    return this.leadsAll;
  }

  get flatLeads(): Lead[] {
    if (this.groupByField === 'status' && this.groupedData.byStatus) {
      return Object.values(this.groupedData.byStatus).flat();
    }
    if (this.groupByField === 'source' && this.groupedData.bySource) {
      return Object.values(this.groupedData.bySource)
        .map(obj => Object.values(obj).flat())
        .flat();
    }
    return this.leadsAll;
  }



  ngOnChanges() {
    this.updateGroupedLeads();
  }

  updateGroupedLeads(): void {
    if (!this.groupBy || !this.lead) {
      this.grouped = [];
      return;
    }

    const map = new Map<string, Lead[]>();

    this.lead.forEach((l: Lead) => {
      if (!l) return;

      let key: string;
      if (this.groupBy === 'Status') {
        key = l.status ?? '—';
      } else if (this.groupBy === 'Source') {
        key = l.source ?? '—';
      } else {
        key = '—';
      }

      if (!map.has(key)) {
        map.set(key, []);
      }
      map.get(key)?.push(l);
    });

    this.grouped = Array.from(map.entries()).map(([key, items]) => ({ key, items }));
  }


  toggleGroup(key: string) {
    if (this.expandedGroups.has(key)) this.expandedGroups.delete(key);
    else this.expandedGroups.add(key);
  }

  isGroupExpanded(key: string): boolean {
    return this.expandedGroups.has(key);
  }

  expandedGroupsGrid: Set<string> = new Set();

  isGroupExpandedGrid(groupKey: string): boolean {
    if (this.expandedGroupsGrid.has(groupKey)) {
      return true;
    }

    if (this.currentGrouping) {
      return true;
    }

    return false;
  }

  toggleGroupGrid(groupKey: string): void {
    if (this.expandedGroups.has(groupKey)) {
      this.expandedGroups.delete(groupKey);
    } else {
      this.expandedGroups.add(groupKey);
    }
  }

  onGroupSelected(field: string) {

    if (field === 'Status' || field === 'Source') {
      this.currentGroup = field;
      this.groupBy = field;
    } else {
      this.currentGroup = null;
      this.groupBy = null;
    }

    this.updateGroupedData();

    const mappedField = this.groupFieldMap[field];
    if (!mappedField) {
      this.currentGrouping = null;
      this.groupedData = {};
      this.groupByField = null;
      return;
    }

    this.groupByField = mappedField;
    this.currentGrouping = field === 'Source' ? 'source' : 'status';
    this.rebuildGroupedData();
  }

  updateGroupedData() {
    if (!this.currentGroup || !this.leadsAll.length) {
      this.grouped = [];
      return;
    }

    const map = new Map<string, Lead[]>();

    this.leadsAll.forEach(lead => {
      let key: string;

      if (this.currentGroup === 'Status') {
        key = lead.status || 'Unknown';
      } else if (this.currentGroup === 'Source') {
        key = lead.source || 'Unknown';
      } else {
        key = 'Unknown';
      }

      if (!map.has(key)) {
        map.set(key, []);
      }
      map.get(key)!.push(lead);
    });

    this.grouped = Array.from(map.entries())
      .map(([key, items]) => ({
        key,
        items: this.sortLeads(items, this.sortBy)
      }))
      .sort((a, b) => {
        if (this.currentGroup === 'Status') {
          const statusOrder = [
            LeadStatus.NEW,
            LeadStatus.CONTACTED,
            LeadStatus.QUALIFIED,
            LeadStatus.CONVERTED
          ];
          const aIndex = statusOrder.indexOf(a.key as LeadStatus);
          const bIndex = statusOrder.indexOf(b.key as LeadStatus);
          return (aIndex === -1 ? 999 : aIndex) - (bIndex === -1 ? 999 : bIndex);
        } else {
          return a.key.localeCompare(b.key);
        }
      });
  }

  private sortLeads(leads: Lead[], sortBy: SortByType): Lead[] {
    const sorted = [...leads];

    switch (sortBy) {
      case 'Name':
        return sorted.sort((a, b) => (a.fullName || '').localeCompare(b.fullName || ''));
      case 'Updated':
        return sorted.sort((a, b) =>
          new Date(b.lastModifiedDate || b.createdDate || '').getTime() -
          new Date(a.lastModifiedDate || a.createdDate || '').getTime()
        );
      case 'Created':
        return sorted.sort((a, b) =>
          new Date(b.createdDate || '').getTime() -
          new Date(a.createdDate || '').getTime()
        );
      case 'Status':
        return sorted.sort((a, b) => (a.status || '').localeCompare(b.status || ''));
      default:
        return sorted;
    }
  }

  onSortChange(sortData: { field: string, direction: 'asc' | 'desc' }) {
    this.sortBy = this.sortFieldMap[sortData.field] || 'Updated';
    this.sortDirection = sortData.direction;

    this.sortColumn(sortData.field, sortData.direction);

    if (this.currentGroup) {
      this.updateGroupedData();
    }
  }



  onSearchQueryChange(query: string) {
    this.searchQuery = query;

    if (this.currentGroup) {
      this.updateGroupedData();
    }
  }
}