import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../config';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ErrorHandlerService } from './error-handler.service';
import { Deal } from '../models/deal.model';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DealService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllDeals(): Observable<Deal[]> {
    return this.http.get<Deal[]>(`${this.base}/deals`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllDeals');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving deal');
        return throwError(() => errorInfo);
      })
    );
  }

  getDeal(id: string): Observable<Deal> {
    return this.http.get<Deal>(`${this.base}/deals/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getDeal');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the deal');
        return throwError(() => errorInfo);
      })
    );
  }

  getDealById(id: string): Observable<Deal> {
    return this.http.get<Deal>(`${this.base}/deals/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getDeal');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the deal');
        return throwError(() => errorInfo);
      })
    );
  }

  createDeal(body: Deal): Observable<Deal> {
    return this.http.post<Deal>(`${this.base}/deals`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createDeal');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the deal');
        return throwError(() => errorInfo);
      })
    );
  }

  updateDeal(id: string, body: Deal): Observable<Deal> {
    return this.http.put<Deal>(`${this.base}/deals/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateDeal');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the deal');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteDeal(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/deals/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteDeal');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the deal');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateDeal(id: string, body: Partial<Deal>): Observable<Deal> {
    return this.http.patch<Deal>(`${this.base}/deals/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateDeal');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the deal');
        return throwError(() => errorInfo);
      })
    );
  }


}
