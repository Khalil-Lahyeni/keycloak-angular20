import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

export interface ErrorInfo {
  message: string;
  isBackendError: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ErrorHandlerService {

  /**
   * Extracts error message from HttpErrorResponse with fallback mechanism
   * @param error - The HTTP error response
   * @param fallbackMessage - Default message if no backend error is found
   * @returns ErrorInfo object containing the message and whether it's from backend
   */
  extractErrorMessage(error: HttpErrorResponse, fallbackMessage: string): ErrorInfo {
    // Check if error has a response body with error message
    if (error.error && typeof error.error === 'object') {
      // Try different common error message properties
      const backendMessage = error.error.error ||
        error.error.message ||
        error.error.details ||
        error.error.errorMessage;

      if (backendMessage && typeof backendMessage === 'string') {
        return {
          message: backendMessage,
          isBackendError: true
        };
      }
    }

    // Check if error.error is a string (some APIs return string directly)
    if (error.error && typeof error.error === 'string') {
      return {
        message: error.error,
        isBackendError: true
      };
    }

    // Check if there's a message in the error itself
    if (error.message && error.message !== `Http failure response for ${error.url}: ${error.status} ${error.statusText}`) {
      return {
        message: error.message,
        isBackendError: true
      };
    }

    // Fallback to generic message
    return {
      message: fallbackMessage,
      isBackendError: false
    };
  }

  /**
   * Gets appropriate error message for tenant operations
   * @param error - The HTTP error response
   * @param operation - The operation being performed (create, update, get)
   * @returns ErrorInfo object
   */
  getTenantErrorMessage(error: HttpErrorResponse, operation: 'create' | 'update' | 'get' | 'delete'): ErrorInfo {
    const fallbackMessages = {
      create: 'Error creating the tenant',
      update: 'Error updating the tenant',
      get: 'Error retrieving tenants',
      delete: 'Error deleting the tenant'

    };

    return this.extractErrorMessage(error, fallbackMessages[operation]);
  }

  /**
   * Logs error details for debugging purposes
   * @param error - The HTTP error response
   * @param context - Additional context for logging
   */
  logError(error: HttpErrorResponse, context: string): void {
    console.error(`[${context}] HTTP Error:`, {
      status: error.status,
      statusText: error.statusText,
      url: error.url,
      error: error.error,
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}
