package com.railway.collector.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "influxdb")
public class InfluxProperties {

    private String url = "http://localhost:8086";
    private String token = "railway-super-secret-token";
    private String org = "railway";
    private String bucket = "train_monitoring";
}
