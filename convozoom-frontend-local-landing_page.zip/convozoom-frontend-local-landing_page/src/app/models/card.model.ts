export interface Card {
  id: string;
  title: string;
  status: string;
  [key: string]: any;
}
