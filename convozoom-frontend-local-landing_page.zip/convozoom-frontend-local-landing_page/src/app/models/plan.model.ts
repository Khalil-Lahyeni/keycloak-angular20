export interface PlanDTO {
  id?: string;
  code: string;
  name: string;
  description: string;
  price?: number;
  storage?: number;
  leadsByMonth?: number;
  licenceNb?: number;
}