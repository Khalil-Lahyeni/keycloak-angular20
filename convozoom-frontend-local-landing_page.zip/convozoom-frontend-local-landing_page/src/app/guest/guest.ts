import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GuestService } from '../services/guest-service';
import { AgendaService } from '../services/agenda.service';
import { GuestStateService } from '../services/guest-state.service';
import { GuestDTO, AgendaDTO } from '../models/guest.model';
import { dateToOffsetDateTime } from './guest.util';

@Component({
  selector: 'app-guest',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './guest.html',
  styleUrls: ['./guest.css']
})
export class GuestPage implements OnInit {

  // Guest information
  guestInfo: GuestDTO | null = null;
  isLoadingGuest: boolean = false;
  guestError: string = '';

  // Agent information
  agentName = 'Agent AI';
  agentDescription = 'Your virtual real-estate guide - French & English';
  agentInitials = 'AI';
  agentTags = ['Real Estate', '30 min'];
  nextAvailability = 'Thu, Nov 13 — 10:00';

  // Calendar state
  selectedDate: Date | null = null;
  selectedTime: string = '';
  isTimeDropdownOpen: boolean = false;
  isMonthDropdownOpen: boolean = false;
  currentMonth: Date = new Date();
  calendarDays: Array<{ 
    date: Date | null; 
    isCurrentMonth: boolean; 
    isSelected: boolean; 
    isToday: boolean;
    isPast: boolean 
  }> = [];

  // Modal state
  showConfirmationModal: boolean = false;


  pageSize: number = 5; 
  currentPage: number = 1; 


  get totalPages(): number {
    const total = this.guestInfo?.agenda?.length ?? 0;
    return total === 0 ? 1 : Math.ceil(total / this.pageSize);
  }


  get paginatedAgendas(): AgendaDTO[] {
    const all = this.guestInfo?.agenda ?? [];
    const start = (this.currentPage - 1) * this.pageSize;
    return all.slice(start, start + this.pageSize);
  }


  nextPage() {
    if (this.currentPage < this.totalPages) this.currentPage++;
  }
  prevPage() {
    if (this.currentPage > 1) this.currentPage--;
  }

  // Available time slots (30-minute intervals)
  availableTimes: string[] = [
    '00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30',
    '04:00', '04:30', '05:00', '05:30', '06:00', '06:30', '07:00', '07:30',
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
    '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30',
    '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30'
  ];

  // Month names for dropdown
  months: string[] = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private guestService: GuestService,
    private agendaService: AgendaService,
    private guestStateService: GuestStateService
  ) {}

  ngOnInit() {
    // Extract token, leadId, and tenantId from URL query parameters
    this.route.queryParams.subscribe(params => {
      const accessToken = params['token'];
      const leadId = params['leadId'];
      const tenantId = params['tenantId'];
      
      if (accessToken) {
        this.initializeGuestSession(accessToken, leadId, tenantId);
      } else {
        this.guestError = 'No access token provided in URL';
      }
    });

    this.generateCalendar();
  }

  /**
   * Initializes the guest session by fetching guest info
   * @param accessToken - The token from the URL query parameter
   * @param leadId - The lead identifier from URL query parameter
   * @param tenantId - The tenant identifier from URL query parameter
   */
  private async initializeGuestSession(accessToken: string, leadId?: string, tenantId?: string) {
    this.isLoadingGuest = true;

    try {
      // Get guest information from backend
      this.guestInfo = await this.guestService.getGuestByToken(accessToken).toPromise() as GuestDTO;
      
      // Publish guest info into global state service
      this.guestStateService.setGuestInfo(this.guestInfo);
      
      // Publish leadId and tenantId into global state service
      if (leadId) {
        this.guestStateService.setLeadId(leadId);
      }
      if (tenantId) {
        this.guestStateService.setTenantId(tenantId);
      }

      if (!this.guestInfo) {
        throw new Error('Failed to fetch guest information');
      }

      // Update agent info with guest data if needed
      this.agentName = this.guestInfo.name || this.agentName;
      // Reset pagination when data loads
      this.currentPage = 1;
      
      this.isLoadingGuest = false;

    } catch (error) {
      this.isLoadingGuest = false;
      this.guestError = error instanceof Error ? error.message : 'Failed to initialize session';
    }
  }

  // Return a PatternFly color modifier class based on AgendaStatus
  labelColorClass(state: string | undefined): string {
    switch (state) {
      case 'Planified':
        return 'pf-m-blue';
      case 'InProgress':
        return 'pf-m-green';
      case 'Closed':
        return 'pf-m-red';
      default:
        return 'pf-m-grey';
    }
  }

  generateCalendar() {
    const year = this.currentMonth.getFullYear();
    const month = this.currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const firstDayOfWeek = firstDay.getDay();
    
    this.calendarDays = [];

    // Add padding for days before the first day of the month
    for (let i = 0; i < firstDayOfWeek; i++) {
      this.calendarDays.push({ 
        date: null, 
        isCurrentMonth: false, 
        isSelected: false, 
        isToday: false,
        isPast: false 
      });
    }
    
    // Get today's date for comparison
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Add all days of the current month
    for (let day = 1; day <= lastDay.getDate(); day++) {
      const date = new Date(year, month, day);
      const isToday = date.getTime() === today.getTime();
      const isSelected = this.selectedDate ? date.getTime() === this.selectedDate.getTime() : false;
      const isPast = date.getTime() < today.getTime();
      
      this.calendarDays.push({
        date: date,
        isCurrentMonth: true,
        isSelected: isSelected,
        isToday: isToday,
        isPast: isPast
      });
    }
    
    // Add padding to complete the last week
    const totalCells = this.calendarDays.length;
    const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
    for (let i = 0; i < remainingCells; i++) {
      this.calendarDays.push({ 
        date: null, 
        isCurrentMonth: false, 
        isSelected: false, 
        isToday: false,
        isPast: false 
      });
    }
  }

  selectDate(day: { date: Date | null; isCurrentMonth: boolean; isSelected: boolean; isToday: boolean; isPast: boolean }) {
    if (day.date && day.isCurrentMonth && !day.isPast) {
      this.selectedDate = day.date;
      
      // Si la date sélectionnée est aujourd'hui, trouver le prochain créneau disponible
      const today = new Date();
      const isToday = day.date.toDateString() === today.toDateString();
      
      if (isToday) {
        this.selectedTime = this.getNextAvailableTime();
      } else {
        this.selectedTime = '10:00'; // Par défaut pour les dates futures
      }
      
      this.generateCalendar();
    }
  }

  // Méthode pour obtenir le prochain créneau horaire disponible
  getNextAvailableTime(): string {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    // Trouver le prochain créneau de 30 minutes
    let nextHour = currentHour;
    let nextMinute = currentMinute <= 30 ? 30 : 0;
    
    if (currentMinute > 30) {
      nextHour += 1;
    }
    
    // Si on dépasse 23:00, prendre le dernier créneau disponible (23:30)
    if (nextHour >= 24) {
      return '23:30';
    }
    
    // Chercher le créneau dans la liste des availableTimes
    const targetTime = `${nextHour.toString().padStart(2, '0')}:${nextMinute.toString().padStart(2, '0')}`;
    
    // Vérifier si ce créneau existe dans availableTimes
    const availableSlot = this.availableTimes.find((slot: string) => slot >= targetTime);
    
    return availableSlot || this.availableTimes[this.availableTimes.length - 1]; // Retourner le créneau trouvé ou le dernier disponible
  }

  // Méthode pour obtenir les créneaux horaires disponibles selon la date sélectionnée
  getAvailableTimesForSelectedDate(): string[] {
    if (!this.selectedDate) {
      return this.availableTimes;
    }

    const today = new Date();
    const isToday = this.selectedDate.toDateString() === today.toDateString();

    // Si ce n'est pas aujourd'hui, retourner tous les créneaux
    if (!isToday) {
      return this.availableTimes;
    }

    // Si c'est aujourd'hui, filtrer les créneaux passés
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    // Calculer le temps actuel en minutes depuis minuit
    const currentTimeInMinutes = currentHour * 60 + currentMinute;

    // Filtrer les créneaux qui sont dans le futur
    return this.availableTimes.filter((time: string) => {
      const [hours, minutes] = time.split(':').map(Number);
      const slotTimeInMinutes = hours * 60 + minutes;
      return slotTimeInMinutes > currentTimeInMinutes;
    });
  }

  toggleTimeDropdown() {
    this.isTimeDropdownOpen = !this.isTimeDropdownOpen;
  }

  selectTime(time: string) {
    this.selectedTime = time;
    this.isTimeDropdownOpen = false;
  }

  getFormattedDateTime(): string {
    if (!this.selectedDate) return this.nextAvailability;
    
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    const dayName = days[this.selectedDate.getDay()];
    const monthName = months[this.selectedDate.getMonth()];
    const day = this.selectedDate.getDate();
    const year = this.selectedDate.getFullYear();
    
    return `${dayName}, ${monthName} ${day}, ${year}`;
  }

  previousMonth() {
    this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() - 1, 1);
    this.generateCalendar();
  }

  nextMonth() {
    this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + 1, 1);
    this.generateCalendar();
  }

  getMonthName(): string {
    return this.months[this.currentMonth.getMonth()];
  }

  toggleMonthDropdown() {
    this.isMonthDropdownOpen = !this.isMonthDropdownOpen;
  }

  selectMonth(monthIndex: number) {
    this.currentMonth = new Date(this.currentMonth.getFullYear(), monthIndex, 1);
    this.isMonthDropdownOpen = false;
    this.generateCalendar();
  }

  getWeeks(): Array<Array<{ date: Date | null; isCurrentMonth: boolean; isSelected: boolean; isToday: boolean; isPast: boolean }>> {
    const weeks: Array<Array<{ date: Date | null; isCurrentMonth: boolean; isSelected: boolean; isToday: boolean; isPast: boolean }>> = [];
    let currentWeek: Array<{ date: Date | null; isCurrentMonth: boolean; isSelected: boolean; isToday: boolean; isPast: boolean }> = [];
    
    this.calendarDays.forEach((day, index) => {
      currentWeek.push(day);
      if ((index + 1) % 7 === 0) {
        weeks.push(currentWeek);
        currentWeek = [];
      }
    });
    
    if (currentWeek.length > 0) {
      weeks.push(currentWeek);
    }
    
    return weeks;
  }

  getAriaLabel(day: { date: Date | null; isCurrentMonth: boolean; isSelected: boolean; isToday: boolean; isPast: boolean }): string {
    if (!day.date) return '';
    return `${day.date.getDate()} ${this.months[day.date.getMonth()]} ${day.date.getFullYear()}`;
  }

  bookRendezVous() {
    // Validation des données requises
    if (!this.selectedDate || !this.selectedTime) {
      alert('Please select a date and time');
      return;
    }

    if (!this.guestInfo) {
      alert('Guest information not loaded');
      return;
    }

    // Construire la date complète au format ISO: "2025-11-15T14:30:00"
    const [hours, minutes] = this.selectedTime.split(':');
    const fullDate = new Date(this.selectedDate);
    fullDate.setHours(parseInt(hours, 10), parseInt(minutes, 10), 0, 0);
    const fullDateString = dateToOffsetDateTime(fullDate);
    // Récupérer leadId et tenantId depuis l'URL (stockés dans guestStateService)
    const leadId = this.guestStateService.currentLeadId;
    const tenantId = this.guestStateService.currentTenantId;

    // Créer le payload avec date, leadId, tenantId (de l'URL) et guest
    const agendaData: AgendaDTO = {
      date: fullDateString, 
      leadId: leadId || undefined,
      tenantId: tenantId || undefined,
      guest: this.guestInfo!
    };

    // Appeler le service pour créer le rendez-vous
    this.agendaService.createAgenda(agendaData).subscribe({
      next: (response) => {
        console.log('Agenda created successfully:', response);
        // Afficher le modal de confirmation au lieu d'une alert
        this.showConfirmationModal = true;
      },
      error: (error) => {
        console.error('Error creating agenda:', error);
        alert('Erreur lors de la création du rendez-vous. Veuillez réessayer.');
      }
    });
  }

  confirmAndClose() {
    // Fermer le modal
    this.showConfirmationModal = false;
    
    // Détruire/fermer la fenêtre automatiquement
    //window.location.href = 'https://www.google.com';
  }

  async startChat(agenda: AgendaDTO) {
    if (!agenda?.id) {
      alert('Agenda missing id; cannot start chat');
      return;
    }

    this.guestStateService.setAgenda(agenda);
    // Navigate to meeting page
    this.router.navigate(['/meeting'])
  }

  // Compare agenda tenantId with tenantId from URL (normalized)
  canStartChat(agenda: AgendaDTO | any): boolean {
    const aId = (agenda?.tenantId ?? '').toString().trim().toLowerCase();
    const uId = (this.guestStateService.currentTenantId ?? '').toString().trim().toLowerCase();
    return aId !== '' && uId !== '' && aId === uId;
  }
}
