package com.railway.collector.handler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.railway.collector.model.Alert;
import com.railway.collector.service.CollectorStatsService;
import com.railway.collector.service.FleetManagerService;
import com.railway.collector.service.normalizer.NormalizerService;
import com.railway.collector.service.publisher.InfluxPublisherService;
import com.railway.collector.service.publisher.MqttPublisherService;
import com.railway.collector.service.rules.RulesEngineService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ═══════════════════════════════════════════════════════════
 *  MqttMessageRouter — Pipeline de traitement principal.
 *
 *  Flux: Message MQTT → Parse Topic → Parse JSON
 *        → Normalize → Rules → Publish (MQTT + InfluxDB)
 * ═══════════════════════════════════════════════════════════
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MqttMessageRouter {

    private final ObjectMapper objectMapper;
    private final NormalizerService normalizer;
    private final RulesEngineService rulesEngine;
    private final MqttPublisherService mqttPublisher;
    private final InfluxPublisherService influxPublisher;
    private final FleetManagerService fleetManager;
    private final CollectorStatsService stats;

    // ─── Topic Patterns ───
    private static final Pattern STATUS_PATTERN =
            Pattern.compile("^trains/status/(.+)$");
    private static final Pattern CONFIG_PATTERN =
            Pattern.compile("^trains/configuration/(.+)$");
    private static final Pattern MEDIA_PATTERN =
            Pattern.compile("^trains/media_databases$");
    private static final Pattern MESSAGE_PATTERN =
            Pattern.compile("^trains/message/(.+)$");

    private static final TypeReference<Map<String, Object>> MAP_TYPE =
            new TypeReference<>() {};

    /**
     * Point d'entrée unique — reçoit chaque message MQTT.
     */
    public void handleMessage(Message<?> message) {
        stats.incrementReceived();

        String topic = (String) message.getHeaders().get(MqttHeaders.RECEIVED_TOPIC);
        if (topic == null) {
            log.warn("Message without topic header, skipping");
            stats.incrementInvalid();
            return;
        }

        try {
            // ── Étape 1: Parse le topic ──
            TopicInfo topicInfo = parseTopic(topic);
            if (topicInfo == null) {
                log.warn("Unknown topic pattern: {}", topic);
                stats.incrementInvalid();
                return;
            }

            // ── Étape 2: Parse le payload JSON ──
            String payload = extractPayload(message);
            Map<String, Object> data = objectMapper.readValue(payload, MAP_TYPE);

            // ── Étape 3-6: Dispatch vers le handler approprié ──
            switch (topicInfo.type) {
                case "status" -> handleStatus(topicInfo.trainId, data);
                case "configuration" -> handleConfiguration(topicInfo.trainId, data);
                case "media_databases" -> handleMediaDatabases(data);
                case "message" -> handleTrainMessage(topicInfo.trainId, data);
            }

            stats.incrementProcessed();

        } catch (Exception e) {
            log.error("Error processing message on topic {}: {}",
                    topic, e.getMessage(), e);
            stats.incrementInvalid();
        }
    }

    // ═══════════════════════════════════════════════
    // Handlers par type de topic
    // ═══════════════════════════════════════════════

    /**
     * trains/status/{train_id}
     */
    private void handleStatus(String trainId, Map<String, Object> data) {
        // Couche 2: Normalisation
        Map<String, Object> normalized = normalizer.normalizeStatus(data);

        // Couche 3: Règles métier
        List<Alert> alerts = rulesEngine.applyStatusRules(trainId, normalized);
        int healthScore = rulesEngine.computeHealthScore(trainId, normalized);

        // Enrichissement
        normalized.put("_trainId", trainId);
        normalized.put("_healthScore", healthScore);
        normalized.put("_alertCount", alerts.size());
        normalized.put("_hasAlerts", !alerts.isEmpty());
        normalized.put("_maxSeverity", getMaxSeverity(alerts));
        normalized.put("_processedAt", Instant.now().toString());

        // Couche 4: Double publication
        mqttPublisher.publishStatus(trainId, normalized);
        influxPublisher.writeTrainStatus(trainId, normalized);

        if (!alerts.isEmpty()) {
            mqttPublisher.publishAlerts(alerts);
            alerts.forEach(influxPublisher::writeAlert);
            stats.incrementAlerts(alerts.size());
        }

        // Mise à jour vue flotte
        fleetManager.updateTrain(trainId, normalized);

        log.info("[{}] status: health={}, alerts={}",
                trainId, healthScore, alerts.size());
    }

    /**
     * trains/configuration/{train_id}
     */
    private void handleConfiguration(String trainId, Map<String, Object> data) {
        Map<String, Object> normalized = normalizer.normalizeConfiguration(data);
        List<Alert> alerts = rulesEngine.applyConfigRules(trainId, normalized);

        normalized.put("_trainId", trainId);
        normalized.put("_alertCount", alerts.size());
        normalized.put("_processedAt", Instant.now().toString());

        mqttPublisher.publishConfiguration(trainId, normalized);
        influxPublisher.writeTrainConfiguration(trainId, normalized);

        if (!alerts.isEmpty()) {
            mqttPublisher.publishAlerts(alerts);
            alerts.forEach(influxPublisher::writeAlert);
            stats.incrementAlerts(alerts.size());
        }

        log.info("[{}] configuration: alerts={}", trainId, alerts.size());
    }

    /**
     * trains/media_databases
     */
    private void handleMediaDatabases(Map<String, Object> data) {
        Map<String, Object> normalized = normalizer.normalizeMediaDatabase(data);
        List<Alert> alerts = rulesEngine.applyMediaDbRules(normalized);

        normalized.put("_alertCount", alerts.size());
        normalized.put("_processedAt", Instant.now().toString());

        mqttPublisher.publishMediaDatabases(normalized);
        influxPublisher.writeMediaDatabase(normalized);

        if (!alerts.isEmpty()) {
            mqttPublisher.publishAlerts(alerts);
            alerts.forEach(influxPublisher::writeAlert);
            stats.incrementAlerts(alerts.size());
        }

        log.info("[FLEET] media_databases: alerts={}", alerts.size());
    }

    /**
     * trains/message/{train_id}
     */
    private void handleTrainMessage(String trainId, Map<String, Object> data) {
        Map<String, Object> normalized = normalizer.normalizeMessage(data);

        normalized.put("_trainId", trainId);
        normalized.put("_processedAt", Instant.now().toString());

        mqttPublisher.publishMessage(trainId, normalized);
        influxPublisher.writeTrainMessage(trainId, normalized);

        log.info("[{}] message: type={}, name={}",
                trainId, normalized.get("messageType"), normalized.get("name"));
    }

    // ═══════════════════════════════════════════════
    // Utilitaires
    // ═══════════════════════════════════════════════

    private record TopicInfo(String type, String trainId) {}

    private TopicInfo parseTopic(String topic) {
        Matcher m;

        m = STATUS_PATTERN.matcher(topic);
        if (m.matches()) return new TopicInfo("status", m.group(1));

        m = CONFIG_PATTERN.matcher(topic);
        if (m.matches()) return new TopicInfo("configuration", m.group(1));

        m = MEDIA_PATTERN.matcher(topic);
        if (m.matches()) return new TopicInfo("media_databases", "FLEET");

        m = MESSAGE_PATTERN.matcher(topic);
        if (m.matches()) return new TopicInfo("message", m.group(1));

        return null;
    }

    private String extractPayload(Message<?> message) {
        Object payload = message.getPayload();
        if (payload instanceof byte[] bytes) {
            return new String(bytes);
        }
        return payload.toString();
    }

    private String getMaxSeverity(List<Alert> alerts) {
        if (alerts.isEmpty()) return "NONE";
        return alerts.stream()
                .map(Alert::getSeverity)
                .max(Enum::compareTo)
                .map(Enum::name)
                .orElse("NONE");
    }
}
