import { Injectable, signal } from '@angular/core';
import { TenantDTO } from '../models/tenant.model';

@Injectable({
  providedIn: 'root'
})
export class TenantSelectionService {
  selectedTenant = signal<TenantDTO | null>(null);
  
  setTenant(tenant: TenantDTO) {
    this.selectedTenant.set(tenant);
    localStorage.setItem('tenantId', tenant.id!);
  }

  clearTenant() {
    this.selectedTenant.set(null);
  }
  getTenantId(): string {
    return localStorage.getItem('tenantId') || '';
  }

  setTenantCode(code: string) {
    localStorage.setItem('tenantCode', code);
  }

  getTenantCode(): string {
    return localStorage.getItem('tenantCode') || '';
  }

  extractAndStoreTenantCodeFromUrl(): string | null {
    try {
      const hostname = window.location.hostname;
      // Pattern: trial-{code}.convozoom.com or trial-{code}.domain.com
      const match = hostname.match(/^trial-([a-z0-9]+)\./i);
      
      if (match && match[1]) {
        const tenantCode = match[1];
        this.setTenantCode(tenantCode);
        return tenantCode;
      }else {
          var parts = hostname.split('.');  
          const firstPart = parts[0];
          if(firstPart !== 'convozoom' && firstPart !== 'auth' && firstPart !== 'localhost'){
            this.setTenantCode( firstPart);
          }
          
      }
    } catch (error) {
    }
    return null;
  }

}

