import { TenantDTO } from "./tenant.model";

export interface ContactDTO {
  id?: string;
  firstname: string;
  lastname: string;
  phone?: string;
  email: string;
  function?: string;
  byDefault: boolean;
  tenant?: TenantDTO;
}