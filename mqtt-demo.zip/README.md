# 🚀 MQTT Demo — Spring Boot + Mosquitto + Device Simulator

Mini projet d'intégration MQTT avec Spring Boot, un broker Mosquitto (Docker),
et un simulateur de device IoT **séparé**.

## Architecture

```
┌───────────────────────┐          ┌──────────────┐          ┌─────────────────────┐
│  mqtt-device-simulator│  publish │  Mosquitto   │subscribe │  spring-mqtt        │
│  (Spring Boot + Paho) │ ───────▶ │  Broker      │ ◀─────── │  (Spring Boot)      │
│                       │          │  :1883       │          │                     │
└───────────────────────┘          └──────────────┘          └─────────────────────┘
                                                                    │
                                                               Console Output
```

## Prérequis

- Java 17+
- Maven 3.8+
- Docker & Docker Compose

## Démarrage rapide

### 1. Lancer Mosquitto

```bash
docker-compose up -d
```

### 2. Lancer le serveur Spring Boot (subscriber) — Terminal 1

```bash
cd spring-mqtt
mvn spring-boot:run
```

### 3. Lancer le simulateur — Terminal 2

```bash
cd mqtt-device-simulator
mvn spring-boot:run
```

Tu devrais voir les messages apparaître dans la console du **spring-mqtt**.

## Topics MQTT

| Topic                  | Données                           | Fréquence |
|------------------------|-----------------------------------|-----------|
| `devices/temperature`  | Température (°C) avec alertes     | ~3s       |
| `devices/humidity`     | Humidité (%) avec alertes         | ~3s       |
| `devices/gps`          | Coordonnées GPS (autour de Gabès) | ~3s       |
| `devices/status`       | ONLINE / MAINTENANCE / ERROR      | ~3s       |

## Sortie console (spring-mqtt)

```
═══════════════════════════════════════════════
📨 MQTT Message Received  [#5]
📌 Topic   : devices/temperature
📦 Raw     : {"device_id":"DEVICE-001","sensor_type":"temperature","value":38.72,"unit":"°C",...}
🌡️  TEMPERATURE
   Device    : DEVICE-001
   Value     : 38.72 °C
   Timestamp : 2025-01-15T14:32:10
═══════════════════════════════════════════════
```

## Tester manuellement

```bash
# Publier un message
docker exec mosquitto-broker mosquitto_pub \
  -t "devices/temperature" \
  -m '{"device_id":"MANUAL","sensor_type":"temperature","value":42.5,"unit":"°C","timestamp":"2025-01-15T10:00:00"}'

# Écouter tous les topics
docker exec mosquitto-broker mosquitto_sub -t "devices/#" -v
```

## Structure

```
mqtt-demo/
├── docker-compose.yml
├── mosquitto/config/mosquitto.conf
│
├── spring-mqtt/                          ← Subscriber (reçoit les messages)
│   ├── pom.xml
│   └── src/main/java/com/actia/mqttdemo/
│       ├── MqttDemoApplication.java
│       ├── config/MqttConfig.java
│       ├── model/SensorData.java
│       └── service/
│           ├── MqttMessageHandler.java
│           └── MqttPublisherService.java
│
└── mqtt-device-simulator/                ← Publisher (simule un device IoT)
    ├── pom.xml
    └── src/main/java/com/actia/simulator/
        ├── SimulatorApplication.java
        ├── DeviceSimulator.java
        └── model/SensorData.java
```

## Technologies

- **Spring Boot 3.2** + Spring Integration MQTT
- **Eclipse Paho** (MQTT client)
- **Mosquitto 2.0** (broker Docker)
- **Jackson** (JSON)
- **Lombok**
