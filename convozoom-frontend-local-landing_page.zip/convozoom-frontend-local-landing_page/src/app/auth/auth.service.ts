import { Injectable, inject } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom, Observable, switchMap } from 'rxjs';
import { environment } from '../../environments/environment';
import { RoleService } from './role.service';
import { AppConfigService } from '../config/app-config.service';
import { TrialTenantPayload } from '../models/trialTenant.model';

@Injectable({
	providedIn: 'root'
})
export class AuthService {
	private keycloakService = inject(KeycloakService);
	private http = inject(HttpClient);
	private roleService = inject(RoleService);
	private appConfigService = inject(AppConfigService);

	private normalizeRoleName(name: string): string {
		return (name || '').toLowerCase().replace(/[\s_-]+/g, '-');
	}

	/**
	 * Attempts to authenticate with username and password
	 * This method will redirect to Keycloak login page if direct auth is not possible
	 */
	async loginWithCredentials(username: string, password: string): Promise<boolean> {
		try {
			// Try to authenticate directly with Keycloak
			const token = await this.getTokenDirectly(username, password);
			if (token) {
				// Store the token and redirect
				localStorage.setItem('keycloak_token', token);
				return true;
			}
		} catch (error) {
			console.error('Direct authentication failed:', error);
		}

		// Fallback: redirect to Keycloak login page
		await this.keycloakService.login({
			redirectUri: window.location.origin + '/home'
		});
		return false;
	}

	/**
	 * Utility to trigger Keycloak hosted login
	 */
	async loginRedirect(redirectUri: string): Promise<void> {
		await this.keycloakService.login({ redirectUri });
	}

	/**
	 * Attempts to get a token directly from Keycloak
	 */
	private async getTokenDirectly(username: string, password: string): Promise<string | null> {
		try {
			const tokenUrl = `${environment.keycloak.url}/realms/${environment.keycloak.realm}/protocol/openid-connect/token`;
			
			const body = new URLSearchParams();
			body.set('grant_type', 'password');
			body.set('client_id', environment.keycloak.clientId);
			body.set('username', username);
			body.set('password', password);

			const headers = new HttpHeaders({
				'Content-Type': 'application/x-www-form-urlencoded'
			});

			const response = await firstValueFrom(this.http.post<any>(tokenUrl, body.toString(), { headers }));
			
			if (response && response.access_token) {
				return response.access_token;
			}
		} catch (error) {
			console.error('Error getting token directly:', error);
		}

		return null;
	}

	/**
	 * Logs out the current user
	 */
	async logout(): Promise<void> {
		try {
			await this.keycloakService.logout();
		} catch (error) {
			console.error('Logout error:', error);
		}
	}

	/**
	 * Checks if user is authenticated
	 */
	async isAuthenticated(): Promise<boolean> {
		try {
			return await this.keycloakService.isLoggedIn();
		} catch (error) {
			console.error('Error checking authentication:', error);
			return false;
		}
	}

	/**
	 * Roles helpers
	 */
	async getUserRoles(): Promise<string[]> { return this.roleService.getAllRoles(); }
	async hasRole(role: string): Promise<boolean> { return this.roleService.hasRole(role); }
	async hasAnyRole(rolesToCheck: string[]): Promise<boolean> { return this.roleService.hasAnyRole(rolesToCheck); }
	async isSalesManager(): Promise<boolean> { return this.hasAnyRole(['sales manager', 'sales-manager', 'sales_manager']); }
	async isTenantAdmin(): Promise<boolean> { return this.hasAnyRole(['tenant_admin', 'tenant-admin', 'tenant admin']); }
	async isSuperAdmin(): Promise<boolean> { return this.hasAnyRole(['admin', 'admin', 'super_admin']); }

	/**
	 * Gets the current user profile
	 */
	async getUserProfile(): Promise<any> {
		try {
			// Prefer OIDC userinfo endpoint to avoid Keycloak Account CORS
			const kc: any = (this.keycloakService as any).getKeycloakInstance?.() || (this.keycloakService as any);
			const info = await kc.loadUserInfo();
			return {
				username: info?.preferred_username,
				email: info?.email,
				firstName: info?.given_name,
				lastName: info?.family_name
			};
		} catch (userinfoError) {
			// Fallback to loadUserProfile if userinfo is unavailable
			try {
				return await this.keycloakService.loadUserProfile();
			} catch (error) {
				console.error('Error loading user profile:', error);
				return null;
			}
		}
	}

	/**
	 * Gets the current access token
	 */
	async getToken(): Promise<string | null> {
		try {
			return await this.keycloakService.getToken();
		} catch (error) {
			console.error('Error getting token:', error);
			return null;
		}
	}

	/**
	 * Refreshes the current token
	 */
	async refreshToken(): Promise<boolean> {
		try {
			await this.keycloakService.updateToken(-1);
			return true;
		} catch (error) {
			console.error('Error refreshing token:', error);
			return false;
		}
	}

	/**
	 * Creates a free trial tenant account
	 */
	createTrialTenant(payload: TrialTenantPayload):Observable<TrialTenantPayload> {
		return this.appConfigService.getApiBaseUrl().pipe(
			switchMap(baseUrl => {
				const url = `${baseUrl}/tenants/trial`;
				const headers = new HttpHeaders({
					'Content-Type': 'application/json'
				});
				return this.http.post<TrialTenantPayload>(url, payload, { headers });
			})
		);
	}
}



