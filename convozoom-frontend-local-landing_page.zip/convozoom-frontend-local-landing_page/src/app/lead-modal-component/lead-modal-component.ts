import { CommonModule, Location } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormsModule } from '@angular/forms';
import { Lead, LeadStatus } from '../models/lead.model';
import { CustomDropdown } from "../shared/custom-dropdown/custom-dropdown";
import { LeadService } from '../services/lead-service';
import { Activity, ActivityType } from '../models/activity.model';
import { ActivityService } from '../services/activity-service';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { UserService } from '../services/user-service';
import { UserDTO } from '../models/user.model';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-lead-modal-component',
  standalone: true,
  imports: [CommonModule, FormsModule, CustomDropdown],
  templateUrl: './lead-modal-component.html',
  styleUrls: ['./lead-modal-component.css']
})
export class LeadModalComponent implements OnChanges {
  @Output() createLead = new EventEmitter<Lead>();
  @Output() isFormOnlyChange = new EventEmitter<boolean>();

  @Input() isOpen = false;
  @Output() closed = new EventEmitter<void>();
  @Input() leadForm: Lead = {} as Lead;
  @Input() isFormOnly = false;


  status = Object.values(LeadStatus);
  priorities = ['Low', 'Medium', 'High', 'Urgent'];
  firstName = '';
  lastName = '';
  notes = '';
  users: UserDTO[] = [];
  assigneeOptions: string[] = ['Unassigned'];
  activity: Activity = {} as Activity;
  leadSaved: boolean = false;
  currentDate: Date = new Date();
  savedLeadName: string = '';
  activities: Activity[] = [];
  originalStatus: LeadStatus | undefined;
  showDeleteConfirm = false;
  leadIdToDelete?: string;
  colorsVars = [
    'var(--pf-t--global--color--nonstatus--purple--clicked)',
    'var(--pf-t--global--border--color--nonstatus--purple--clicked)',
    'var(--pf-t--global--border--color--status--info--default)',
    'var(--pf-t--global--border--color--status--info--clicked)'
  ];
  colorsMap: { [status: string]: string } = {};
  
  // Email matching for edit permission
  currentUserEmail: string = '';
  isEmailMatched: boolean = true;


  constructor(
    private leadService: LeadService,
    private activityService: ActivityService,
    private location: Location,
    private tenantSelection: TenantSelectionService,
    private userService: UserService,
    private authService: AuthService
  ) {
    this.initColorsMap();
    this.loadCurrentUserEmail();
    this.resetForm();
  }

  initColorsMap() {
    this.colorsMap = {};
    this.status.forEach((s, index) => {
      this.colorsMap[s] = this.colorsVars[index % this.colorsVars.length];
    });
  }

  private loadCurrentUserEmail(): void {
    this.authService.getUserProfile().then(profile => {
      this.currentUserEmail = profile?.email || '';
      this.checkEmailMatch();
    }).catch(err => {
      console.error('Error loading user profile:', err);
      this.currentUserEmail = '';
    });
  }

  checkEmailMatch(): void {
    // For new leads (no id), always allow editing
    if (!this.leadForm?.id) {
      this.isEmailMatched = true;
      return;
    }

    // If no assignee, allow editing
    if (!this.leadForm.assignedTo || this.leadForm.assignedTo === 'Unassigned') {
      this.isEmailMatched = true;
      return;
    }

    // Find the assigned user's email from the users list
    const assignedUser = this.users.find(u => {
      const fullName = `${u.firstname} ${u.lastname}`.trim();
      return fullName === this.leadForm.assignedTo;
    });

    if (assignedUser && assignedUser.email) {
      this.isEmailMatched = this.currentUserEmail.toLowerCase() === assignedUser.email.toLowerCase();
    } else {
      // If can't find user, allow editing
      this.isEmailMatched = true;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    // When leadForm or isOpen changes and modal is opened with an existing lead
    if (changes['isOpen'] && this.isOpen && this.leadForm?.id) {
      this.originalStatus = this.leadForm.status;
      this.leadSaved = true;
      this.savedLeadName = this.leadForm.fullName || '';
      this.getAllActivitiesById(this.leadForm.id);
      this.syncAuxFieldsFromLead();
      this.loadUsers();
    } else if (changes['leadForm'] && this.isOpen && this.leadForm?.id) {
      this.originalStatus = this.leadForm.status;
      this.leadSaved = true;
      this.savedLeadName = this.leadForm.fullName || '';
      this.getAllActivitiesById(this.leadForm.id);
      this.syncAuxFieldsFromLead();
      this.loadUsers();
    } else if (changes['isOpen'] && this.isOpen && !this.leadForm?.id) {
      // New lead - clear activities
      this.activities = [];
      this.leadSaved = false;
      this.savedLeadName = '';
      this.syncAuxFieldsFromLead();
      this.loadUsers();
    }
  }

  open(lead?: Lead, formOnly: boolean = true) {
    this.isOpen = true;
    this.isFormOnly = formOnly;
    this.leadForm = lead ? { ...lead } : { status: this.status[0] } as Lead;
    this.originalStatus = this.leadForm.status; // Track original status
    this.syncAuxFieldsFromLead();
    this.loadUsers();

    // Set leadSaved based on whether this is an existing lead
    this.leadSaved = !!lead?.id;
    this.savedLeadName = lead?.fullName || '';

    if (lead?.id) {
      this.getAllActivitiesById(lead.id);
    } else {
      this.activities = [];
    }
  }

  private loadUsers() {
    const tenantId = this.tenantSelection.selectedTenant()?.id || '';
    const loader$ = tenantId ? this.userService.getUsersByTenant(tenantId) : this.userService.getAllUsers();
    loader$.subscribe({
      next: (users) => {
        this.users = users || [];
        const names = this.users.map(u => `${u.firstname} ${u.lastname}`.trim()).filter(n => n.length > 0);
        this.assigneeOptions = ['Unassigned', ...names];
        // Ensure assignedTo matches an option or defaults
        if (!this.leadForm.assignedTo || !this.assigneeOptions.includes(this.leadForm.assignedTo)) {
          this.leadForm.assignedTo = 'Unassigned';
        }
        // Check email match after users are loaded
        this.checkEmailMatch();
      },
      error: (err) => console.error('Error loading users for assignee', err)
    });
  }

  close() {
    this.isOpen = false;
    this.leadSaved = false;
    this.originalStatus = undefined;
    this.resetForm();
    this.location.replaceState('/lead-board');
    this.closed.emit();
  }

  resetForm() {
    this.leadForm = { status: this.status[0] } as Lead;
    this.activity = {} as Activity;
    this.originalStatus = undefined;
    this.firstName = '';
    this.lastName = '';
    this.notes = '';
  }


  saveLead() {
    this.updateFullNameFromParts();
    this.leadForm.customFields = this.notes?.trim();

    if (!this.leadForm.status) {
      this.leadForm.status = this.status[0];
    }

    if (!this.leadForm.fullName?.trim()) {
      return;
    }

    const isUpdate = !!this.leadForm.id;
    const wasAlreadySaved = this.leadSaved;
    const statusChanged = this.originalStatus && this.originalStatus !== this.leadForm.status;
    this.leadForm.tenantId = this.tenantSelection.selectedTenant()?.id || '';

    if (this.leadForm.id) {
      // Update existing lead - create activity only if status changed
      this.leadService.updateLead(this.leadForm.id, this.leadForm).subscribe({
        next: updatedLead => {
          this.leadForm = { ...updatedLead };
          this.syncAuxFieldsFromLead();
          this.savedLeadName = updatedLead.fullName;
          this.leadSaved = true;
          this.isFormOnly = false;

          // Create activity if status changed
          if (statusChanged) {
            this.createActivityForStatusChange(
              updatedLead,
              updatedLead.status
            );
          }

          // Update original status after save
          this.originalStatus = updatedLead.status;
      
          // Close modal after successful update
          this.close();
        },
        error: err => console.error('Error updating lead:', err)
      });
    } else {
      // Create new lead - only create activity on first save
      this.leadForm.id = Math.random().toString(36).substring(2, 18);
      this.leadForm.createdAt = new Date().toISOString();
      this.leadService.createLead(this.leadForm).subscribe(createdLead => {
        this.leadForm = { ...createdLead };
        this.syncAuxFieldsFromLead();
        this.savedLeadName = this.leadForm.fullName;
        this.leadSaved = true;
        this.isFormOnly = false;
        this.location.replaceState('/lead-board');
          });
      // this.createLead.emit(this.leadForm);

    }
  }

  createActivity(lead: Lead, manualText?: string, type?: ActivityType) {
    let summaryText: string;

    if (manualText) {
      summaryText = manualText;
    } else {
      summaryText = this.activity.details?.trim() ? 'Contact customer' : 'Activity';
    }

    // Only create new activity, no updates
    const newActivity: Activity = {
      id: Math.random().toString(36).substring(2, 18),
      tenantId: lead.tenantId,
      lead: lead,
      summary: summaryText,
      details: this.activity.details,
      type: type || this.activity.type || ActivityType.CALL,
      createdAt: new Date().toISOString(),
      dateTime: new Date().toISOString()
    };
    this.activityService.createActivity(newActivity).subscribe({
      next: created => {
        this.activities.unshift(created);
        this.activity = {} as Activity;
          },
      error: err => console.error('Error creating activity', err)
    });
  }

  onFirstNameChange(value: string) {
    this.firstName = value || '';
    this.updateFullNameFromParts();
  }

  onLastNameChange(value: string) {
    this.lastName = value || '';
    this.updateFullNameFromParts();
  }

  private updateFullNameFromParts() {
    const combined = `${this.firstName} ${this.lastName}`.trim();
    this.leadForm.fullName = combined;
  }

  private syncAuxFieldsFromLead() {
    const fullName = (this.leadForm?.fullName || '').trim();
    if (fullName) {
      const [first, ...rest] = fullName.split(' ');
      this.firstName = first || '';
      this.lastName = rest.join(' ').trim();
    } else {
      this.firstName = '';
      this.lastName = '';
    }

    this.notes = this.leadForm?.customFields || '';
  }

  enableEdit() {
    this.isFormOnly = true;
  }

  keepChanges() {
    this.savedLeadName = this.leadForm.fullName || '';
    this.isFormOnly = false;
  }

  getStatusColor(status: LeadStatus): string {
    if (!this.leadForm || !this.leadForm.status) {
      return '--pf-t--global--background--color--disabled--default';
    }

    const statusOrder = Object.values(LeadStatus);
    const currentIndex = statusOrder.indexOf(this.leadForm.status);
    const statusIndex = statusOrder.indexOf(status);

    return statusIndex <= currentIndex ? this.colorsMap[status]
      : '--pf-t--global--background--color--disabled--default';
  }



  deleteLeadConfirm(id?: string) {
    if (!id) return;
    this.leadIdToDelete = id;
    this.showDeleteConfirm = true;
  }

  confirmDelete() {
    if (!this.leadIdToDelete) return;

    this.leadService.deleteLeadWithActivities(this.leadIdToDelete).subscribe({
      next: () => {
        // Mise à jour locale
        this.showDeleteConfirm = false;
        this.closed.emit();
          },
      error: (err) => {
        console.error('Erreur suppression lead:', err);
        this.showDeleteConfirm = false;
      }
    });
  }

  cancelDelete() {
    this.showDeleteConfirm = false;
    this.leadIdToDelete = undefined;
  }


  getAllActivitiesById(leadId: string) {
    this.activityService.getAllActivities().subscribe({
      next: allActivities => {
        this.activities = allActivities
          .filter(a => a.lead?.id === leadId)
          .sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime());
          },
      error: err => console.error('Error loading activities', err)
    });
  }

  createActivityForStatusChange(lead: Lead, newStatus: LeadStatus) {
    const newActivity: Activity = {
      id: Math.random().toString(36).substring(2, 18),
      tenantId: lead.tenantId,
      lead: lead,
      summary: `Status changed to ${newStatus}`,
      details: '',
      type: ActivityType.CALL,
      createdAt: new Date().toISOString(),
      dateTime: new Date().toISOString()
    };

    this.activityService.createActivity(newActivity).subscribe({
      next: created => {
        // Add to local activities list and trigger change detection
        this.activities.unshift(created);
          },
      error: err => console.error('Error creating activity for status change:', err)
    });
  }


}