import { Routes } from '@angular/router';
import { authGuard } from './auth/auth.guard';
import { TenantForm } from './tenant-form/tenant-form';
import { TenantList } from './tenant-list/tenant-list';
import { PlanCardComponent } from './plan-card/plan-card.component';
import { Settings } from './settings/settings';
import { guestGuard } from './auth/guest.guard';
import { LeadBoard } from './lead-board/lead-board';
import { MainLayoutComponent } from './main-layout-component/main-layout-component';
import { DealBoard } from './deal-board/deal-board';
export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./landing-page/landing-page').then((m) => m.LandingPage),
    canActivate: [guestGuard],
  },
  {
    path: 'home',
    loadComponent: () => import('./home/home.component').then((m) => m.HomeComponent),
    canActivate: [authGuard],
  },
  {
    path: 'free-trial',
    loadComponent: () =>
      import('./auth/free-trial/free-trial-page').then((m) => m.FreeTrialPageComponent),
    canActivate: [guestGuard],
  },
  {
    path: 'auth',
    children: [
      //  {
      //     path: 'login',
      //     loadComponent: () => import('./auth/login/login.component').then(m => m.LoginComponent)
      //   },
      {
        path: 'forgot-password',
        loadComponent: () =>
          import('./auth/forgot-password/forgot-password.component').then(
            (m) => m.ForgotPasswordComponent
          ),
      },
    ],
  },
  {
    path: 'protected',
    loadComponent: () =>
      import('./protected/protected.component').then((m) => m.ProtectedComponent),
    canActivate: [authGuard],
  },
  {
    path: 'profile',
    loadComponent: () => import('./profile/profile.component').then((m) => m.ProfileComponent),
    canActivate: [authGuard],
  },
  {
    path: 'management',
    loadComponent: () =>
      import('./management/management.component').then((m) => m.ManagementComponent),
    canActivate: [authGuard],
  },
  {
    path: 'user-management',
    loadComponent: () =>
      import('./user-management/user-management.component').then((m) => m.UserManagementComponent),
    canActivate: [authGuard],
  },

  { path: 'tenant', component: TenantList, canActivate: [authGuard] },

  { path: 'plan', component: PlanCardComponent, canActivate: [authGuard] },

  { path: 'tenant/add', component: TenantForm, canActivate: [authGuard] },

  { path: 'tenant/:id', component: TenantForm, canActivate: [authGuard] },

  { path: 'settings', component: Settings, canActivate: [authGuard] },

  {
    path: 'templates',
    loadComponent: () => import('./template/template').then((m) => m.TemplatesTable),
    canActivate: [authGuard],
  },
  {
    path: 'deal-list',
    loadComponent: () => import('./deal-list/deal-list').then((m) => m.DealList),
    canActivate: [authGuard],
  },
  // { path: 'lead-board', component: LeadBoard,   data: { breadcrumb: 'Leads' } },
  {
    path: 'guest',
    loadComponent: () => import('./guest/guest').then((m) => m.GuestPage),
    canActivate: [guestGuard],
  },
  {
    path: 'meeting',
    loadComponent: () => import('./meeting/meeting').then((m) => m.Meeting),
    canActivate: [guestGuard],
  },

  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'lead-board',
        component: LeadBoard,
        canActivate: [authGuard],
        data: { breadcrumb: 'Leads' }
      }
      , {
        path: 'deal-board',
        component: DealBoard,
        canActivate: [authGuard],
        data: { breadcrumb: 'deals' }
      }
    ]
  }
];
