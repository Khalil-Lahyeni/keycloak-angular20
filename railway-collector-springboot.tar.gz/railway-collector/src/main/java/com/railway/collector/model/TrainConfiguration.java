package com.railway.collector.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrainConfiguration {

    private boolean visible;
    private String ccu1Ip;
    private String ccu2Ip;
}
