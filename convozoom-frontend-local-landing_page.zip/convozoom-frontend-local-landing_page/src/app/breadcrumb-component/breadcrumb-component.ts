import { Component } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';

@Component({
  selector: 'app-breadcrumb-component',
  imports: [RouterModule],
  templateUrl: './breadcrumb-component.html',
  styleUrl: './breadcrumb-component.css'
})
export class BreadcrumbComponent {

  label = '';

  constructor(private route: ActivatedRoute) {
    this.label = this.findBreadcrumb(this.route.root);
  }

  private findBreadcrumb(route: ActivatedRoute): string {
    if (route.snapshot.data['breadcrumb']) {
      return route.snapshot.data['breadcrumb'];
    }
    for (const child of route.children) {
      const label = this.findBreadcrumb(child);
      if (label) {
        return label;
      }
    }
    return '';
  }
}
