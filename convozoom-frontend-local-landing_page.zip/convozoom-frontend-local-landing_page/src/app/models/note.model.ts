import { Deal } from "./deal.model";
import { Lead } from "./lead.model";

export interface Note {
    id?: string;
    tenantId: string;
    description: string;
    createdAt: string;
    createdBy?: string;
    lead?: Lead;
    deal?: Deal;
}
