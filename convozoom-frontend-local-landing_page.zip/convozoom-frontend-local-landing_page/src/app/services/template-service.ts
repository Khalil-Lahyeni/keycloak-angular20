import { Injectable , inject} from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { TemplateDTO } from '../models/template.model';
import { AppConfigService } from '../config';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  appConfigService = inject(AppConfigService);
  private  base : string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService ) { 
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllTemplates(tenantId: string): Observable<TemplateDTO[]> {
    return this.http.get<TemplateDTO[]>(`${this.base}/templates/tenant/${tenantId}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllTemplates');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving templates');
        return throwError(() => errorInfo);
      })
    );
  }

  createTemplate(body: TemplateDTO): Observable<TemplateDTO> {
    return this.http.post<TemplateDTO>(`${this.base}/templates`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createTemplate');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the template');
        return throwError(() => errorInfo);
      })
    );
  }

  getTemplate(id: string): Observable<TemplateDTO> {
    return this.http.get<TemplateDTO>(`${this.base}/templates/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getTemplate');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the template');
        return throwError(() => errorInfo);
      })
    );
  }

  updateTemplate(id: string, body: TemplateDTO): Observable<TemplateDTO> {
    return this.http.put<TemplateDTO>(`${this.base}/templates/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateTemplate');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the template');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateTemplate(id: string, body: Partial<TemplateDTO>): Observable<TemplateDTO> {
    return this.http.patch<TemplateDTO>(`${this.base}/templates/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateTemplate');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the template');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteTemplate(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/templates/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteTemplate');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the template');
        return throwError(() => errorInfo);
      })
    );
  }
}