import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, RouterModule } from '@angular/router';
import { filter } from 'rxjs';
import { BreadcrumbComponent } from '../breadcrumb-component/breadcrumb-component';

@Component({
  selector: 'app-main-layout-component',
  imports: [CommonModule, RouterModule, BreadcrumbComponent],
  templateUrl: './main-layout-component.html',
  styleUrl: './main-layout-component.css'
})
export class MainLayoutComponent {
  showBreadcrumb = false;

  constructor(private router: Router, private route: ActivatedRoute) {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.showBreadcrumb = this.hasBreadcrumb(this.route.root);
      });
  }

  private hasBreadcrumb(route: ActivatedRoute): boolean {
    if (route.snapshot.data['breadcrumb']) {
      return true;
    }
    return route.children.some(child => this.hasBreadcrumb(child));
  }
}
