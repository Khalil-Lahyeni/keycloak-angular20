package com.railway.collector.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Alert {

    public enum Severity {
        INFO, WARNING, CRITICAL, EMERGENCY
    }

    private String alertType;
    private Severity severity;
    private String trainId;
    private String message;
    private String details;

    @Builder.Default
    private Instant timestamp = Instant.now();
}
