package com.railway.collector.service.publisher;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.influxdb.client.WriteApiBlocking;
import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import com.railway.collector.config.InfluxProperties;
import com.railway.collector.model.Alert;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Couche 4b — Publication InfluxDB.
 * Écrit les données comme time-series pour l'historique.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InfluxPublisherService {

    private final WriteApiBlocking writeApi;
    private final InfluxProperties influxProperties;
    private final ObjectMapper objectMapper;

    // ─── Train Status ───

    public void writeTrainStatus(String trainId, Map<String, Object> data) {
        try {
            Point point = Point.measurement("train_status")
                    .addTag("train_id", trainId)
                    .addTag("mission", str(data, "mission"))
                    .addTag("current_station", str(data, "currentStation"))
                    .addField("pacis_status", str(data, "pacisStatus"))
                    .addField("cctv_status", str(data, "cctvStatus"))
                    .addField("rearview_status", str(data, "rearViewStatus"))
                    .addField("health_score", intVal(data, "_healthScore"))
                    .addField("alert_count", intVal(data, "_alertCount"))
                    .addField("next_station", str(data, "nextStation"))
                    .addField("destination", str(data, "destination"))
                    .addField("baseline", str(data, "baseline"))
                    .addField("update_status", str(data, "updateStatus"))
                    .time(Instant.now(), WritePrecision.MS);

            writeApi.writePoint(influxProperties.getBucket(),
                    influxProperties.getOrg(), point);
            log.debug("InfluxDB: wrote train_status for {}", trainId);
        } catch (Exception e) {
            log.error("InfluxDB write error (status): {}", e.getMessage());
        }
    }

    // ─── Train Configuration ───

    public void writeTrainConfiguration(String trainId, Map<String, Object> data) {
        try {
            Point point = Point.measurement("train_configuration")
                    .addTag("train_id", trainId)
                    .addField("visible", Boolean.TRUE.equals(data.get("visible")))
                    .addField("ccu1_ip", str(data, "ccu1Ip"))
                    .addField("ccu2_ip", str(data, "ccu2Ip"))
                    .time(Instant.now(), WritePrecision.MS);

            writeApi.writePoint(influxProperties.getBucket(),
                    influxProperties.getOrg(), point);
            log.debug("InfluxDB: wrote train_configuration for {}", trainId);
        } catch (Exception e) {
            log.error("InfluxDB write error (config): {}", e.getMessage());
        }
    }

    // ─── Media Database ───

    @SuppressWarnings("unchecked")
    public void writeMediaDatabase(Map<String, Object> data) {
        try {
            String dbName = str(data, "name");
            List<Map<String, Object>> versions =
                    (List<Map<String, Object>>) data.getOrDefault("versions", List.of());
            long activeCount = versions.stream()
                    .filter(v -> Boolean.TRUE.equals(v.get("is_active")))
                    .count();

            Point point = Point.measurement("media_database")
                    .addTag("db_name", dbName)
                    .addTag("device_ip", str(data, "deviceIp"))
                    .addField("total_versions", versions.size())
                    .addField("active_versions", (int) activeCount)
                    .time(Instant.now(), WritePrecision.MS);

            writeApi.writePoint(influxProperties.getBucket(),
                    influxProperties.getOrg(), point);
            log.debug("InfluxDB: wrote media_database for {}", dbName);
        } catch (Exception e) {
            log.error("InfluxDB write error (media): {}", e.getMessage());
        }
    }

    // ─── Train Message ───

    public void writeTrainMessage(String trainId, Map<String, Object> data) {
        try {
            Point point = Point.measurement("train_message")
                    .addTag("train_id", trainId)
                    .addTag("message_type", str(data, "messageType"))
                    .addField("message_id", intVal(data, "messageId"))
                    .addField("name", str(data, "name"))
                    .time(Instant.now(), WritePrecision.MS);

            writeApi.writePoint(influxProperties.getBucket(),
                    influxProperties.getOrg(), point);
            log.debug("InfluxDB: wrote train_message for {}", trainId);
        } catch (Exception e) {
            log.error("InfluxDB write error (message): {}", e.getMessage());
        }
    }

    // ─── Alert ───

    public void writeAlert(Alert alert) {
        try {
            Point point = Point.measurement("train_alert")
                    .addTag("train_id", alert.getTrainId())
                    .addTag("alert_type", alert.getAlertType())
                    .addTag("severity", alert.getSeverity().name())
                    .addField("message", alert.getMessage())
                    .addField("details", alert.getDetails() != null ? alert.getDetails() : "")
                    .time(Instant.now(), WritePrecision.MS);

            writeApi.writePoint(influxProperties.getBucket(),
                    influxProperties.getOrg(), point);
        } catch (Exception e) {
            log.error("InfluxDB write error (alert): {}", e.getMessage());
        }
    }

    // ─── Helpers ───

    private String str(Map<String, Object> data, String key) {
        Object val = data.get(key);
        return val != null ? val.toString() : "unknown";
    }

    private int intVal(Map<String, Object> data, String key) {
        Object val = data.get(key);
        if (val instanceof Number n) return n.intValue();
        return 0;
    }
}
