import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../config';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ErrorHandlerService } from './error-handler.service';
import { Note } from '../models/note.model';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NoteService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllNotes(): Observable<Note[]> {
    return this.http.get<Note[]>(`${this.base}/notes`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllNotes');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving note');
        return throwError(() => errorInfo);
      })
    );
  }

  getNote(id: string): Observable<Note> {
    return this.http.get<Note>(`${this.base}/notes/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getNote');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the note');
        return throwError(() => errorInfo);
      })
    );
  }

  createNote(body: Note): Observable<Note> {
    return this.http.post<Note>(`${this.base}/notes`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createNote');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the note');
        return throwError(() => errorInfo);
      })
    );
  }

  updateNote(id: string, body: Note): Observable<Note> {
    return this.http.put<Note>(`${this.base}/notes/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateNote');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the note');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteNote(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/notes/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteNote');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the note');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateNote(id: string, body: Partial<Note>): Observable<Note> {
    return this.http.patch<Note>(`${this.base}/notes/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateNote');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the note');
        return throwError(() => errorInfo);
      })
    );
  }
}
