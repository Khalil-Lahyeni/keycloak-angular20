import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-custom-dropdown',
  imports: [CommonModule, FormsModule],
  templateUrl: './custom-dropdown.html',
  styleUrl: './custom-dropdown.css'
})
export class CustomDropdown<T> {
  @Input() options: T[] = [];
  @Input() selectedOption!: T;
  @Input() label!: string;
  @Input() placeholder!: string;
  @Output() selectedOptionChange = new EventEmitter<T>();

  isDropdownOpen = false;

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  selectOption(option: T) {
    this.selectedOption = option;
    this.selectedOptionChange.emit(option);
    this.isDropdownOpen = false;
  }
}
