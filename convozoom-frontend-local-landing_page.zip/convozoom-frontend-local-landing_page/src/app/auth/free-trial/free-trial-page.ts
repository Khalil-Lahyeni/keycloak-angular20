import { AfterViewInit, Component, ElementRef, inject, OnInit, ViewChild } from '@angular/core';
import { HeroPanelComponent } from '../shared/hero-panel';
import { AuthService } from '../../auth/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';
import { TrialTenantPayload } from '../../models/trialTenant.model';

@Component({
  selector: 'app-free-trial-page',
  standalone: true,
  imports: [HeroPanelComponent, CommonModule, ReactiveFormsModule],
  templateUrl: './free-trial-page.html',
  styleUrls: ['./free-trial-page.scss']
})
export class FreeTrialPageComponent implements OnInit, AfterViewInit {
  private auth = inject(AuthService);
  private router = inject(Router);
  private fb = inject(FormBuilder);
  @ViewChild('freeTrialFormHTMLElement', { read: ElementRef, static: false })
  freeTrialFormHTMLElement!: ElementRef;
  isSubmitting = false;
  submittedOnce = false;
  errorMessage = '';
  successMessage = '';
  showPassword = false;
  showConfirm = false;
  isTypeDropdownOpen = false;
  
  tenantTypes = ['Agency', 'Broker', 'Developer', 'Investor'];

 freeTrialForm = this.fb.group({
    firstname: this.fb.control('', { validators: [Validators.required] }),
    lastname: this.fb.control('', { validators: [Validators.required] }),
    email: this.fb.control('', { validators: [Validators.required, Validators.email] }),
    type: this.fb.control('', { validators: [Validators.required] }),
    password: this.fb.control('', { validators: [Validators.required, Validators.minLength(6)] }),
    'password-confirm': this.fb.control('', { validators: [Validators.required, Validators.minLength(6)] })
});





ngOnInit(): void {
  // Initialization logic if needed
}

ngAfterViewInit() {
  console.log(this.freeTrialFormHTMLElement);
}

// Derived states for password UI
get passwordHasValue(): boolean { return !!this.freeTrialForm.controls.password.value; }
get criteria() {
  const pwd = this.freeTrialForm.controls.password.value || '';
  return {
    length12: pwd.length >= 8,
    lower: /[a-z]/.test(pwd),
    upper: /[A-Z]/.test(pwd),
    digitOrSymbol: /[0-9\W_]/.test(pwd)
  };
}
get allCriteriaMet(): boolean { const c = this.criteria; return c.length12 && c.lower && c.upper && c.digitOrSymbol; }
get passwordMismatch(): boolean {
  const pass = this.freeTrialForm.controls.password.value || '';
  const confirm = this.freeTrialForm.controls['password-confirm'].value || '';
  return !!pass && !!confirm && pass !== confirm;
}
get confirmShowsSuccess(): boolean {
  const confirm = this.freeTrialForm.controls['password-confirm'].value || '';
  return !!confirm && !this.passwordMismatch;
}

toggleShowPassword(): void { this.showPassword = !this.showPassword; }
toggleShowConfirm(): void { this.showConfirm = !this.showConfirm; }

toggleTypeDropdown(): void {
  if (!this.isSubmitting) {
    this.isTypeDropdownOpen = !this.isTypeDropdownOpen;
  }
}

selectType(type: string): void {
  this.freeTrialForm.controls.type.setValue(type);
  this.freeTrialForm.controls.type.markAsTouched();
  this.isTypeDropdownOpen = false;
}

onSubmit() {
  this.submittedOnce = true;
  this.errorMessage = '';
  this.successMessage = '';

  if (this.freeTrialForm.valid && !this.passwordMismatch) {
    this.isSubmitting = true;
    
    const payload: TrialTenantPayload = {
      firstname: this.freeTrialForm.controls.firstname.value!,
      lastname: this.freeTrialForm.controls.lastname.value!,
      email: this.freeTrialForm.controls.email.value!,
      type: this.freeTrialForm.controls.type.value! as 'Agency' | 'Broker' | 'Developer' | 'Investor',
      password: this.freeTrialForm.controls.password.value!
    };
    
    this.auth.createTrialTenant(payload).subscribe({
      next: (response) => {
        this.successMessage = 'Free trial account created successfully! Redirecting...';
       window.location.href = response.url!;
      },
      error: (error: any) => {
        console.error('Free trial creation failed:', error);
        this.errorMessage = error?.error?.message || 'Failed to create free trial account. Please try again.';
        this.isSubmitting = false;
      },
      complete: () => {
        // Optionnel: faire quelque chose après la complétion
      }
    });
  } else {
    this.errorMessage = 'Please fill all required fields correctly.';
  }
}

}
