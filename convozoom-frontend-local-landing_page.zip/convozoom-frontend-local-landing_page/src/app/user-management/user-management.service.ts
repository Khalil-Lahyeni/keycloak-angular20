import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, from, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AuthService } from '../auth/auth.service';
import { AppConfigService } from '../config/app-config.service';

export interface KeycloakUser {
  id?: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  enabled: boolean;
  emailVerified: boolean;
  credentials?: Array<{
    type: string;
    value: string;
    temporary: boolean;
  }>;
  attributes?: Record<string, string[]>;
  realmRoles?: string[];
  clientRoles?: Record<string, string[]>;
}

export interface UserCreateRequest {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  temporaryPassword?: boolean;
  enabled?: boolean;
  emailVerified?: boolean;
  realmRoles?: string[];
  clientRoles?: Record<string, string[]>;
}

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  private http = inject(HttpClient);
  private authService = inject(AuthService);
  private configService = inject(AppConfigService);

  private async getKeycloakAdminUrl(): Promise<string> {
    const config = await this.configService.getConfig().toPromise();
    if (!config) {
      throw new Error('Configuration not available');
    }
    return `${config.keycloak.url}/admin/realms/${config.keycloak.realm}`;
  }

  private async getAuthHeaders(): Promise<HttpHeaders> {
    const token = await this.authService.getToken();
    if (!token) {
      throw new Error('No authentication token available');
    }

    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  /**
   * Get all users in the realm
   */
  async getUsers(): Promise<KeycloakUser[]> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();
      
      const response = await this.http.get<any[]>(`${adminUrl}/users`, { headers }).toPromise();
      return response || [];
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  }

  /**
   * Get a specific user by ID
   */
  async getUser(userId: string): Promise<KeycloakUser> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();
      
      const response = await this.http.get<any>(`${adminUrl}/users/${userId}`, { headers }).toPromise();
      return response;
    } catch (error) {
      console.error('Error fetching user:', error);
      throw error;
    }
  }

  /**
   * Create a new user
   */
  async createUser(userData: UserCreateRequest): Promise<string> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      const userPayload = {
        username: userData.username,
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        enabled: userData.enabled ?? true,
        emailVerified: userData.emailVerified ?? false,
        credentials: [{
          type: 'password',
          value: userData.password,
          temporary: userData.temporaryPassword ?? true
        }]
      };

      const response = await this.http.post(`${adminUrl}/users`, userPayload, { 
        headers,
        observe: 'response'
      }).toPromise();

      // Extract user ID from Location header
      const location = response?.headers.get('Location');
      if (location) {
        const userId = location.split('/').pop();
        return userId || '';
      }

      throw new Error('User created but ID not found in response');
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  /**
   * Update an existing user
   */
  async updateUser(userId: string, userData: Partial<KeycloakUser>): Promise<void> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      await this.http.put(`${adminUrl}/users/${userId}`, userData, { headers }).toPromise();
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  }

  /**
   * Delete a user
   */
  async deleteUser(userId: string): Promise<void> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      await this.http.delete(`${adminUrl}/users/${userId}`, { headers }).toPromise();
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  }

  /**
   * Reset user password
   */
  async resetUserPassword(userId: string, newPassword: string, temporary: boolean = true): Promise<void> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      const passwordPayload = {
        type: 'password',
        value: newPassword,
        temporary: temporary
      };

      await this.http.put(`${adminUrl}/users/${userId}/reset-password`, passwordPayload, { headers }).toPromise();
    } catch (error) {
      console.error('Error resetting password:', error);
      throw error;
    }
  }

  /**
   * Get user roles
   */
  async getUserRoles(userId: string): Promise<{ realmRoles: string[], clientRoles: Record<string, string[]> }> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      const [realmRoles, clientRoles] = await Promise.all([
        this.http.get<any[]>(`${adminUrl}/users/${userId}/role-mappings/realm`, { headers }).toPromise(),
        this.http.get<Record<string, any[]>>(`${adminUrl}/users/${userId}/role-mappings/clients`, { headers }).toPromise()
      ]);

      return {
        realmRoles: realmRoles?.map(role => role.name) || [],
        clientRoles: clientRoles || {}
      };
    } catch (error) {
      console.error('Error fetching user roles:', error);
      throw error;
    }
  }

  /**
   * Assign roles to user
   */
  async assignRolesToUser(userId: string, realmRoles: string[] = [], clientRoles: Record<string, string[]> = {}): Promise<void> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      // Assign realm roles
      if (realmRoles.length > 0) {
        const realmRolesPayload = await this.getRolesPayload(realmRoles, 'realm');
        await this.http.post(`${adminUrl}/users/${userId}/role-mappings/realm`, realmRolesPayload, { headers }).toPromise();
      }

      // Assign client roles
      for (const [clientId, roles] of Object.entries(clientRoles)) {
        if (roles.length > 0) {
          const clientRolesPayload = await this.getRolesPayload(roles, 'client', clientId);
          await this.http.post(`${adminUrl}/users/${userId}/role-mappings/clients/${clientId}`, clientRolesPayload, { headers }).toPromise();
        }
      }
    } catch (error) {
      console.error('Error assigning roles:', error);
      throw error;
    }
  }

  /**
   * Get available roles for assignment
   */
  async getAvailableRoles(): Promise<{ realmRoles: string[], clientRoles: Record<string, string[]> }> {
    try {
      const adminUrl = await this.getKeycloakAdminUrl();
      const headers = await this.getAuthHeaders();

      const [realmRoles, clients] = await Promise.all([
        this.http.get<any[]>(`${adminUrl}/roles`, { headers }).toPromise(),
        this.http.get<any[]>(`${adminUrl}/clients`, { headers }).toPromise()
      ]);

      const clientRoles: Record<string, string[]> = {};
      
      // Get roles for each client
      for (const client of clients || []) {
        try {
          const roles = await this.http.get<any[]>(`${adminUrl}/clients/${client.id}/roles`, { headers }).toPromise();
          clientRoles[client.clientId] = roles?.map(role => role.name) || [];
        } catch (error) {
          console.warn(`Could not fetch roles for client ${client.clientId}:`, error);
        }
      }

      return {
        realmRoles: realmRoles?.map(role => role.name) || [],
        clientRoles
      };
    } catch (error) {
      console.error('Error fetching available roles:', error);
      throw error;
    }
  }

  private async getRolesPayload(roleNames: string[], type: 'realm' | 'client', clientId?: string): Promise<any[]> {
    const adminUrl = await this.getKeycloakAdminUrl();
    const headers = await this.getAuthHeaders();

    if (type === 'realm') {
      const allRoles = await this.http.get<any[]>(`${adminUrl}/roles`, { headers }).toPromise();
      return allRoles?.filter(role => roleNames.includes(role.name)) || [];
    } else if (type === 'client' && clientId) {
      const allRoles = await this.http.get<any[]>(`${adminUrl}/clients/${clientId}/roles`, { headers }).toPromise();
      return allRoles?.filter(role => roleNames.includes(role.name)) || [];
    }

    return [];
  }

  /**
   * Open Keycloak Admin Console for user management
   */
  async openKeycloakAdminConsole(): Promise<void> {
    try {
      const config = await this.configService.getConfig().toPromise();
      if (!config) {
        throw new Error('Configuration not available');
      }
      
      const token = await this.authService.getToken();
      if (!token) {
        throw new Error('No authentication token available');
      }

      // Construct the admin console URL with the current token
      const adminUrl = `${config.keycloak.url}/admin/${config.keycloak.realm}/console`;
      
      // Open in a new window/tab
      window.open(adminUrl, '_blank');
    } catch (error) {
      console.error('Error opening Keycloak admin console:', error);
      throw error;
    }
  }
}
