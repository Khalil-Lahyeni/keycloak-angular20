import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { PlanDTO } from '../models/plan.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({ providedIn: 'root' })
export class PlanService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllPlans(): Observable<PlanDTO[]> {
    return this.http.get<PlanDTO[]>(`${this.base}/plans`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllPlans');
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'get');
        return throwError(() => errorInfo);
      })
    );
  }

  createPlan(plan: PlanDTO): Observable<PlanDTO> {
    return this.http.post<PlanDTO>(`${this.base}/plans`, plan).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createPlan');
        const errorInfo = this.errorHandler.getTenantErrorMessage(err, 'create');
        return throwError(() => errorInfo);
      })
    );
  }
}
