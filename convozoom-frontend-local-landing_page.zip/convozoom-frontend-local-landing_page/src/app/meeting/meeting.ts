import { Component, ViewChild, ElementRef, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Room, RoomEvent, Track, RemoteTrack, RemoteTrackPublication, TranscriptionSegment, TrackPublication, Participant, DataPacket_Kind } from 'livekit-client';
import { GuestService } from '../services/guest-service';
import { GuestStateService } from '../services/guest-state.service';
import { LoadingService } from '../services/loading.service';
import { AgendaDTO, AgendaStatus, ChatMessage, GuestDTO, LiveKitTokenRequest } from '../models/guest.model';
import { combineLatest, filter } from 'rxjs';
import { AgendaService } from '../services/agenda.service';

@Component({
  selector: 'app-meeting',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './meeting.html',
  styleUrl: './meeting.scss'
})
export class Meeting implements OnDestroy, OnInit {
  @ViewChild('videoSection') videoSection!: ElementRef;
  @ViewChild('remoteVideo') remoteVideoElement!: ElementRef<HTMLVideoElement>;
  @ViewChild('localVideo') localVideoElement!: ElementRef<HTMLVideoElement>;
  @ViewChild('messagesContainer') messagesContainer!: ElementRef<HTMLDivElement>;

  // LiveKit connection properties
  room: Room | null = null;
  isConnected: boolean = false;
  connectionStatus: string = 'Disconnected';
  
  // Configuration
  livekitUrl: string = '';
  token: string = '';
  roomName: string = '';
  identity: string = '';
  
  // Guest information
  guestInfo: GuestDTO | null = null;
  leadId: string | null = null;
  tenantId: string | null = null;
  agenda: AgendaDTO = {} as AgendaDTO;
  isLoadingGuest: boolean = false;
  guestError: string = '';

  // Track attached media elements for cleanup
  private attachedAudioElements: HTMLAudioElement[] = [];
  private attachedVideoElements: Map<string, HTMLVideoElement> = new Map();
  
  // UI state
  isVideoOn: boolean = false;
  isMicOn: boolean = true;
  isFullscreen: boolean = false;
  isChatOpen: boolean = false;
  isVideoOpen: boolean = false;
  isCameraActive: boolean = false;
  newMessage: string = '';
  messages: ChatMessage[] = [];  // Changed from any[] to ChatMessage[]
  localStream: MediaStream | null = null;

  constructor(
    private guestService: GuestService,
    private guestStateService: GuestStateService,
    private loadingService: LoadingService,
    private agendaService: AgendaService,
    private router: Router
  ) {}

  ngOnInit() {
    // Subscribe to all guest data (guestInfo, leadId, tenantId) and wait for all to be available
    combineLatest([
      this.guestStateService.guestInfo$,
      this.guestStateService.leadId$,
      this.guestStateService.tenantId$,
      this.guestStateService.agenda$
    ]).pipe(
      filter(([guest, leadId, tenantId, agenda]) => 
        guest !== null && leadId !== null && tenantId !== null && agenda !== null
      )
    ).subscribe(([guest, leadId, tenantId, agenda]) => {
      this.guestInfo = guest;
      this.leadId = leadId;
      this.tenantId = tenantId;
      this.agenda = agenda;
      this.identity = guest!.name;
      this.connectionStatus = 'Guest loaded';
      
      // Initialize LiveKit connection only once when all data is available
      if (!this.room) {
        this.initializeLiveKitConnection();
      }
    });
  }

  ngOnDestroy() {
    this.disconnectFromRoom();
    this.stopLocalCamera();
  }

  /**
   * Initializes LiveKit connection after guest info is loaded
   * Guest info is already available from GuestPage's global state
   */
  private async initializeLiveKitConnection() {
    if (!this.guestInfo) {
      this.connectionStatus = 'Error: No guest information';
      return;
    }

    // Try to reuse pre-generated token details from GuestPage
    if (typeof localStorage !== 'undefined') {
      const storedToken = localStorage.getItem('lk_token');
      const storedUrl = localStorage.getItem('lk_url');
      const storedRoom = localStorage.getItem('lk_room');
      if (storedToken && storedUrl && storedRoom) {
        this.token = storedToken;
        this.livekitUrl = storedUrl;
        this.roomName = storedRoom;
        this.connectionStatus = 'Token reused';
        await this.connectToRoom();
        return; // Skip regeneration
      }
    }

    this.isLoadingGuest = true;
    this.connectionStatus = 'Generating LiveKit token...';

    try {
      // Generate LiveKit token using guest information
      const tokenRequest: LiveKitTokenRequest = {
        lead_id: this.leadId || '',
        tenant_id: this.tenantId || '',
        lead_name: this.guestInfo.name,
        ttl: 3600
      };

      const livekitResponse = await this.guestService.generateLiveKitToken(tokenRequest).toPromise();
      
      if (!livekitResponse) {
        throw new Error('Failed to generate LiveKit token');
      }

      // Store LiveKit connection details
      this.token = livekitResponse.token;
      this.livekitUrl = livekitResponse.url;
      this.roomName = livekitResponse.room_name;

      this.connectionStatus = 'Ready to connect';
      this.isLoadingGuest = false;

      this.agenda.state = AgendaStatus.InProgress;
      this.agenda.roomId = livekitResponse.room_name;
      await this.agendaService.updateAgenda(this.agenda!.id!, this.agenda).toPromise();

      // Automatically connect to the room
      await this.connectToRoom();

    } catch (error) {
      this.isLoadingGuest = false;
      this.guestError = error instanceof Error ? error.message : 'Failed to initialize LiveKit session';
      this.connectionStatus = 'Error: ' + this.guestError;
    }
  }
  /**
   * Establishes connection to LiveKit room and enables microphone
   * Sets up all event listeners for handling remote tracks
   */
  async connectToRoom() {
    if (!this.token || !this.livekitUrl) {
      this.connectionStatus = 'Error: Missing token or URL';
      return;
    }

    try {
      this.connectionStatus = 'Connecting...';
      this.room = new Room({
        adaptiveStream: true,
        dynacast: true,
      });

      this.setupRoomEventListeners();

      await this.room.connect(this.livekitUrl, this.token);
      
      this.isConnected = true;
      this.connectionStatus = 'Connected';

      // Enable microphone by default when connecting
      await this.room.localParticipant.setMicrophoneEnabled(true);
      this.isMicOn = true;

    } catch (error) {
      this.connectionStatus = 'Connection Failed';
      alert('Failed to connect: ' + (error as Error).message);
    }
  }

  /**
   * Registers event handlers for LiveKit room events
   * Handles incoming video/audio tracks and participant state changes
   */
  setupRoomEventListeners() {
    if (!this.room) return;

    this.room.on(RoomEvent.TrackSubscribed, (
      track: RemoteTrack,
      publication: RemoteTrackPublication
    ) => {
      if (track.kind === Track.Kind.Video) {
        this.handleVideoTrack(track);
      } else if (track.kind === Track.Kind.Audio) {
        this.handleAudioTrack(track);
      }
    });

    this.room.on(RoomEvent.TrackUnsubscribed, (
      track: RemoteTrack,
      publication: RemoteTrackPublication
    ) => {
      if (track.kind === Track.Kind.Video) {
        this.detachVideoTrack();
      }
    });

 // Listen for transcription events
    this.room.on(RoomEvent.TranscriptionReceived, (
      segments: TranscriptionSegment[],
      participant?: Participant,
      publication?: TrackPublication
    ) => {
      this.handleTranscription(segments, participant);
    });

    // Listen for incoming chat messages via Data Channel
    this.room.on(RoomEvent.DataReceived, (
      payload: Uint8Array,
      participant?: Participant,
      kind?: DataPacket_Kind
    ) => {
      this.handleIncomingMessage(payload, participant);
    });

    this.room.on(RoomEvent.ConnectionStateChanged, (state) => {
      this.connectionStatus = state;
    });

    this.room.on(RoomEvent.Disconnected, () => {
      this.isConnected = false;
      this.connectionStatus = 'Disconnected';
    });
  }

  /**
   * Handles incoming transcription segments from LiveKit
   * Converts transcriptions to chat messages from the AI Agent
   * @param segments - Array of transcription segments
   * @param participant - The participant who spoke
   */
  handleTranscription(segments: TranscriptionSegment[], participant?: Participant) {
    if (!segments || segments.length === 0) return;

    segments.forEach(segment => {
      // Only process final transcriptions (ignore interim/partial ones)
      if (segment.final && segment.text.trim()) {
        const participantIdentity = participant?.identity || 'unknown';
        const participantName = participant?.name || participant?.identity || 'AI Agent';
        const isLocalParticipant = this.room?.localParticipant.identity === participantIdentity;

        // Add transcription as a chat message from the AI Agent
        const chatMessage: ChatMessage = {
          id: `transcription-${Date.now()}-${Math.random()}`,
          text: segment.text.trim(),
          senderIdentity: participantIdentity,
          senderName: isLocalParticipant ? 'You' : participantName,
          timestamp: new Date(),
          isLocal: isLocalParticipant
        };

        this.messages.push(chatMessage);

        // Keep only last 100 messages to prevent memory issues
        if (this.messages.length > 100) {
          this.messages = this.messages.slice(-100);
        }

        // Auto-open chat if closed and new message arrives
        if (!this.isChatOpen && !isLocalParticipant) {
          this.isChatOpen = true;
        }

        // Trigger change detection to update UI immediately

        this.scrollToBottom();
      }
    });
  }

  /**
   * Handles incoming chat messages from LiveKit Data Channel
   * @param payload - The raw data payload (Uint8Array)
   * @param participant - The participant who sent the message
   */
  handleIncomingMessage(payload: Uint8Array, participant?: Participant) {
    try {
      // Decode the message from Uint8Array to string
      const decoder = new TextDecoder();
      const messageText = decoder.decode(payload);
      
      // Parse the JSON message
      const messageData = JSON.parse(messageText);
      
      const chatMessage: ChatMessage = {
        id: `${Date.now()}-${Math.random()}`,
        text: messageData.text || messageText,  // Support both structured and plain text
        senderIdentity: participant?.identity || 'Unknown',
        senderName: participant?.name || participant?.identity || 'Unknown',
        timestamp: new Date(messageData.timestamp || Date.now()),
        isLocal: false  // Received from remote participant
      };

      this.messages.push(chatMessage);

      // Keep only last 100 messages to prevent memory issues
      if (this.messages.length > 100) {
        this.messages = this.messages.slice(-100);
      }

      // Trigger change detection to update UI immediately

      this.scrollToBottom();
    } catch (error) {
      console.error('Failed to parse incoming message:', error);
    }
  }
  
  /**
   * Attaches a remote video track to the video element for display
   * @param track - The remote video track to display
   */
  handleVideoTrack(track: RemoteTrack) {
    setTimeout(() => {
      if (this.remoteVideoElement?.nativeElement) {
        const videoElement = this.remoteVideoElement.nativeElement;
        
        track.attach(videoElement);
        
        if (track.sid) {
          this.attachedVideoElements.set(track.sid, videoElement);
        }
        
        videoElement.play().catch(() => {});
      }
    }, 100);
  }

  /**
   * Scrolls the chat messages container to the bottom
   * Called after new messages are added to ensure latest message is visible
   */
  private scrollToBottom(): void {
    setTimeout(() => {
      if (this.messagesContainer?.nativeElement) {
        const container = this.messagesContainer.nativeElement;
        container.scrollTop = container.scrollHeight;
      }
    }, 100);
  }
  
  /**
   * Creates an audio element and attaches a remote audio track for playback
   * @param track - The remote audio track to play
   */
  handleAudioTrack(track: RemoteTrack) {
    const audioElement = new Audio();
    track.attach(audioElement);
    
    this.attachedAudioElements.push(audioElement);
    
    audioElement.play().catch(() => {});
    
    track.on('ended', () => {
      audioElement.pause();
      audioElement.srcObject = null;
      const index = this.attachedAudioElements.indexOf(audioElement);
      if (index > -1) {
        this.attachedAudioElements.splice(index, 1);
      }
    });
  }

  /**
   * Removes the video track from the video element
   */
  detachVideoTrack() {
    if (this.remoteVideoElement?.nativeElement) {
      this.remoteVideoElement.nativeElement.srcObject = null;
    }
  }

  /**
   * Disconnects from the LiveKit room and cleans up all media elements
   * Properly releases all audio/video resources to prevent memory leaks
   * Shows loading spinner and redirects to landing page after 1 second
   */
  async disconnectFromRoom() {
    // Show loading spinner
    this.loadingService.show();
    
    if (this.room) {
      this.room.disconnect();
      this.room = null;
      this.isConnected = false;
      this.connectionStatus = 'Disconnected';
    }
    
    // Clean up all audio elements
    this.attachedAudioElements.forEach(audio => {
      audio.pause();
      audio.srcObject = null;
    });
    this.attachedAudioElements = [];
    
    // Clean up video elements
    this.attachedVideoElements.forEach(video => {
      video.pause();
      video.srcObject = null;
    });
    this.attachedVideoElements.clear();
    
    // Stop local camera if active
    this.stopLocalCamera();
    
    // Wait 1 second with spinner, then hide spinner and redirect to landing page
    setTimeout(() => {
      this.loadingService.hide();
      this.router.navigate(['/']);
    }, 100);
  }

  /**
   * Toggles the local camera on/off
   * Note: Currently not used in the UI
   */
  async toggleVideo() {
    this.isVideoOn = !this.isVideoOn;
    
    if (this.room) {
      try {
        await this.room.localParticipant.setCameraEnabled(this.isVideoOn);
      } catch (error) {
        // Silent fail
      }
    }
  }

  /**
   * Toggles the local microphone on/off
   * This allows users to mute/unmute during the call
   */
  async toggleMic() {
    this.isMicOn = !this.isMicOn;
    
    if (this.room) {
      try {
        await this.room.localParticipant.setMicrophoneEnabled(this.isMicOn);
      } catch (error) {
        // Silent fail
      }
    }
  }

  /**
   * Toggles fullscreen mode for the video section
   */
  toggleFullscreen() {
    const videoElement = this.videoSection.nativeElement;
    
    if (!document.fullscreenElement) {
      if (videoElement.requestFullscreen) {
        videoElement.requestFullscreen();
      }
      this.isFullscreen = true;
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      this.isFullscreen = false;
    }
  }

  /**
   * Toggles the chat panel visibility
   */
  toggleChat() {
    this.isChatOpen = !this.isChatOpen;
  }

  /**
   * Toggles the video panel visibility
   */
  async toggleVideoPanel() {
    this.isVideoOpen = !this.isVideoOpen;
    if (this.isVideoOpen) {
      // Start local camera when opening video panel
      await this.startLocalCamera();
    } else {
      // Stop local camera when closing video panel
      this.stopLocalCamera();
    }
  }

  /**
   * Starts the local camera and displays it in the video panel
   */
  async startLocalCamera() {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false
      });
      
      this.isCameraActive = true;
      
      // Wait for the view to update
      setTimeout(() => {
        if (this.localVideoElement?.nativeElement && this.localStream) {
          this.localVideoElement.nativeElement.srcObject = this.localStream;
        }
      }, 100);
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Failed to access camera. Please check your camera permissions.');
      this.isCameraActive = false;
    }
  }

  /**
   * Stops the local camera stream and releases the camera
   */
  stopLocalCamera() {
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
      this.localStream = null;
    }
    
    if (this.localVideoElement?.nativeElement) {
      this.localVideoElement.nativeElement.srcObject = null;
    }
    
    this.isCameraActive = false;
  }

  /**
   * Toggles the camera on/off
   */
  async toggleCamera() {
    this.isCameraActive = !this.isCameraActive;
    
    if (this.isCameraActive) {
      // Start camera if not already started
      if (!this.localStream) {
        await this.startLocalCamera();
      }
    } else {
      // Stop camera
      this.stopLocalCamera();
    }
  }

  /**
   * Sends a chat message via LiveKit Data Channel
   * Publishes the message to all participants in the room
   */
  async sendMessage() {
    if (!this.newMessage.trim() || !this.room) {
      return;
    }

    try {
      const messageText = this.newMessage.trim();
      const now = new Date();



      // Publish message to all participants via Data Channel
      await this.room.localParticipant.sendText(messageText);


      // Add the sent message to local chat history
      const chatMessage: ChatMessage = {
        id: `${Date.now()}-${Math.random()}`,
        text: messageText,
        senderIdentity: this.identity,
        senderName: this.guestInfo?.name || this.identity,
        timestamp: now,
        isLocal: true  // Sent by current user
      };

      this.messages.push(chatMessage);

      // Clear the input field
      this.newMessage = '';
      this.scrollToBottom();
    } catch (error) {
      console.error('Failed to send message:', error);
      alert('Failed to send message. Please try again.');
    }
  }
}
