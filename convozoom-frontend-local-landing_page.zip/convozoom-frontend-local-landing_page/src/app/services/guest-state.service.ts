import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { AgendaDTO, GuestDTO } from '../models/guest.model';

/**
 * Service for managing global guest state across the application
 * Holds guest information loaded from access token + leadId and tenantId from URL
 */
@Injectable({ providedIn: 'root' })
export class GuestStateService {
  // BehaviorSubject to hold guest information
  private readonly guestInfoSubject = new BehaviorSubject<GuestDTO | null>(null);
  
  // BehaviorSubjects for leadId and tenantId (extracted from URL)
  private readonly leadIdSubject = new BehaviorSubject<string | null>(null);
  private readonly tenantIdSubject = new BehaviorSubject<string | null>(null);
  private readonly agendaSubject = new BehaviorSubject<AgendaDTO>({} as AgendaDTO);

  // Public observable that components can subscribe to
  readonly guestInfo$: Observable<GuestDTO | null> = this.guestInfoSubject.asObservable();
  readonly leadId$: Observable<string | null> = this.leadIdSubject.asObservable();
  readonly tenantId$: Observable<string | null> = this.tenantIdSubject.asObservable();
  readonly agenda$: Observable<AgendaDTO> = this.agendaSubject.asObservable();

  /**
   * Get current guest info value (snapshot)
   */
  get currentGuestInfo(): GuestDTO | null {
    return this.guestInfoSubject.value;
  }

  /**
   * Get current leadId value (snapshot)
   */
  get currentLeadId(): string | null {
    return this.leadIdSubject.value;
  }

  /**
   * Get current tenantId value (snapshot)
   */
  get currentTenantId(): string | null {
    return this.tenantIdSubject.value;
  }

  /**
   * Set guest information (called after fetching from backend)
   * @param guest - GuestDTO object
   */
  setGuestInfo(guest: GuestDTO | null): void {
    this.guestInfoSubject.next(guest);
  }

  /**
   * Set leadId (extracted from URL query params)
   * @param leadId - Lead identifier
   */
  setLeadId(leadId: string | null): void {
    this.leadIdSubject.next(leadId);
  }

  /**
   * Set tenantId (extracted from URL query params)
   * @param tenantId - Tenant identifier
   */
  setTenantId(tenantId: string | null): void {
    this.tenantIdSubject.next(tenantId);
  }

  /**
   * Set tenantId (extracted from URL query params)
   * @param tenantId - Tenant identifier
   */
  setAgenda(agenda: AgendaDTO): void {
    this.agendaSubject.next(agenda);
  }

  /**
   * Update guest information partially
   * @param updates - Partial guest data to update
   */
  updateGuestInfo(updates: Partial<GuestDTO>): void {
    const current = this.guestInfoSubject.value;
    if (current) {
      this.guestInfoSubject.next({ ...current, ...updates });
    }
  }

  /**
   * Clear guest information (logout/reset)
   */
  clearGuestInfo(): void {
    this.guestInfoSubject.next(null);
  }
}
