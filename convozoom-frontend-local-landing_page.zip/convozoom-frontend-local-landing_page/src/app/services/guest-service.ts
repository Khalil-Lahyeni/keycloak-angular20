import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { GuestDTO, LiveKitTokenRequest, LiveKitTokenResponse } from '../models/guest.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

/**
 * Service for handling guest authentication and LiveKit token generation
 */
@Injectable({ providedIn: 'root' })
export class GuestService {
  private appConfigService = inject(AppConfigService);
  private apiBaseUrl: string = '';
  private aiBaseUrl: string = '';

  constructor(
    private http: HttpClient,
    private errorHandler: ErrorHandlerService
  ) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.apiBaseUrl = url || '';
    });

    this.appConfigService.getApiAiBaseUrl().subscribe((url: string | undefined) => {
      this.aiBaseUrl = url || '';
    });
  }

  /**
   * Fetches guest information by access token
   * @param token - The access token from the URL query parameter
   * @returns Observable<GuestDTO>
   */
  getGuestByToken(token: string): Observable<GuestDTO> {
    return this.http
      .get<GuestDTO>(`${this.apiBaseUrl}/guests/token/${token}`)
      .pipe(
        catchError((err: HttpErrorResponse) => {
          this.errorHandler.logError(err, `getGuestByToken ${token}`);
          return throwError(
            () => new Error('Failed to fetch guest information. Please check your access token.')
          );
        })
      );
  }

  /**
   * Generates a LiveKit access token for the guest
   * @param request - The token request payload with lead_id, tenant_id, lead_name
   * @returns Observable<LiveKitTokenResponse>
   */
  generateLiveKitToken(request: LiveKitTokenRequest): Observable<LiveKitTokenResponse> {
    return this.http
      .post<LiveKitTokenResponse>(
        `${this.aiBaseUrl}/auth/token`,
        request
      )
      .pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'generateLiveKitToken');
        return throwError(() => new Error('Failed to generate LiveKit token. Please try again.'));
        })
      );
  }
}
