export enum LeadImportJobStatus {
    PENDING = 'Pending',
    COMPLETED = 'Completed',
    FAILED = 'Failed'
}

export interface LeadImportJob {
    id?: string;
    tenantId: string;
    source?: string;
    status?: LeadImportJobStatus;
    startedAt?: string;
    completedAt?: string;
    errorLog?: string;
    importedCount?:number;
}