package com.railway.collector.service;

import com.railway.collector.service.publisher.MqttPublisherService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Fleet Manager — Agrège l'état de tous les trains.
 * Publie périodiquement une vue d'ensemble de la flotte.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FleetManagerService {

    private final MqttPublisherService mqttPublisher;

    private final Map<String, Map<String, Object>> trainStates = new ConcurrentHashMap<>();

    /**
     * Met à jour l'état d'un train dans la vue flotte.
     */
    public void updateTrain(String trainId, Map<String, Object> data) {
        Map<String, Object> state = new LinkedHashMap<>();
        state.put("trainId", trainId);
        state.put("healthScore", data.getOrDefault("_healthScore", -1));
        state.put("hasAlerts", data.getOrDefault("_hasAlerts", false));
        state.put("maxSeverity", data.getOrDefault("_maxSeverity", "NONE"));
        state.put("mission", data.getOrDefault("mission", "unknown"));
        state.put("currentStation", data.getOrDefault("currentStation", "unknown"));
        state.put("nextStation", data.getOrDefault("nextStation", "unknown"));
        state.put("destination", data.getOrDefault("destination", "unknown"));
        state.put("pacisStatus", data.getOrDefault("pacisStatus", "unknown"));
        state.put("cctvStatus", data.getOrDefault("cctvStatus", "unknown"));
        state.put("rearViewStatus", data.getOrDefault("rearViewStatus", "unknown"));
        state.put("lastUpdate", Instant.now().toString());

        trainStates.put(trainId, state);
    }

    /**
     * Publication périodique de la vue flotte (toutes les 10 secondes).
     */
    @Scheduled(fixedDelayString = "${rules.fleet-overview-interval-seconds:10}000")
    public void publishFleetOverview() {
        List<Map<String, Object>> trains = new ArrayList<>(trainStates.values());

        if (trains.isEmpty()) {
            return;
        }

        double avgHealth = trains.stream()
                .map(t -> (Number) t.getOrDefault("healthScore", 0))
                .mapToInt(Number::intValue)
                .filter(s -> s >= 0)
                .average()
                .orElse(0.0);

        long trainsWithAlerts = trains.stream()
                .filter(t -> Boolean.TRUE.equals(t.get("hasAlerts")))
                .count();

        Map<String, Integer> severityCounts = new LinkedHashMap<>();
        severityCounts.put("INFO", 0);
        severityCounts.put("WARNING", 0);
        severityCounts.put("CRITICAL", 0);
        severityCounts.put("EMERGENCY", 0);

        for (Map<String, Object> t : trains) {
            String sev = (String) t.getOrDefault("maxSeverity", "NONE");
            severityCounts.computeIfPresent(sev, (k, v) -> v + 1);
        }

        Map<String, Object> overview = new LinkedHashMap<>();
        overview.put("totalTrains", trains.size());
        overview.put("averageHealthScore", Math.round(avgHealth * 10.0) / 10.0);
        overview.put("trainsWithAlerts", trainsWithAlerts);
        overview.put("trainsHealthy", trains.size() - trainsWithAlerts);
        overview.put("severitySummary", severityCounts);
        overview.put("trains", trains);
        overview.put("timestamp", Instant.now().toString());

        mqttPublisher.publishFleetOverview(overview);

        log.debug("Fleet overview: {} trains, avg health: {}",
                trains.size(), overview.get("averageHealthScore"));
    }
}
