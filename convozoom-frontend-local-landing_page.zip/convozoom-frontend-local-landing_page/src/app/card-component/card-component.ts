import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Lead } from '../models/lead.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-card-component',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './card-component.html',
  styleUrl: './card-component.css'
})
export class CardComponent {
  @Input() lead!: Lead;
  @Input() color!: string;
  @Output() clicked = new EventEmitter<Lead>();
  showDetails: boolean = false; 

  onCardClick() {
    this.clicked.emit(this.lead); 
  }

  getBadgeClass(priority: string | undefined): string {
    switch (priority) {
      case 'Urgent': return 'badge-urgent';
      case 'Moderate': return 'badge-moderate';
      case 'Low': return 'badge-low';
      default: return 'badge-default';
    }
  }

  getPriorityIcon(priority?: string): string {
  switch (priority) {
    case 'Urgent':
      return 'assets/lead/Flag.svg';   
    case 'Moderate':
      return 'assets/lead/Flag-orange.svg'; 
    case 'Low':
      return 'assets/lead/Flag-green.svg';      
    default:
      return 'assets/lead/Flag.svg';
  }
}

  toggleDetails(event: Event) {
    event.stopPropagation();
    this.showDetails = !this.showDetails;
  }
}