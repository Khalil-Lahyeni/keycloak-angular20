import { Component, OnInit, AfterViewInit, Output, EventEmitter, Input, inject, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AgendaService } from '../../../services/agenda.service';
import { AgendaDTO, AgendaStatus } from '../../../models/guest.model';

interface MeetingItem {
  id: string;
  clientName: string;
  timeRange: string;
  startHour: number;
  duration: number;
  agentName: string;
  hasAiAgent: boolean;
  status: AgendaStatus;
  roomId?: string;
  agenda: AgendaDTO;
}

interface TimeSlot {
  hour: number;
  label: string;
  meetings: MeetingItem[];
}

@Component({
  selector: 'app-meeting-widget',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './meeting-widget.html',
  styleUrl: './meeting-widget.css'
})
export class MeetingWidgetComponent implements OnInit, AfterViewInit {
  private agendaService = inject(AgendaService);
  private router = inject(Router);
  
  @ViewChild('scheduleContainer') scheduleContainer!: ElementRef<HTMLDivElement>;
  
  @Input() editMode: boolean = false;
  @Output() remove = new EventEmitter<void>();
  @Output() meetingClick = new EventEmitter<AgendaDTO>();
  
  timeSlots: TimeSlot[] = [];
  meetings: MeetingItem[] = [];
  isLoading: boolean = true;
  selectedMeeting: MeetingItem | null = null;

  ngOnInit(): void {
    this.initializeTimeSlots();
    this.loadMeetings();
  }

  ngAfterViewInit(): void {
    setTimeout(() => this.scrollToCurrentTime(), 100);
  }

  private initializeTimeSlots(): void {
    for (let i = 0; i < 24; i++) {
      this.timeSlots.push({
        hour: i,
        label: `${i.toString().padStart(2, '0')}:00`,
        meetings: []
      });
    }
  }

  private loadMeetings(): void {
    this.isLoading = true;
    this.agendaService.getAllAgenda().subscribe({
      next: (agendas) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const todayMeetings = agendas.filter(agenda => {
          const meetingDate = new Date(agenda.date);
          meetingDate.setHours(0, 0, 0, 0);
          return meetingDate.getTime() === today.getTime();
        });
        
        if (todayMeetings.length > 0) {
          this.meetings = todayMeetings.map(agenda => this.mapAgendaToMeeting(agenda));
        } else {
          this.meetings = this.getMockMeetings();
        }
        this.assignMeetingsToSlots();
        this.isLoading = false;
        setTimeout(() => this.scrollToCurrentTime(), 100);
      },
      error: (err) => {
        console.error('Error loading meetings:', err);
        this.meetings = this.getMockMeetings();
        this.assignMeetingsToSlots();
        this.isLoading = false;
        setTimeout(() => this.scrollToCurrentTime(), 100);
      }
    });
  }

  private getMockMeetings(): MeetingItem[] {
    const today = new Date();
    
    return [
      {
        id: 'mock-1',
        clientName: 'Client name',
        timeRange: '10:00-10:30',
        startHour: 10,
        duration: 30,
        agentName: 'Agent name',
        hasAiAgent: false,
        status: AgendaStatus.Planified,
        roomId: 'room-1',
        agenda: { date: today.toISOString(), guest: { name: 'Client name', accessToken: '', email: '' } }
      },
      {
        id: 'mock-2',
        clientName: 'Client Name',
        timeRange: '11:00-12:00',
        startHour: 11,
        duration: 60,
        agentName: 'Agent name',
        hasAiAgent: false,
        status: AgendaStatus.Planified,
        roomId: 'room-2',
        agenda: { date: today.toISOString(), guest: { name: 'Client Name', accessToken: '', email: '' } }
      },
      {
        id: 'mock-3',
        clientName: 'Client Name',
        timeRange: '13:00-13:30',
        startHour: 13,
        duration: 30,
        agentName: 'Agent name',
        hasAiAgent: true,
        status: AgendaStatus.InProgress,
        roomId: 'room-3',
        agenda: { date: today.toISOString(), guest: { name: 'Client Name', accessToken: '', email: '' } }
      },
      {
        id: 'mock-4',
        clientName: 'Client Name',
        timeRange: '16:00-20:00',
        startHour: 16,
        duration: 240,
        agentName: 'Agent name',
        hasAiAgent: false,
        status: AgendaStatus.Planified,
        roomId: 'room-4',
        agenda: { date: today.toISOString(), guest: { name: 'Client Name', accessToken: '', email: '' } }
      }
    ];
  }

  private mapAgendaToMeeting(agenda: AgendaDTO): MeetingItem {
    const startDate = new Date(agenda.date);
    const startHour = startDate.getHours();
    const startMinutes = startDate.getMinutes();
    const duration = 30;
    const endDate = new Date(startDate.getTime() + duration * 60000);
    
    const formatTime = (h: number, m: number) => 
      `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;

    return {
      id: agenda.id || '',
      clientName: agenda.guest?.name || agenda.projectName || 'Client Name',
      timeRange: `${formatTime(startHour, startMinutes)}-${formatTime(endDate.getHours(), endDate.getMinutes())}`,
      startHour: startHour + (startMinutes / 60),
      duration,
      agentName: agenda.tenantName || 'Agent name',
      hasAiAgent: true,
      status: agenda.state || AgendaStatus.Planified,
      roomId: agenda.roomId,
      agenda
    };
  }

  private assignMeetingsToSlots(): void {
    this.timeSlots.forEach(slot => slot.meetings = []);
    this.meetings.forEach(meeting => {
      const slotIndex = Math.floor(meeting.startHour);
      if (slotIndex >= 0 && slotIndex < 24) {
        this.timeSlots[slotIndex].meetings.push(meeting);
      }
    });
  }

  private scrollToCurrentTime(): void {
    if (!this.scheduleContainer?.nativeElement) return;
    const now = new Date();
    const currentHour = now.getHours();
    const scrollPosition = Math.max(0, (currentHour - 2) * 32);
    this.scheduleContainer.nativeElement.scrollTo({ top: scrollPosition, behavior: 'smooth' });
  }

  getMeetingHeight(meeting: MeetingItem): number {
    return Math.max(28, (meeting.duration / 60) * 32);
  }

  getMeetingTop(meeting: MeetingItem): number {
    const minutesOffset = (meeting.startHour % 1) * 60;
    return (minutesOffset / 60) * 32;
  }

  getMeetingClass(meeting: MeetingItem): string {
    switch (meeting.status) {
      case AgendaStatus.InProgress:
        return 'meeting-block meeting-in-progress';
      case AgendaStatus.Closed:
        return 'meeting-block meeting-closed';
      default:
        return 'meeting-block meeting-scheduled';
    }
  }

  getCurrentTimePosition(): number {
    const now = new Date();
    return (now.getHours() * 32) + (now.getMinutes() / 60 * 32);
  }

  toggleMeetingDetails(meeting: MeetingItem, event: Event): void {
    event.stopPropagation();
    this.selectedMeeting = this.selectedMeeting?.id === meeting.id ? null : meeting;
  }

  isSlotExpanded(slot: TimeSlot): boolean {
    return slot.meetings.some(m => m.id === this.selectedMeeting?.id);
  }

  closeMeetingDetails(): void {
    this.selectedMeeting = null;
  }

  onJoinMeeting(meeting: MeetingItem, event: Event): void {
    event.stopPropagation();
    this.meetingClick.emit(meeting.agenda);
    
    if (meeting.roomId) {
      this.router.navigate(['/meeting'], {
        queryParams: { roomId: meeting.roomId, leadId: meeting.agenda.leadId, tenantId: meeting.agenda.tenantId }
      });
    } else if (meeting.agenda.id) {
      this.router.navigate(['/meeting'], { queryParams: { agendaId: meeting.agenda.id } });
    }
  }

  onRemove(): void {
    this.remove.emit();
  }
}
