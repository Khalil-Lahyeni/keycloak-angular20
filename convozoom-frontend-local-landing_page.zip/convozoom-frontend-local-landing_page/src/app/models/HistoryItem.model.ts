export interface HistoryItem {
  type: 'created' | 'modified';
  performedBy: string;
  date: string;
  icon: string;
}