import { Component, Input, ViewChild, ElementRef, HostListener } from '@angular/core';
import { Column } from '../models/column.model';
import { CdkDragDrop, DragDropModule, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Deal, DealStage } from '../models/deal.model';
import { DealService } from '../services/deal-service';
import { ActivityService } from '../services/activity-service';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { interval, Subscription } from 'rxjs';
import { ToolbarComponent } from '../toolbar-component/toolbar-component';
import { Lead } from '../models/lead.model';
import { DealList } from '../deal-list/deal-list';
import { CardDealComponent } from '../card-deal-component/card-deal-component';

type SortByType = 'Budget' | 'Status' | 'Assignee' | 'Updated' | 'Created';
// En haut de DealBoard, modifiez le type
export type DealGroupBy = 'stage' | 'priority' | 'source' | null;

// Modifiez aussi le type pour sortBy dans DealList
type DealListSortBy = 'Updated' | 'Created' | 'Name' | 'Stage';
@Component({
  selector: 'app-deal-board',
  imports: [CommonModule, FormsModule, DragDropModule, ToolbarComponent, DealList, CardDealComponent],
  templateUrl: './deal-board.html',
  styleUrls: ['./deal-board.css']
})
export class DealBoard {
  @Input() deal?: Deal;
  DealStage = DealStage;

  mockDeal: Deal[] = [
    {
      id: 'deal-001',
      tenantId: '001',
      title: 'Nikita Sokolov',
      amount: 1.5,
      currency: 'USD',
      stage: DealStage.PROSPECTING,
      probability: 70,
      expectedCloseDate: new Date('2024-12-15').toISOString(),
      assignedTo: 'Layla Al-Mansoori',
      createdAt: new Date('2025-12-15').toISOString(),
      customFields: 'Type A',
      createdDate: new Date('2025-12-01').toISOString(),
      lastModifiedDate: new Date('2025-12-10').toISOString(),
      lead: {
        id: 'lead-001',
        fullName: 'Nikita Sokolov',
        company: 'Acme Corporation',
        email: 'john.miller@mail.com',
        phone: '+33 6 12 34 56 78',
        source: 'Website',
        location: 'Sydney, Australia',
        tags: 'VIP, Priority',
        priority: 'Moderate'
      } as Lead,
      createdBy: 'admin',
      lastModifiedBy: 'admin'
    },

    {
      id: 'deal-002',
      tenantId: '002',
      title: 'Amina Al-Farsi',
      amount: 1.3,
      currency: 'USD',
      stage: DealStage.NEGOTIATION,
      probability: 85,
      expectedCloseDate: new Date('2024-11-30').toISOString(),
      assignedTo: 'Fatima Al-Hassan',
      createdAt: new Date('2024-11-30').toISOString(),
      customFields: 'Type B',
      createdDate: new Date('2025-11-25').toISOString(),
      lastModifiedDate: new Date('2025-12-05').toISOString(),
      lead: {
        id: 'lead-002',
        fullName: 'Amina Al-Farsi',
        company: 'Globex France',
        email: 'claire.dupont@mail.com',
        phone: '+33 6 98 76 54 32',
        source: 'Website',
        location: 'Tokyo, Japan',
        tags: 'Important',
        priority: 'Urgent'
      } as Lead,
      createdBy: 'admin',
      lastModifiedBy: 'admin'
    },

    {
      id: 'deal-003',
      tenantId: '003',
      title: 'Svetlana Ivanova',
      amount: 1.4,
      currency: 'USD',
      stage: DealStage.CLOSED_WON,
      probability: 100,
      expectedCloseDate: new Date('2024-10-30').toISOString(),
      actualCloseDate: new Date('2024-10-15').toISOString(),
      assignedTo: 'Zara Al-Nasr',
      createdAt: new Date('2024-12-25').toISOString(),
      customFields: 'Type C',
      createdDate: new Date('2025-11-20').toISOString(),
      lastModifiedDate: new Date('2025-12-01').toISOString(),
      lead: {
        id: 'lead-003',
        fullName: 'Svetlana Ivanova',
        company: 'Innova Ltd',
        location: 'Paris, France',
        priority: 'Low',
        source: 'From file'
      } as Lead,
      createdBy: 'admin',
      lastModifiedBy: 'admin'
    },

    {
      id: 'deal-004',
      tenantId: '004',
      title: 'James Smith',
      amount: 0.9,
      currency: 'EUR',
      stage: DealStage.PROSPECTING,
      probability: 40,
      expectedCloseDate: new Date('2025-01-20').toISOString(),
      assignedTo: 'Omar Al-Farsi',
      createdAt: new Date().toISOString(),
      customFields: 'Type A',
      createdDate: new Date('2025-12-03').toISOString(),
      lastModifiedDate: new Date('2025-12-15').toISOString(),
      lead: {
        id: 'lead-004',
        fullName: 'James Smith',
        company: 'TechnoSoft',
        source: 'From file',
        location: 'Toronto, Canada',
        priority: 'Moderate'
      } as Lead,
      createdBy: 'admin',
      lastModifiedBy: 'admin'
    },

    {
      id: 'deal-005',
      tenantId: '005',
      title: 'Dmitry Petrov sun',
      amount: 2.2,
      currency: 'USD',
      stage: DealStage.NEGOTIATION,
      probability: 60,
      expectedCloseDate: new Date('2025-02-10').toISOString(),
      assignedTo: 'Viktor Kovalenko',
      createdAt: new Date().toISOString(),
      customFields: 'Type B',
      createdDate: new Date('2025-12-02').toISOString(),
      lastModifiedDate: new Date('2025-12-14').toISOString(),
      lead: {
        id: 'lead-005',
        fullName: 'Sophie Bernard',
        company: 'BlueWave Solutions',
        source: 'CRM',
        location: 'Marseille, France',
        priority: 'Urgent'
      } as Lead,
      createdBy: 'admin',
      lastModifiedBy: 'admin'
    }
  ];

  currentGroup: DealGroupBy = null;
  columns: Column<Deal>[] = [];
  dealsAll: Deal[] = [];
  showQuickDeal = false;
  targetColumn: Column<Deal> | null = null;
  showModal = false;
  quickDeal: Deal = {} as Deal;
  showAddStageCard: boolean = false;
  newStageName: string = '';

  bgColorsVars = [
    'var(--color-blue-10, #E0F0FF)',
    '#F8AE5429',
    'var(--color-purple-10, #ECE6FF)',
    '#AFDC8F29'
  ];

  textColorsVars = [
    'var(--color-blue-60, #004D99)',
    'var(--color-orange-60, #9E4A06)',
    'var(--color-purple-60, #3D2785)',
    'var(--color-green-60, #3D7317)'
  ];

  countColorsVars = [
    'var(--color-blue-40, #4394E5)',
    'var(--color-orange-40, #F5921B)',
    'var(--color-purple-40, #876FD4)',
    'var(--color-green-40, #87BB62)',
  ];


  lastColorIndex = -1;
  addingStage: boolean = false;
  nextColor: string = '';
  selectedDeal: Deal = {} as Deal;
  isFormOnly = false;
  private refreshSubscription!: Subscription;
  newDealIds: Set<string> = new Set();

  // UI state
  viewMode: 'grid' | 'list' = 'grid';
  searchQuery = '';

  // Sorting
  sortBy: SortByType = 'Updated';
  grouped: { key: string, items: Deal[] }[] = [];
  expandedGroups: Set<string> = new Set();

  // Toolbar UI state
  isSortOpen = false;
  isGroupOpen = false;
  isSearchOpen = false;
  @ViewChild('searchInput') searchInput?: ElementRef<HTMLInputElement>;
  selectedField: string | null = null;
  sortDirection: 'asc' | 'desc' = 'asc';
  isFilterOpen = false;
  selectedFilterField: string | null = null;
  filterValue: string = '';
  filterValues: { [key: string]: string } = {};
  activeFilters: { field: string, value: string, operator: string }[] = [];
  filterOperators = [
    { label: 'equals', value: 'equals' },
    { label: 'contains', value: 'contains' },
    { label: 'starts with', value: 'startsWith' },
    { label: 'ends with', value: 'endsWith' },
    { label: 'greater than', value: 'greaterThan' },
    { label: 'less than', value: 'lessThan' }
  ];
  selectedOperator: string = 'contains';

  // Map de tri
  private sortFieldMap: Record<string, SortByType> = {
    'amount': 'Budget',
    'budget': 'Budget',
    'stage': 'Status',
    'status': 'Status',
    'assignedTo': 'Assignee',
    'assigned': 'Assignee',
    'updatedAt': 'Updated',
    'lastModifiedDate': 'Updated',
    'updated': 'Updated',
    'createdAt': 'Created',
    'createdDate': 'Created',
    'created': 'Created'
  };

  stageOrder: DealStage[] = [
    DealStage.PROSPECTING,
    DealStage.NEGOTIATION,
    DealStage.CLOSED_WON
  ];

  // Properties for grouping
  groupByField: string | null = null;
  currentGrouping: 'source' | 'stage' | null = null;
  groupedData: {
    bySource?: Record<string, Record<string, Deal[]>>;
    byStage?: Record<string, Deal[]>;
    byAssignee?: Record<string, Record<string, Deal[]>>;
  } = {};

  // For grid view grouping
  expandedGroupsGrid: Set<string> = new Set();

  // Déclaration des tableaux qui seront initialisés dynamiquement
  sortFields: { label: string; value: string }[] = [];
  groupFields: { label: string; value: string }[] = [];
  filters: { label: string; value: string }[] = [];

  constructor(
    private dealService: DealService,
    private location: Location,
    private activityService: ActivityService,
    private tenantSelection: TenantSelectionService,
  ) { }
  ngOnInit() {
    this.initColumns();
  this.stageOrder.forEach(stage => this.expandedGroupsGrid.add(stage));

    // Inject mock data into columns
    this.mockDeal.forEach(deal => {
      const column = this.columns.find(col => col.status === deal.stage);
      if (column) column.tasks.push(deal as any);
    });

    // Inject mock data for list view
    this.dealsAll = [...this.mockDeal];

    // Initialiser les champs dynamiquement après avoir les données
    this.initializeDynamicFields();

    // Pas besoin d'appeler updateGroupedData() ici car grouped est un getter

    this.getAllDeals();
    this.startAutoRefresh();
  }
  // Méthode pour initialiser les champs dynamiquement
  private initializeDynamicFields() {
    this.sortFields = this.generateSortFields();
    this.groupFields = this.generateGroupFields();
    this.filters = this.generateFilterFields();
  }

  // Générer les champs de tri disponibles dynamiquement - SEULEMENT Budget, Status, Assignee, Updated, Created
  private generateSortFields() {
    const availableFields = [];

    // Champs autorisés selon les contraintes
    const allowedFields = [
      { label: 'Budget', value: 'budget' },
      { label: 'Status', value: 'status' },
      { label: 'Assignee', value: 'assigned' },
      { label: 'Updated', value: 'updated' },
      { label: 'Created', value: 'created' }
    ];

    // Vérifier l'existence des champs dans les données
    if (this.dealsAll.length > 0) {
      const sampleDeal = this.dealsAll[0];

      return allowedFields.filter(field => {
        switch (field.value) {
          case 'budget':
            return sampleDeal.amount !== undefined;
          case 'status':
            return sampleDeal.stage !== undefined;
          case 'assigned':
            return sampleDeal.assignedTo !== undefined;
          case 'updated':
            return sampleDeal.lastModifiedDate !== undefined;
          case 'created':
            return sampleDeal.createdDate !== undefined;
          default:
            return false;
        }
      });
    }

    // Si pas de données, retourner tous les champs autorisés
    return allowedFields;
  }

  private generateGroupFields() {
    return [
      { label: 'Status', value: 'stage' },
      { label: 'Priority', value: 'priority' },
      { label: 'Source', value: 'source' }
    ];
  }



  // Générer les champs de filtrage dynamiquement - SEULEMENT Budget, Status, Assignee, Updated, Created
  private generateFilterFields() {
    const availableFilters = [];

    // Champs autorisés selon les contraintes
    const allowedFilters = [
      { label: 'Budget', value: 'budget' },
      { label: 'Status', value: 'status' },
      { label: 'Assignee', value: 'assigned' },
      { label: 'Updated', value: 'updated' },
      { label: 'Created', value: 'created' }
    ];

    // Vérifier l'existence des champs dans les données
    if (this.dealsAll.length > 0) {
      const sampleDeal = this.dealsAll[0];

      return allowedFilters.filter(filter => {
        switch (filter.value) {
          case 'budget':
            return sampleDeal.amount !== undefined;
          case 'status':
            return sampleDeal.stage !== undefined;
          case 'assigned':
            return sampleDeal.assignedTo !== undefined;
          case 'updated':
            return sampleDeal.lastModifiedDate !== undefined;
          case 'created':
            return sampleDeal.createdDate !== undefined;
          default:
            return false;
        }
      });
    }

    // Si pas de données, retourner tous les champs autorisés
    return allowedFilters;
  }

  // Initialize columns based on deal stages
  initColumns() {
    this.columns = this.stageOrder.map((stage, index) => {
      const colorIndex = index % this.bgColorsVars.length;
      return new Column(
        stage,
        this.bgColorsVars[colorIndex],
        this.textColorsVars[colorIndex],
        this.countColorsVars[colorIndex]
      );
    });
  }

  // Get columns in order
  getColumnsInOrder(): Column<Deal>[] {
    return this.stageOrder
      .map(stage => this.columns.find(c => c.status === stage))
      .filter(c => c !== undefined) as Column<Deal>[];
  }

  private matchesSearch(deal: Deal, query: string): boolean {
    if (!query || !query.trim()) return true;

    const q = query.toLowerCase();

    // Vérifier tous les champs disponibles dynamiquement
    const allFields = this.getAllAvailableFields();

    for (const field of allFields) {
      let value: any;

      // Extraire la valeur du champ
      value = this.extractFieldValue(deal, field);

      if (value !== null && value !== undefined) {
        if (String(value).toLowerCase().includes(q)) {
          return true;
        }
      }
    }

    return false;
  }

  // Méthode pour obtenir tous les champs disponibles dynamiquement
  private getAllAvailableFields(): string[] {
    const fields: string[] = [];

    if (this.dealsAll.length > 0) {
      const sampleDeal = this.dealsAll[0];

      // Champs de Deal
      (Object.keys(sampleDeal) as (keyof Deal)[]).forEach(key => {
        if (key !== 'lead' && sampleDeal[key] !== undefined) {
          fields.push(key.toString());
        }
      });

      // Champs de Lead
      if (sampleDeal.lead) {
        (Object.keys(sampleDeal.lead) as (keyof Lead)[]).forEach(key => {
          if (sampleDeal.lead![key] !== undefined) {
            fields.push(`lead.${key.toString()}`);
          }
        });
      }
    }

    return fields;
  }

  private extractFieldValue(deal: Deal, fieldPath: string): any {
    const parts = fieldPath.split('.');
    let current: any = deal;

    for (const part of parts) {
      if (current === null || current === undefined) return null;
      current = current[part];
    }

    return current;
  }

  onSearchQueryChange(query: string) {
    this.searchQuery = query;
    // Pas besoin d'appeler updateGroupedData car filteredDeals est un getter
  }

onGroupSelected(field: string) {
  if (field === 'none') {
    this.currentGroup = null;
    this.groupByField = null;
  } else {
    this.currentGroup = field as DealGroupBy;
    this.groupByField = field;
    
    // Ouvrir automatiquement tous les groupes lorsqu'un groupement est sélectionné
    this.expandedGroupsGrid.clear();
    
    if (field === 'stage') {
      // Pour le groupement par stage, ouvrir tous les stages
      this.getUniqueStages().forEach(stage => this.expandedGroupsGrid.add(stage));
    } else if (field === 'source') {
      // Pour le groupement par source, ouvrir toutes les sources
      this.getUniqueSources().forEach(source => this.expandedGroupsGrid.add(source));
    } else if (field === 'priority') {
      // Pour le groupement par priorité, ouvrir toutes les priorités
      this.getUniquePriorities().forEach(priority => this.expandedGroupsGrid.add(priority));
    }
  }
}


  onSortChange(sortData: { field: string, direction: 'asc' | 'desc' }) {
    // Utilisez directement la valeur du champ si disponible
    const fieldMap: { [key: string]: SortByType } = {
      'budget': 'Budget',
      'status': 'Status',
      'assigned': 'Assignee',
      'updated': 'Updated',
      'created': 'Created'
    };

    this.sortBy = fieldMap[sortData.field] || 'Updated';
    this.sortDirection = sortData.direction;
  }
  private extractGroupValue(deal: Deal, groupField: DealGroupBy): string {
    switch (groupField) {
      case 'stage':
        return this.getStageLabel(deal.stage);

      case 'priority':
        return deal.lead?.priority || 'No priority';

      case 'source':
        return deal.lead?.source || 'Unknown';

      default:
        return 'Unknown';
    }
  }

  private getStageLabel(stage?: DealStage): string {
    switch (stage) {
      case DealStage.PROSPECTING: return 'Prospecting';
      case DealStage.NEGOTIATION: return 'Negotiation';
      case DealStage.CLOSED_WON: return 'Closed Won';
      default: return 'Unknown';
    }
  }

  onViewModeChange(mode: 'grid' | 'list') {
    this.viewMode = mode;
  }

  get filteredDeals(): Deal[] {
    // Commencer avec les données de base
    let filtered = this.dealsAll;

    // Appliquer la recherche
    if (this.searchQuery.trim()) {
      filtered = filtered.filter(deal => this.matchesSearch(deal, this.searchQuery));
    }

    // Appliquer les filtres avancés
    if (this.activeFilters.length > 0) {
      filtered = filtered.filter(deal => this.applyFilters(deal));
    }

    // Trier les résultats
    return this.sortDeals(filtered);
  }
  get groupedDealsForList(): { key: string; items: Deal[] }[] {
    if (!this.currentGroup) return [];

    const map = new Map<string, Deal[]>();

    this.filteredDeals.forEach(deal => {
      const key = this.extractGroupValue(deal, this.currentGroup!);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(deal);
    });

    let groups = Array.from(map.entries()).map(([key, items]) => ({
      key,
      items: this.sortDeals(items)
    }));

    // ordre spécial pour Status
    if (this.currentGroup === 'stage') {
      const order = ['Prospecting', 'Negotiation', 'Closed Won'];
      groups.sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key));
    }
    // ordre spécial pour Priority
    else if (this.currentGroup === 'priority') {
      const priorityOrder = ['Urgent', 'High', 'Moderate', 'Low'];
      groups.sort((a, b) => {
        const aIndex = priorityOrder.indexOf(a.key);
        const bIndex = priorityOrder.indexOf(b.key);
        return (aIndex === -1 ? 999 : aIndex) - (bIndex === -1 ? 999 : bIndex);
      });
    } else {
      groups.sort((a, b) => a.key.localeCompare(b.key));
    }

    return groups;
  }

  onFilterSelected(field: string) {
    console.log('Filter selected:', field);
    // Logique de filtrage...
  }

  // Data methods
  getAllDeals() {
    this.dealService.getAllDeals().subscribe(deals => {
      this.dealsAll = deals;

      // Update columns
      this.columns.forEach(c => c.tasks = []);
      this.dealsAll.forEach(deal => {
        const column = this.columns.find(col => col.status === deal.stage);
        if (column) column.tasks.push(deal as any);
      });

      // Mettre à jour les champs dynamiques avec les nouvelles données
      this.initializeDynamicFields();
    });
  }

  private sortDeals(deals: Deal[]): Deal[] {
    if (deals.length === 0) return [];

    const sorted = [...deals];

    if (this.sortBy === 'Budget') {
      return sorted.sort((a, b) => {
        const aAmount = a.amount || 0;
        const bAmount = b.amount || 0;
        return this.sortDirection === 'asc' ? aAmount - bAmount : bAmount - aAmount;
      });
    } else if (this.sortBy === 'Status') {
      return sorted.sort((a, b) => {
        const aStage = this.extractGroupValue(a, 'stage');
        const bStage = this.extractGroupValue(b, 'stage');
        const result = aStage.localeCompare(bStage);
        return this.sortDirection === 'asc' ? result : -result;
      });
    } else if (this.sortBy === 'Assignee') {
      return sorted.sort((a, b) => {
        const aAssignee = a.assignedTo || '';
        const bAssignee = b.assignedTo || '';
        const result = aAssignee.localeCompare(bAssignee);
        return this.sortDirection === 'asc' ? result : -result;
      });
    } else if (this.sortBy === 'Updated') {
      return sorted.sort((a, b) => {
        const aDate = new Date(a.lastModifiedDate || a.createdDate || '').getTime();
        const bDate = new Date(b.lastModifiedDate || b.createdDate || '').getTime();
        return this.sortDirection === 'asc' ? aDate - bDate : bDate - aDate;
      });
    } else if (this.sortBy === 'Created') {
      return sorted.sort((a, b) => {
        const aDate = new Date(a.createdDate || '').getTime();
        const bDate = new Date(b.createdDate || '').getTime();
        return this.sortDirection === 'asc' ? aDate - bDate : bDate - aDate;
      });
    }

    return sorted;
  }
  // Modal methods
  openModal(dealId?: string, column?: Column<Deal>) {
    if (dealId) {
      this.dealService.getDealById(dealId).subscribe({
        next: (deal) => {
          this.selectedDeal = { ...deal };
          this.isFormOnly = false;
          this.showModal = true;
          this.location.replaceState(`/deals/${deal.id}`);
        },
        error: (err) => console.error('Error fetching deal:', err)
      });
    } else {
      this.isFormOnly = true;
      this.selectedDeal = {
        stage: column ? (column.status as DealStage) : DealStage.PROSPECTING,
        lead: {} as Lead
      } as Deal;
      this.showModal = true;
    }
  }

  onModalClosed() {
    this.showModal = false;
    this.selectedDeal = {} as Deal;
    this.isFormOnly = false;
    this.getAllDeals();
  }

  // Drag and drop
  dropColumn(event: CdkDragDrop<Column<Deal>[]>) {
    moveItemInArray(this.columns, event.previousIndex, event.currentIndex);
  }

  dropTask(event: CdkDragDrop<any[]>, column: Column<Deal>) {
    let movedDeal: Deal;

    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      return;
    } else {
      movedDeal = event.previousContainer.data[event.previousIndex];

      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }

    if (movedDeal && movedDeal.id) {
      const newStage = column.status as DealStage;

      this.dealService.updateDeal(movedDeal.id, { ...movedDeal, stage: newStage })
        .subscribe({
          next: (deal) => {
            movedDeal.stage = deal.stage;
          },
          error: err => console.error('Error updating deal:', err)
        });
    }
  }

  getConnectedLists(currentCol: Column<Deal>): string[] {
    return this.columns
      .filter(c => c !== currentCol)
      .map(c => c.status);
  }

  getVisibleDeals(col: Column<Deal>): any[] {
    // Filtrer d'abord
    let tasks = col.tasks.filter((deal: any) => {
      const matchesSearch = this.matchesSearch(deal, this.searchQuery);
      const matchesFilters = this.applyFilters(deal);
      return matchesSearch && matchesFilters;
    });

    // Ensuite trier
    return this.sortDeals(tasks);
  }

  private applyFilters(deal: Deal): boolean {
    // Si aucun filtre actif, retourner true
    if (this.activeFilters.length === 0) return true;

    return this.activeFilters.every(filter => {
      const value = this.getFilterValue(deal, filter.field);
      if (value === null || value === undefined) return false;

      const filterValue = filter.value.toLowerCase();
      const dealValue = String(value).toLowerCase();

      switch (filter.operator) {
        case 'equals':
          return dealValue === filterValue;
        case 'contains':
          return dealValue.includes(filterValue);
        case 'startsWith':
          return dealValue.startsWith(filterValue);
        case 'endsWith':
          return dealValue.endsWith(filterValue);
        case 'greaterThan':
          const numValue = parseFloat(dealValue);
          const numFilter = parseFloat(filterValue);
          return !isNaN(numValue) && !isNaN(numFilter) && numValue > numFilter;
        case 'lessThan':
          const numValue2 = parseFloat(dealValue);
          const numFilter2 = parseFloat(filterValue);
          return !isNaN(numValue2) && !isNaN(numFilter2) && numValue2 < numFilter2;
        default:
          return true;
      }
    });
  }

  // Méthode pour obtenir la valeur du filtre depuis le deal - SEULEMENT Budget, Status, Assignee, Updated, Created
  private getFilterValue(deal: Deal, field: string): any {
    switch (field) {
      case 'budget':
        return deal.amount;
      case 'status':
        return deal.stage;
      case 'assigned':
        return deal.assignedTo;
      case 'updated':
        return deal.lastModifiedDate || deal.createdDate;
      case 'created':
        return deal.createdDate;
      default:
        // Essayer d'extraire dynamiquement
        return this.extractFieldValue(deal, field);
    }
  }

  // Helper pour transformer un Deal en objet compatible avec CardComponent
  getDealForCard(deal: Deal): any {
    return {
      id: deal.id,
      fullName: deal.lead?.fullName || deal.title || 'No title',
      company: deal.lead?.company || 'No company',
      email: deal.lead?.email,
      phone: deal.lead?.phone,
      status: deal.stage,
      source: deal.lead?.source,
      assignedTo: deal.assignedTo,
      estimatedValue: deal.amount,
      location: deal.lead?.location,
      tags: deal.lead?.tags,
      createdAt: deal.createdAt,
      // Garder l'objet deal original pour référence
      _deal: deal
    };
  }

  // Grid grouping methods
  toggleGroupGrid(key: string) {
    if (this.expandedGroupsGrid.has(key)) {
      this.expandedGroupsGrid.delete(key);
    } else {
      this.expandedGroupsGrid.add(key);
    }
  }

  isGroupExpandedGrid(key: string): boolean {
    return this.expandedGroupsGrid.has(key);
  }

  getUniqueStages(): string[] {
    const stages = new Set<string>();
    this.columns.forEach(col => {
      stages.add(col.status);
    });
    return Array.from(stages);
  }

  getUniqueSources(): string[] {
    const sources = new Set<string>();
    this.columns.forEach(col => {
      col.tasks.forEach((deal: any) => {
        if (deal.lead?.source) {
          sources.add(deal.lead.source);
        }
      });
    });
    return Array.from(sources).filter(source => source && source !== 'Unknown');
  }

  getDealsByStage(stage: string): any[] {
    const col = this.columns.find(c => c.status === stage);
    if (!col) return [];

    // Filtrer d'abord
    let tasks = col.tasks.filter((deal: any) => {
      const matchesSearch = this.matchesSearch(deal, this.searchQuery);
      const matchesFilters = this.applyFilters(deal);
      return matchesSearch && matchesFilters;
    });

    // Ensuite trier
    return this.sortDeals(tasks);
  }

  getDealsBySourceAndStage(source: string, stage: string): any[] {
    const col = this.columns.find(c => c.status === stage);
    if (!col) return [];

    // Filtrer d'abord
    let tasks = col.tasks.filter((deal: any) => {
      const matchesSource = deal.lead?.source === source;
      const matchesSearch = this.matchesSearch(deal, this.searchQuery);
      const matchesFilters = this.applyFilters(deal);
      return matchesSource && matchesSearch && matchesFilters;
    });

    // Ensuite trier
    return this.sortDeals(tasks);
  }

  getTotalDealsBySource(source: string): number {
    let total = 0;

    this.columns.forEach(col => {
      col.tasks.forEach((deal: any) => {
        if (deal.lead?.source === source && this.matchesSearch(deal, this.searchQuery)) {
          total++;
        }
      });
    });

    return total;
  }

  // Auto refresh
  startAutoRefresh() {
    if (this.refreshSubscription) this.refreshSubscription.unsubscribe();
    this.refreshSubscription = interval(60000).subscribe(() => this.checkForUpdates());
  }

  checkForUpdates() {
    if (this.showQuickDeal || this.showModal) return;

    this.dealService.getAllDeals().subscribe(deals => {
      this.dealsAll = deals;

      this.columns.forEach(c => c.tasks = []);
      deals.forEach(deal => {
        const col = this.columns.find(c => c.status === deal.stage);
        if (col) col.tasks.push(deal as any);
      });

      // Mettre à jour les champs dynamiques
      this.initializeDynamicFields();
    });
  }

  ngOnDestroy() {
    this.refreshSubscription?.unsubscribe();
  }

  // Grouping methods (for list view)
  toggleGroup(key: string) {
    if (this.expandedGroups.has(key)) this.expandedGroups.delete(key);
    else this.expandedGroups.add(key);
  }

  isGroupExpanded(key: string): boolean {
    return this.expandedGroups.has(key);
  }


  // Helper methods
  getStatusClass(stage: string): string {
    const stageMap: Record<string, string> = {
      'Prospecting': 'pf-m-blue',
      'Negotiation': 'pf-m-yellow',
      'ClosedWon': 'pf-m-green'
    };
    return stageMap[stage] || '';
  }

  // Méthode pour le template - obtient le nom de l'entreprise depuis le lead
  getCompany(deal: Deal): string {
    return deal.lead?.company || 'No company';
  }

  // Méthode pour le template - obtient le nom complet depuis le lead
  getFullName(deal: Deal): string {
    return deal.lead?.fullName || deal.title || 'No title';
  }

  // Méthode pour le template - obtient la source depuis le lead
  getSource(deal: Deal): string {
    return deal.lead?.source || 'Unknown';
  }

  mapGroupToDealListGroup(): 'Stage' | 'Priority' | 'Source' | null {
    if (!this.currentGroup) return null;

    switch (this.currentGroup) {
      case 'stage':
        return 'Stage';
      case 'priority':
        return 'Priority';
      case 'source':
        return 'Source';
      default:
        return null;
    }
  }

  // Méthode pour convertir sortBy de DealBoard vers DealList
  getDealListSortBy(): DealListSortBy {
    switch (this.sortBy) {
      case 'Updated':
        return 'Updated';
      case 'Created':
        return 'Created';
      case 'Status':
        return 'Stage';
      case 'Budget':
        return 'Updated'; // Fallback pour Budget
      case 'Assignee':
        return 'Updated'; // Fallback pour Assignee
      default:
        return 'Updated';
    }
  }

  // Méthode pour gérer le changement de tri depuis DealList
  onSortByChange(sort: 'Updated' | 'Created' | 'Name' | 'Stage') {
    // Convertir de DealList vers DealBoard
    switch (sort) {
      case 'Updated':
        this.sortBy = 'Updated';
        break;
      case 'Created':
        this.sortBy = 'Created';
        break;
      case 'Stage':
        this.sortBy = 'Status';
        break;
      default:
        this.sortBy = 'Updated';
    }
    this.sortDirection = 'desc'; // Mettre à jour la direction si nécessaire
  }

  // Récupérer tous les deals d'une priorité spécifique
  getDealsByPriority(priority: string): Deal[] {
    const deals: Deal[] = [];

    this.columns.forEach(col => {
      col.tasks.forEach((deal: Deal) => {
        const matchesPriority = deal.lead?.priority === priority;
        const matchesSearch = this.matchesSearch(deal, this.searchQuery);
        const matchesFilters = this.applyFilters(deal);

        if (matchesPriority && matchesSearch && matchesFilters) {
          deals.push(deal);
        }
      });
    });

    return this.sortDeals(deals);
  }

  // Récupérer le total de deals pour une priorité donnée
  getTotalDealsByPriority(priority: string): number {
    let total = 0;

    this.columns.forEach(col => {
      col.tasks.forEach((deal: Deal) => {
        if (deal.lead?.priority === priority && this.matchesSearch(deal, this.searchQuery)) {
          total++;
        }
      });
    });

    return total;
  }

  // Récupérer toutes les priorités uniques (pour générer des groupes)
  getUniquePriorities(): string[] {
    const priorities = new Set<string>();

    this.columns.forEach(col => {
      col.tasks.forEach((deal: Deal) => {
        if (deal.lead?.priority) {
          priorities.add(deal.lead.priority);
        }
      });
    });

    return Array.from(priorities);
  }
  // Récupérer tous les deals pour une priorité ET un stage spécifique
  getDealsByPriorityAndStage(priority: string, stage: string): Deal[] {
    const deals: Deal[] = [];

    this.columns.forEach(col => {
      // Filtrer uniquement la colonne correspondant au stage
      if (col.status === stage) {
        col.tasks.forEach((deal: Deal) => {
          const matchesPriority = deal.lead?.priority === priority;
          const matchesSearch = this.matchesSearch(deal, this.searchQuery);
          const matchesFilters = this.applyFilters(deal);

          if (matchesPriority && matchesSearch && matchesFilters) {
            deals.push(deal);
          }
        });
      }
    });

    return this.sortDeals(deals);
  }

}