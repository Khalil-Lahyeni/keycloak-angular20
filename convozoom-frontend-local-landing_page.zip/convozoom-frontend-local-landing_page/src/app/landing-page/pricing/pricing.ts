import { Component } from '@angular/core';

@Component({
  selector: 'app-pricing',
  imports: [],
  templateUrl: './pricing.html',
  styleUrl: './pricing.scss'
})
export class Pricing {
  // billing toggle state: 'monthly' | 'yearly'
  billingPeriod: 'monthly' | 'yearly' = 'monthly';

  setBillingPeriod(period: 'monthly' | 'yearly') {
    this.billingPeriod = period;
  }

  // Prices per plan, per period (numbers; adjust as needed)
  prices = {
    plan1: { monthly: 8.99, yearly: 8.99 * 12 },
    plan2: { monthly: 18.99, yearly: 18.99 * 12 },
    plan3: { monthly: 48.99, yearly: 48.99 * 12 }
  } as const;

  // Period label text
  periodLabel: Record<'monthly' | 'yearly', string> = {
    monthly: '/per month',
    yearly: '/per year'
  };

  // Helpers to format display
  displayPrice(plan: 'plan1' | 'plan2' | 'plan3'): string {
    const value = this.prices[plan][this.billingPeriod];
    return value.toFixed(2);
  }
}
