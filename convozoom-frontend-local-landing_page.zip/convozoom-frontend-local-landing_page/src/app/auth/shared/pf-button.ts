import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

export type PfButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'link' | 'danger' | 'control';
export type PfButtonType = 'button' | 'submit' | 'reset';
export type PfButtonSize = '' | 'small' | 'large';

@Component({
  selector: 'pf-button',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pf-button.html'
})
export class PfButtonComponent {
  @Input() variant: PfButtonVariant = 'primary';
  @Input() type: PfButtonType = 'button';
  @Input() size: PfButtonSize = '';
  @Input() block = false;
  @Input() disabled = false;
}
