import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadBoard } from './lead-board';

describe('LeadBoard', () => {
  let component: LeadBoard;
  let fixture: ComponentFixture<LeadBoard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LeadBoard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LeadBoard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
