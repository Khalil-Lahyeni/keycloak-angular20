import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../config';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ErrorHandlerService } from './error-handler.service';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GoogleSheetService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  readData(spreadsheetId: string, range: string): Observable<any> {
    return this.http.get<any>(`${this.base}/sheets/read/${spreadsheetId}/${range}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'readData');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error reading Google Sheet data');
        return throwError(() => errorInfo);
      })
    );
  }
}
