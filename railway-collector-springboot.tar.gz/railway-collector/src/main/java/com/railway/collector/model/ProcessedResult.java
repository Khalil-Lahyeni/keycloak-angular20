package com.railway.collector.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessedResult {

    private String trainId;
    private String topicType;

    @Builder.Default
    private Instant processedAt = Instant.now();

    private Map<String, Object> enrichedData;

    @Builder.Default
    private List<Alert> alerts = new ArrayList<>();

    @Builder.Default
    private int healthScore = 100;

    private Alert.Severity maxSeverity;
}
