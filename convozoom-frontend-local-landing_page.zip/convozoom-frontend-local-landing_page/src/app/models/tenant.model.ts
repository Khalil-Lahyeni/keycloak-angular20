export enum TenantType {
  Agency = 'Agency',
  Broker = 'Broker',
  Developer = 'Developer',
  Investor = 'Investor'
}

export interface TenantDTO {
  id?: string;
  code?: string;
  name: string;
  description: string;
  type: TenantType;
  url?: string;
  email: string;
  urlConsole?: string;
}
