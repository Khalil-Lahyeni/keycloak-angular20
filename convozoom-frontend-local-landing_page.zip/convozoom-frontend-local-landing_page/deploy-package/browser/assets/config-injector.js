/**
 * Runtime Configuration Injector
 * This script injects environment variables into the window object
 * so they can be accessed by the Angular application at runtime.
 * 
 * Usage: Include this script in your HTML before the Angular app loads
 * and set the environment variables in your deployment script.
 */

(function() {
  'use strict';
  
  // Configuration object that will be injected into the window
  window.__RUNTIME_CONFIG__ = {
    // Keycloak Configuration
    KEYCLOAK_URL: '{{KEYCLOAK_URL}}',
    KEYCLOAK_REALM: '{{KEYCLOAK_REALM}}',
    KEYCLOAK_CLIENT_ID: '{{KEYCLOAK_CLIENT_ID}}',
    
    // API Configuration
    API_BASE_URL: '{{API_BASE_URL}}',
    
    // Environment Configuration
    ENVIRONMENT: '{{ENVIRONMENT}}',
    DEBUG_MODE: '{{DEBUG_MODE}}'
  };
  
  console.log('Runtime configuration injected:', window.__RUNTIME_CONFIG__);
})();
