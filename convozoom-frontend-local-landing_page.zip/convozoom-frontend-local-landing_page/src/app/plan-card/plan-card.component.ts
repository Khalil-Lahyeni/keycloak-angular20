import { Component } from '@angular/core';
import { PlanItemDTO } from '../models/plan-item.model';
import { PlanDTO } from '../models/plan.model';
import { TenantDTO } from '../models/tenant.model';
import { PlanItemService } from '../services/plan-item.service';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

type Card = { id: string; name: string; price: number; description: string };

@Component({
  selector: 'app-plan-card',
  imports: [CurrencyPipe,CommonModule, FormsModule],
  templateUrl: './plan-card.component.html',
  styleUrls: ['./plan-card.component.scss']
})
export class PlanCardComponent {

  tenantId = 'TENANT_ID_A_REMPLACER';


  cards: Card[] = [
    { id: 'plan-basic-id',      name: 'Basic',      price: 0,   description: 'Idéal pour démarrer avec l\'essentiel.' },
    { id: 'plan-pro-id',        name: 'Pro',        price: 49,  description: 'Pour les équipes qui grandissent.' },
    { id: 'plan-enterprise-id', name: 'Enterprise', price: 149, description: 'Fonctionnalités avancées & support.' }
  ];

  loadingIndex: number | null = null;
  message = '';

  constructor(private planItem: PlanItemService) {}

  private dstr(d: Date) { return d.toISOString().slice(0, 10); } 
  private refById<T>(id: string): T { return { id } as unknown as T; }

  choose(c: Card, i: number) {
    this.message = '';
    this.loadingIndex = i;

    const start = new Date();
    const end = new Date(); end.setMonth(end.getMonth() + 1);

    const payload: PlanItemDTO = {
      startDate: this.dstr(start),
      endDate: this.dstr(end),
      finalPrice: c.price,
      enable: true,

      plan:   this.refById<PlanDTO>(c.id),
      tenant: this.refById<TenantDTO>(this.tenantId),
    };

    this.planItem.create(payload).subscribe({
      next: () => {
        this.message = `Plan "${c.name}" activé.`;
        this.loadingIndex = null;
      },
      error: (e) => {
        this.message = `Erreur d'activation: ${e?.error?.message || e?.message || 'inconnue'}`;
        this.loadingIndex = null;
      }
    });
  }
}
