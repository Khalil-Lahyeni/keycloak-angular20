import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DealBoard } from './deal-board';

describe('DealBoard', () => {
  let component: DealBoard;
  let fixture: ComponentFixture<DealBoard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DealBoard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DealBoard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
