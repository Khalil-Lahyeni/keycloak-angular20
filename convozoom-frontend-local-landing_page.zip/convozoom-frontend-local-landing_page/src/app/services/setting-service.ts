import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { SettingDTO } from '../models/setting.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({
  providedIn: 'root'
})
export class SettingService {
  appConfigService = inject(AppConfigService);
  private  base : string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllSettings(tenantId: string): Observable<SettingDTO[]> {
    return this.http.get<SettingDTO[]>(`${this.base}/settings/tenant/${tenantId}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllSettings');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving settings');
        return throwError(() => errorInfo);
      })
    );
  }

  getSetting(id: string): Observable<SettingDTO> {
    return this.http.get<SettingDTO>(`${this.base}/settings/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getSetting');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the setting');
        return throwError(() => errorInfo);
      })
    );
  }

  addSetting(setting: SettingDTO): Observable<SettingDTO> {
    return this.http.post<SettingDTO>(`${this.base}/settings`, setting).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createSetting');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the setting');
        return throwError(() => errorInfo);
      })
    );
  }

  updateSetting(id: string, setting: SettingDTO): Observable<SettingDTO> {
    return this.http.put<SettingDTO>(`${this.base}/settings/${id}`, setting).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateSetting');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the setting');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateSetting(id: string, setting: Partial<SettingDTO>): Observable<SettingDTO> {
    return this.http.patch<SettingDTO>(`${this.base}/settings/${id}`, setting).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateSetting');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the setting');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteSetting(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/settings/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteSetting');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the setting');
        return throwError(() => errorInfo);
      })
    );
  }
  
  authorize(tenantId: string, settingValue: string): Observable<{authUrl: string}> {
    return this.http.get<{ authUrl: string }>(`${this.base}/google-oauth/authorize/${tenantId}/${settingValue}`);
  }
}



