import { Component, OnInit, signal } from '@angular/core';
import { TenantDTO, TenantType } from '../models/tenant.model';
import { NotificationService } from '../services/notification';
import { FormsModule, NgForm } from '@angular/forms';
import { TenantService } from '../services/tenant-service';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ErrorInfo } from '../services/error-handler.service';
import { LoadingService } from '../services/loading.service';

@Component({
  selector: 'app-tenant-form',
  imports: [CommonModule, FormsModule],
  templateUrl: './tenant-form.html',
  styleUrl: './tenant-form.css'
})
export class TenantForm implements OnInit {
  formTenant: TenantDTO = {
    id: undefined,
    code: '',
    name: '',
    description: '',
  type: TenantType.Agency,
    url: '',
    email: '',
    urlConsole: ''
  };

  types = Object.values(TenantType);
  isEditMode = signal(false);
  submitted = signal(false);
  selectedPlan = signal<string>('starter');
  isTypeDropdownOpen = signal(false);

  constructor(
    private tenantService: TenantService,
    private tenantSelectionService: TenantSelectionService,
    private route: ActivatedRoute,
    private router: Router,
    private notification: NotificationService,
    private loadingService: LoadingService
  ) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const selected = id ? this.tenantSelectionService.selectedTenant() : null;
    if (selected) {
      this.formTenant = { ...selected };
      this.isEditMode.set(true);
    } else {
      this.isEditMode.set(false);
    }
  }

  selectPlan(plan: string): void {
    this.selectedPlan.set(plan);
  }

  toggleTypeDropdown(): void {
    this.isTypeDropdownOpen.update(open => !open);
  }

  selectType(type: TenantType): void {
    this.formTenant.type = type;
    this.isTypeDropdownOpen.set(false);
  }

  resetForm(): void {
    this.formTenant = {
      id: undefined,
      code: '',
      name: '',
      description: '',
      type: TenantType.Agency,
      url: '',
      email: '',
      urlConsole:''
    };
    this.isEditMode.set(false);
    this.submitted.set(false);
    this.selectedPlan.set('starter');
    this.isTypeDropdownOpen.set(false);
  }

  onSubmit(form: NgForm) {
    this.submitted.set(true);
    if (!form.valid) return;

    const currentTenant = { ...this.formTenant };

    if (this.isEditMode() && currentTenant.id) {
      this.loadingService.show();
      this.tenantService.updateTenant(currentTenant.id, currentTenant).subscribe({
        next: () => {
          this.loadingService.hide();
          this.notification.showSuccess('Tenant mis à jour avec succès !');
          this.tenantSelectionService.clearTenant();
          this.router.navigate(['/tenant']);
        },
        error: (errorInfo: ErrorInfo) => {
          this.loadingService.hide();
          this.notification.showError(errorInfo.message);
        }
      });
    } else {
      this.loadingService.show();
      this.tenantService.createTenant(currentTenant).subscribe({
        next: () => {
          this.loadingService.hide();
          this.notification.showSuccess('Tenant créé avec succès !');
          this.tenantSelectionService.clearTenant();
          this.router.navigate(['/tenant']);
        },
        error: (errorInfo: ErrorInfo) => {
          this.loadingService.hide();
          this.notification.showError(errorInfo.message);
        }
      });
    }
  }

  onCancel(): void {
    this.tenantSelectionService.clearTenant();
    this.router.navigate(['/tenant']);
  }
}
