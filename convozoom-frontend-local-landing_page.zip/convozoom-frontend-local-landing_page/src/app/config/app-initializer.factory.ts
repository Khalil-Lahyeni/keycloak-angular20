import { AppConfigService } from './app-config.service';
import { AppConfig } from './app.config.interface';

export function initializeApp(configService: AppConfigService) {
  return () => {
    return new Promise<void>((resolve) => {
      configService.getConfig().subscribe((config: AppConfig) => {
        // Store the config synchronously for immediate access
        configService.setConfig(config);
        resolve();
      });
    });
  };
}
