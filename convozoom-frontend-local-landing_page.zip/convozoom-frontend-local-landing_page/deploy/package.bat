@echo off
REM Production Package Script for Windows
REM This script creates a production-ready deployment package

echo Creating production deployment package...

REM Check if .env file exists
if not exist ".env" (
    echo Error: .env file not found!
    echo Please copy deploy/.env.example to .env and configure your settings.
    pause
    exit /b 1
)

REM Load environment variables from .env file
for /f "usebackq tokens=1,2 delims==" %%a in (".env") do (
    if not "%%a"=="" if not "%%a:~0,1%"=="#" (
        set "%%a=%%b"
    )
)

REM Build the application
echo Building Angular application...
call npm run build:prod
if errorlevel 1 (
    echo Build failed!
    pause
    exit /b 1
)

REM Inject configuration
echo Injecting configuration...
node deploy/build.js
if errorlevel 1 (
    echo Configuration injection failed!
    pause
    exit /b 1
)

REM Create deployment package
echo Creating deployment package...
if exist "deploy-package" rmdir /s /q "deploy-package"
mkdir "deploy-package"

REM Copy built application
xcopy "dist\convozoom-front\*" "deploy-package\" /E /I /Y

REM Copy deployment files
copy "deploy\.env.example" "deploy-package\"
copy "deploy\nginx.conf" "deploy-package\"
copy "deploy\docker-compose.yml" "deploy-package\"
copy "deploy\Dockerfile.serve" "deploy-package\"

REM Create README for deployment
echo Creating deployment README...
(
echo # ConvoZoom Frontend Deployment Package
echo.
echo This package contains a production-ready build of the ConvoZoom frontend.
echo.
echo ## Quick Start
echo.
echo 1. Copy `.env.example` to `.env` and configure your environment variables:
echo    - KEYCLOAK_URL: Your Keycloak server URL
echo    - KEYCLOAK_REALM: Your Keycloak realm
echo    - KEYCLOAK_CLIENT_ID: Your Keycloak client ID
echo    - API_BASE_URL: Your backend API URL
echo.
echo 2. For Docker deployment:
echo    ```bash
echo    docker-compose up -d
echo    ```
echo.
echo 3. For manual deployment:
echo    - Serve the files using any web server (nginx, Apache, etc.)
echo    - Make sure to serve the `config-injector.js` file from `/assets/`
echo.
echo ## Configuration
echo.
echo The application uses runtime configuration injection. The `config-injector.js`
echo file in the assets folder contains the environment-specific configuration.
echo.
echo ## Environment Variables
echo.
echo - KEYCLOAK_URL: Keycloak server URL
echo - KEYCLOAK_REALM: Keycloak realm name
echo - KEYCLOAK_CLIENT_ID: Keycloak client ID
echo - API_BASE_URL: Backend API base URL
echo - ENVIRONMENT: Environment name (production, staging, etc.)
echo - DEBUG_MODE: Enable debug mode (true/false)
echo.
) > "deploy-package\README.md"

echo.
echo Deployment package created successfully!
echo Location: deploy-package\
echo.
echo Next steps:
echo 1. Copy the deploy-package folder to your server
echo 2. Configure the .env file with your environment settings
echo 3. Deploy using Docker or your preferred web server
echo.
pause
