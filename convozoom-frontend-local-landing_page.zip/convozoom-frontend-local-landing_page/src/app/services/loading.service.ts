import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {
  private _isLoading = signal(false);

  // Read-only signal for components to subscribe to
  isLoading = this._isLoading.asReadonly();

  /**
   * Show loading spinner
   */
  show(): void {
    this._isLoading.set(true);
  }

  /**
   * Hide loading spinner
   */
  hide(): void {
    this._isLoading.set(false);
  }

  /**
   * Execute an operation with loading state
   * @param operation - Promise or Observable to execute
   */
  async withLoading<T>(operation: Promise<T>): Promise<T> {
    this.show();
    try {
      const result = await operation;
      return result;
    } finally {
      this.hide();
    }
  }
}
