import { Deal } from "./deal.model";
import { Lead } from "./lead.model";

export enum ActivityType {
  CALL = 'Call',
  EMAIL = 'Email',
  MEETING = 'Meeting'
}

export interface Activity {
  id?: string;
  tenantId: string;
  type?: ActivityType;
  dateTime: string; 
  performedBy?: string;
  summary?: string;
  details?: string;
  createdAt: string;
  lead?: Lead;
  deal?: Deal;
}
