@echo off
REM Configuration Injection Script for Windows
REM This script reads environment variables and injects them into the config-injector.js file

setlocal enabledelayedexpansion

REM Set default values
set CONFIG_FILE=src\assets\config-injector.js
set OUTPUT_FILE=dist\convozoom-front\assets\config-injector.js

REM Check if custom files are provided
if not "%1"=="" set CONFIG_FILE=%1
if not "%2"=="" set OUTPUT_FILE=%2

REM Set default environment variables if not already set
if "%KEYCLOAK_URL%"=="" set KEYCLOAK_URL=http://localhost:8080
if "%KEYCLOAK_REALM%"=="" set KEYCLOAK_REALM=agency_01
if "%KEYCLOAK_CLIENT_ID%"=="" set KEYCLOAK_CLIENT_ID=convozoom-frontEnd_client_01
if "%API_BASE_URL%"=="" set API_BASE_URL=http://localhost:3000/api
if "%ENVIRONMENT%"=="" set ENVIRONMENT=production
if "%DEBUG_MODE%"=="" set DEBUG_MODE=false

echo Configuration Injection Script for Windows
echo ==========================================
echo Config File: %CONFIG_FILE%
echo Output File: %OUTPUT_FILE%
echo.
echo Environment Variables:
echo   KEYCLOAK_URL: %KEYCLOAK_URL%
echo   KEYCLOAK_REALM: %KEYCLOAK_REALM%
echo   KEYCLOAK_CLIENT_ID: %KEYCLOAK_CLIENT_ID%
echo   API_BASE_URL: %API_BASE_URL%
echo   ENVIRONMENT: %ENVIRONMENT%
echo   DEBUG_MODE: %DEBUG_MODE%
echo.

REM Check if config file exists
if not exist "%CONFIG_FILE%" (
    echo Error: Config file not found: %CONFIG_FILE%
    exit /b 1
)

REM Create output directory
for %%F in ("%OUTPUT_FILE%") do set OUTPUT_DIR=%%~dpF
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

REM Read and replace the config file using PowerShell for better text processing
echo Injecting configuration...
powershell -Command "& { $content = Get-Content '%CONFIG_FILE%' -Raw; $content = $content -replace '{{KEYCLOAK_URL}}', '%KEYCLOAK_URL%'; $content = $content -replace '{{KEYCLOAK_REALM}}', '%KEYCLOAK_REALM%'; $content = $content -replace '{{KEYCLOAK_CLIENT_ID}}', '%KEYCLOAK_CLIENT_ID%'; $content = $content -replace '{{API_BASE_URL}}', '%API_BASE_URL%'; $content = $content -replace '{{ENVIRONMENT}}', '%ENVIRONMENT%'; $content = $content -replace '{{DEBUG_MODE}}', '%DEBUG_MODE%'; $content | Out-File '%OUTPUT_FILE%' -Encoding UTF8 }"

if %ERRORLEVEL% EQU 0 (
    echo Configuration injected successfully!
    echo Output file: %OUTPUT_FILE%
) else (
    echo Error: Failed to inject configuration
    exit /b 1
)

endlocal
