import { KeycloakService } from 'keycloak-angular';
import { AppConfigService } from '../config/app-config.service';

export function initializeKeycloak(keycloakService: KeycloakService, configService: AppConfigService) {
  return () => {
    return new Promise<void>((resolve, reject) => {
      configService.getConfig().subscribe((config) => {
        keycloakService.init({
          config: {
            url: config.keycloak.url,
            realm: config.keycloak.realm,
            clientId: config.keycloak.clientId
          },
          initOptions: {
            onLoad: 'check-sso',
            pkceMethod: 'S256',
            checkLoginIframe: false
          },
          bearerExcludedUrls: ['/assets', '/favicon.ico']
        }).then(() => {
          console.log('Keycloak initialized successfully with config:', config.keycloak);
          resolve();
        }).catch((error) => {
          console.error('Failed to initialize Keycloak:', error);
          reject(error);
        });
      });
    });
  };
}


