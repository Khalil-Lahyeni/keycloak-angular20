import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../auth/auth.service';

interface NavItem {
  label: string;
  route?: string;
  icon?: string;
  children?: NavItem[];
  expanded?: boolean;
  display?: boolean;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.scss'
})
export class Sidebar implements OnInit {
  private authService = inject(AuthService);
  isExpanded = true;
  isMobileMenuOpen = false;
  isConfigModalOpen = false;
  isSalesManager = false;
  isTenantAdmin = false;
  isSuperAdmin = false;
  private mobileQuery!: MediaQueryList;
  userInfo = {
    name: '',
    email: '',
    firstName: '',
    lastName: ''
  };

  ngOnInit(): void {
    this.checkRole();
    this.initMediaQuery();
    this.loadUserInfo();
  }

  private initMediaQuery(): void {

    this.mobileQuery = window.matchMedia('(max-width: 1040px)');
    

    if (this.mobileQuery.matches) {
      this.isExpanded = false; 
      this.isMobileMenuOpen = false;
    } else {
      this.isExpanded = true; 
    }
    

    this.mobileQuery.addEventListener('change', (e) => {
      if (e.matches) {

        this.isExpanded = false;
        this.isMobileMenuOpen = false;
          } else {

        this.isExpanded = true;
        this.isMobileMenuOpen = false;
          }
    });
  }
  navItems: NavItem[] = [
    {
      label: 'Dashboard',
      route: '/home',
      icon: 'assets/dashboard.svg',
      display: undefined  // Visible for all users (superadmin and regular users)
    },
    // {
    //   label: 'Reports',
    //   route: '/reports',
    //   icon: 'assets/reports.svg'
    // },
    {
      label: 'Leads',
      route: '/lead-board',
      icon: 'assets/leads.svg',
      display: false
    },
    {
      label: 'Deals',
      route: '/deal-board',
      icon: 'assets/deal.svg',
      display: false
    },
    {
      label: 'Tenant management',
      route: '/tenant',
      icon: 'assets/tenant.svg',
      display: true
    }
    // {
    //   label: 'Requests',
    //   route: '/requests',
    //   icon: 'assets/requests.svg'
    // },
    // {
    //   label: 'Surveys',
    //   route: '/surveys',
    //   icon: 'assets/surveys.svg'
    // }
  ];

  userManagementItem: NavItem = {
    label: 'User',
    route: '/user-management',
    icon: 'assets/user_management.svg'
  };

  configurationItem: NavItem = {
    label: 'Preferences',
    icon: 'assets/setting.svg',
    expanded: false,
    children: [
      {
        label: 'Settings',
        route: '/settings'
      },
      {
        label: 'Templates',
        route: '/templates'
      }
      // {
      //   label: 'Plan',
      //   route: '/plan'
      // },
      // {
      //   label: 'Contacts',
      //   route: '/contacts'
      // }
    ]
  };


  toggleExpanded(item: NavItem): void {
    if (item.children) {

      if (!this.isExpanded && item === this.configurationItem) {
        this.isConfigModalOpen = !this.isConfigModalOpen;
          } else {
        item.expanded = !item.expanded;
          }
    }
  }

  closeConfigModal(): void {
    this.isConfigModalOpen = false;
  }

  getNavId(label: string): string {
    return 'nav-' + label.toLowerCase().replace(/\s+/g, '-');
  }

  async signOut(): Promise<void> {
  try {
      await this.authService.logout();
    } catch (error) {
      console.error('Error during logout:', error);
    }
  }

  toggleSidebar(): void {

    if (this.mobileQuery.matches) {
      this.isMobileMenuOpen = !this.isMobileMenuOpen;
      } else {
      this.isExpanded = !this.isExpanded;
      }
  }

  closeMobileMenu(): void {
    this.isMobileMenuOpen = false;
  }

  private async loadUserInfo(): Promise<void> {
    try {
      const profile = await this.authService.getUserProfile();
      
      if (profile) {
        const firstName = profile.firstName || '';
        const lastName = profile.lastName || '';
        const fullName = `${firstName} ${lastName}`.trim();
        
        this.userInfo = {
          name: fullName || profile.username || profile.email || 'User',
          email: profile.email || '',
          firstName: firstName,
          lastName: lastName
        };
      }
    } catch (error) {
      console.error('Error loading user info:', error);
      this.userInfo = {
        name: 'User',
        email: '',
        firstName: '',
        lastName: ''
      };
    }
  }

    private async checkRole() {
    try {
      this.isSalesManager = await this.authService.isSalesManager();
      this.isTenantAdmin = await this.authService.isTenantAdmin();
      this.isSuperAdmin = await this.authService.isSuperAdmin();
      
      } catch (error) {
      this.isSalesManager = false;
      this.isTenantAdmin = false;
      this.isSuperAdmin = false;
      
      }
  }
}
