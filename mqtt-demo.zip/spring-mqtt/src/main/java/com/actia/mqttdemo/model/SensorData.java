package com.actia.mqttdemo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorData {

    @JsonProperty("device_id")
    private String deviceId;

    @JsonProperty("sensor_type")
    private String sensorType;    // temperature, humidity, gps, status

    private double value;

    private String unit;

    @JsonProperty("timestamp")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime timestamp;

    // Extra fields for GPS
    private Double latitude;
    private Double longitude;

    // Extra field for status
    private String status;        // ONLINE, OFFLINE, ERROR, MAINTENANCE
}
