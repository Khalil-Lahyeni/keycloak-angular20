import { Component } from '@angular/core';
import { SettingDTO, SettingType, SettingKey } from '../models/setting.model';
import { TenantService } from '../services/tenant-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SettingService } from '../services/setting-service';
import { TenantSelectionService } from '../services/tenant-selection-service';
import { NotificationService } from '../services/notification';
import { LoadingService } from '../services/loading.service';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { AppConfigService } from '../config/app-config.service';
import { ErrorInfo } from '../services/error-handler.service';
import { HttpClient } from '@angular/common/http';

interface Setting {
  id?: string;
  key: string;
  value: string;
  type: string;
  actionName?: string | null;
  actionDone?: boolean;
  system?: boolean;
}

@Component({
  selector: 'app-settings',
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.html',
  styleUrl: './settings.scss'
})
export class Settings {
  settings: Setting[] = [];
  error = '';
  settingTypes = Object.values(SettingType);
  settingKeys = Object.values(SettingKey);

  showModal = false;
  isEditMode = false;
  editingSettingId: string | null = null;
  isKeyDropdownOpen = false;
  isTypeDropdownOpen = false;

  newSetting: SettingDTO = {
    key: SettingKey.Language,
    value: '',
    type: SettingType.Global
  };

  constructor(
    private settingService: SettingService,
    private tenantSelection: TenantSelectionService,
    private notificationService: NotificationService,
    public loadingService: LoadingService,
    private appConfigService: AppConfigService,
    private router: Router,
    private http: HttpClient
  ) { }


  ngOnInit(): void {
    this.loadSettings();
  }

  navigateToTemplates() {
    this.router.navigate(['/templates']);
  }

  loadSettings(): void {
    this.loadingService.show();
    this.error = '';

    const selected = this.tenantSelection.selectedTenant();
    // const load = (tenantId: string) => {
      this.settingService.getAllSettings(selected?.id!).subscribe({
        next: (rows: SettingDTO[]) => {
          this.settings = rows.map(s => ({
            id: s.id,
            key: s.key,
            value: s.value,
            type: s.type,
            actionName: s.actionName || null,
            actionDone: s.actionDone || false,
            system: s.system || false
          }));
          this.loadingService.hide();
        },
        error: (errorInfo: ErrorInfo) => {
          this.error = errorInfo.message;
          this.loadingService.hide();
          this.notificationService.showError(errorInfo.message);
          
          this.settings = [];
        }
      });
    // };

    // if (selected?.id) {
    //   load(selected.id);
    // } else {
    //   this.appConfigService.getKeycloakRealm().subscribe(realm => load(realm));
    // }
  }

  addSetting() {
    this.isEditMode = false;
    this.editingSettingId = null;
    this.showModal = true;
    this.resetForm();
  }

  editSetting(setting: Setting) {
    if (!setting.id) {
      this.notificationService.showError('Setting ID is missing.');
      return;
    }

    this.isEditMode = true;
    this.editingSettingId = setting.id;
    this.loadingService.show();

    this.settingService.getSetting(setting.id).subscribe({
      next: (settingDTO: SettingDTO) => {
        this.newSetting = {
          id: settingDTO.id,
          key: settingDTO.key,
          value: settingDTO.value,
          type: settingDTO.type,
          actionDone: settingDTO.actionDone,
          actionName: settingDTO.actionName,
          tenant: settingDTO.tenant
        };
        this.showModal = true;
        this.loadingService.hide();
      },
      error: (errorInfo: ErrorInfo) => {
        this.loadingService.hide();
        this.notificationService.showError(errorInfo.message || 'Failed to load setting.');
      }
    });
  }

  deleteSetting(setting: Setting) {
    if (!setting.id) {
      this.notificationService.showError('Setting ID is missing.');
      return;
    }

    if (!confirm(`Are you sure you want to delete the setting "${setting.key}"?`)) {
      return;
    }

    this.loadingService.show();

    this.settingService.deleteSetting(setting.id).subscribe({
      next: () => {
        this.loadingService.hide();
        this.notificationService.showSuccess('Setting deleted successfully!');
        this.loadSettings();
      },
      error: (errorInfo: ErrorInfo) => {
        this.loadingService.hide();
        this.notificationService.showError(errorInfo.message || 'Failed to delete setting.');
      }
    });
  }

  closeModal() {
    this.showModal = false;
    this.isEditMode = false;
    this.editingSettingId = null;
    this.isKeyDropdownOpen = false;
    this.isTypeDropdownOpen = false;
    this.resetForm();
  }

  toggleKeyDropdown() {
    this.isKeyDropdownOpen = !this.isKeyDropdownOpen;
    this.isTypeDropdownOpen = false;
  }

  toggleTypeDropdown() {
    this.isTypeDropdownOpen = !this.isTypeDropdownOpen;
    this.isKeyDropdownOpen = false;
  }

  selectKey(key: SettingKey) {
    this.newSetting.key = key;
    this.isKeyDropdownOpen = false;
  }

  selectType(type: SettingType) {
    this.newSetting.type = type;
    this.isTypeDropdownOpen = false;
  }

  resetForm() {
    this.newSetting = {
      key: SettingKey.Language,
      value: '',
      type: SettingType.Global
    };
  }

  saveSetting() {
    if (!this.newSetting.key || !this.newSetting.value || !this.newSetting.type) {
      this.notificationService.showError('Please fill in all fields.');
      return;
    }

    const tenant = this.tenantSelection.selectedTenant();
    if (!tenant || !tenant.id) {
      this.notificationService.showError('No tenant selected.');
      return;
    }

    this.loadingService.show();

    if (this.isEditMode && this.editingSettingId) {
      const payload: SettingDTO = {
        id: this.newSetting.id,
        key: this.newSetting.key,
        value: this.newSetting.value,
        type: this.newSetting.type,
        actionDone: this.newSetting.actionDone,
        actionName: this.newSetting.actionName,
        tenant: this.newSetting.tenant
      };

      this.settingService.updateSetting(this.editingSettingId, payload as SettingDTO).subscribe({
        next: (updatedSetting: SettingDTO) => {
          this.loadingService.hide();
          this.notificationService.showSuccess('Setting updated successfully!');
          this.closeModal();
          if (updatedSetting.actionName && !updatedSetting.actionDone) {
            this.authorize(updatedSetting);
          }
          
          this.loadSettings();
        },
        error: (errorInfo: ErrorInfo) => {
          this.loadingService.hide();
          this.notificationService.showError(errorInfo.message || 'Failed to update setting.');
        }
      });
    } else {
      const payload: SettingDTO = {
        key: this.newSetting.key,
        value: this.newSetting.value,
        type: this.newSetting.type,
        tenant: tenant
      };

      this.settingService.addSetting(payload).subscribe({
        next: () => {
          this.loadingService.hide();
          this.notificationService.showSuccess('Setting created successfully!');
          this.closeModal();
          this.loadSettings();
        },
        error: (errorInfo: ErrorInfo) => {
          this.loadingService.hide();
          this.notificationService.showError(errorInfo.message || 'Failed to create setting.');
        }
      });
    }
  }

  authorize(setting: SettingDTO) {
    const tenant = this.tenantSelection.selectedTenant();
    const tenantId = tenant?.id;
    
    if (!tenantId) {
      this.notificationService.showError('No tenant selected.');
      return;
    }

    this.loadingService.show();
    
    this.settingService.authorize(tenantId, setting.value)
      .subscribe({
         next: (res) => {
        this.loadingService.hide();
         window.open(res.authUrl, '_blank');
      },
        error: (error) => {
        this.loadingService.hide();
        this.notificationService.showError('Failed to authorize.');
    }
  });

  }

  canEditSetting(setting: Setting): boolean {
    return !setting.system;
  }
}