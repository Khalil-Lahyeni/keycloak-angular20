#!/bin/sh

# Environment injection script for Docker
# This script injects environment variables into the config-injector.js file

echo "Injecting environment variables..."

# Create the config-injector.js file with environment variables
cat > /usr/share/nginx/html/assets/config-injector.js << EOF
/**
 * Runtime Configuration Injector
 * This script injects environment variables into the window object
 * so they can be accessed by the Angular application at runtime.
 */

(function() {
  'use strict';
  
  // Configuration object that will be injected into the window
  window.__RUNTIME_CONFIG__ = {
    // Keycloak Configuration
    KEYCLOAK_URL: '${KEYCLOAK_URL:-http://localhost:8080}',
    KEYCLOAK_REALM: '${KEYCLOAK_REALM:-agency_01}',
    KEYCLOAK_CLIENT_ID: '${KEYCLOAK_CLIENT_ID:-convozoom-frontEnd_client_01}',
    
    // API Configuration
    API_BASE_URL: '${API_BASE_URL:-http://localhost:3000/api}',
    
    // Environment Configuration
    ENVIRONMENT: '${ENVIRONMENT:-production}',
    DEBUG_MODE: '${DEBUG_MODE:-false}'
  };
  
  console.log('Runtime configuration injected:', window.__RUNTIME_CONFIG__);
})();
EOF

echo "Environment variables injected successfully!"