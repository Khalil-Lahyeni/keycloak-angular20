import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Deal {
  id: string;
  clientName: string;
  location: string;
  status: 'new' | 'qualified' | 'proposal' | 'closed';
  value: number;
}

@Component({
  selector: 'app-my-deals-widget',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-deals-widget.html',
  styleUrl: './my-deals-widget.css'
})
export class MyDealsWidgetComponent implements OnInit {
  @Input() editMode: boolean = false;
  @Output() remove = new EventEmitter<void>();
  @Output() dealClick = new EventEmitter<Deal>();

  deals: Deal[] = [];
  isLoading: boolean = true;

  ngOnInit(): void {
    this.loadDeals();
  }

  private loadDeals(): void {
    this.isLoading = true;
    // Mock data - limited to 5 deals
    setTimeout(() => {
      this.deals = this.getMockDeals().slice(0, 5);
      this.isLoading = false;
    }, 300);
  }

  private getMockDeals(): Deal[] {
    return [
      {
        id: '1',
        clientName: 'Sophie Martin',
        location: 'Paris',
        status: 'new',
        value: 15000
      },
      {
        id: '2',
        clientName: 'Jean Dupont',
        location: 'Lyon',
        status: 'qualified',
        value: 28000
      },
      {
        id: '3',
        clientName: 'Marie Bernard',
        location: 'Marseille',
        status: 'proposal',
        value: 42000
      },
      {
        id: '4',
        clientName: 'Pierre Durand',
        location: 'Bordeaux',
        status: 'closed',
        value: 35000
      },
      {
        id: '5',
        clientName: 'Claire Petit',
        location: 'Toulouse',
        status: 'new',
        value: 18500
      }
    ];
  }

  getStatusLabel(status: string): string {
    const labels: { [key: string]: string } = {
      'new': 'New',
      'qualified': 'Qualified',
      'proposal': 'Proposal',
      'closed': 'Closed'
    };
    return labels[status] || status;
  }

  getStatusClass(status: string): string {
    return `status-badge status-${status}`;
  }

  formatValue(value: number): string {
    return value.toLocaleString('en-US');
  }

  onDealClick(deal: Deal): void {
    this.dealClick.emit(deal);
  }

  onRemove(): void {
    this.remove.emit();
  }

  onSeeAll(): void {
    // Navigate to deals page
    console.log('Navigate to deals page');
  }
}
