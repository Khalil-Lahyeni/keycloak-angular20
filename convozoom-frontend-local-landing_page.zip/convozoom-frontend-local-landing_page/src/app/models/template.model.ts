import { TenantDTO } from "./tenant.model";

export enum TemplateType {
  Text = 'Text',
  File = 'File',
}

export interface TemplateDTO {
  id?: string;
  code: string;
  name: string;
  type: TemplateType;
  version: number;
  textContent?: string;
  attachedFile?: string;
  attachedFileContentType?: string;
  tenant?: TenantDTO;
}
