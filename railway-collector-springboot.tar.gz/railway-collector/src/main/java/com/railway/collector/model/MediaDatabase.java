package com.railway.collector.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MediaDatabase {

    private String deviceIp;
    private String name;
    private List<Version> versions;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Version {
        @JsonProperty("version_id")
        private String versionId;

        @JsonProperty("version_number")
        private String versionNumber;

        @JsonProperty("is_active")
        private boolean isActive;

        @JsonProperty("activation_date")
        private String activationDate;
    }
}
