import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../config';
import { ErrorHandlerService } from './error-handler.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { LeadImportJob } from '../models/LeadImportJob.model';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LeadImportJobService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }

  getAllLeadImportJobs(): Observable<LeadImportJob[]> {
    return this.http.get<LeadImportJob[]>(`${this.base}/lead-import-jobs`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllLeadImportJobs');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving lead import jobs');
        return throwError(() => errorInfo);
      })
    );
  }


  getLeadImportJob(id: string): Observable<LeadImportJob> {
    return this.http.get<LeadImportJob>(`${this.base}/lead-import-jobs/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getLeadImportJob');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving the lead import jobs');
        return throwError(() => errorInfo);
      })
    );
  }

  createLeadImportJob(body: LeadImportJob): Observable<LeadImportJob> {
    return this.http.post<LeadImportJob>(`${this.base}/lead-import-jobs`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createLeadImportJob');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the lead import jobs');
        return throwError(() => errorInfo);
      })
    );
  }

  updateLeadImportJob(id: string, body: LeadImportJob): Observable<LeadImportJob> {
    return this.http.put<LeadImportJob>(`${this.base}/lead-import-jobs/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'updateLeadImportJob');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the lead import jobs');
        return throwError(() => errorInfo);
      })
    );
  }

  deleteLeadImportJob(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/lead-import-jobs/${id}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'deleteLeadImportJob');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error deleting the lead import jobs');
        return throwError(() => errorInfo);
      })
    );
  }

  partialUpdateLeadImportJob(id: string, body: Partial<LeadImportJob>): Observable<LeadImportJob> {
    return this.http.patch<LeadImportJob>(`${this.base}/lead-import-jobs/${id}`, body).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'partialUpdateLeadImportJob');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error updating the lead import jobs');
        return throwError(() => errorInfo);
      })
    );
  }


}
