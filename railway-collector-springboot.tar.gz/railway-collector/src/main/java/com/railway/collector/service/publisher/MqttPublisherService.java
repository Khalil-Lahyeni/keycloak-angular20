package com.railway.collector.service.publisher;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.railway.collector.config.MqttProperties;
import com.railway.collector.model.Alert;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Couche 4a — Publication MQTT.
 * Publie les données enrichies sur les topics processed/*.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MqttPublisherService {

    private final MessageChannel mqttOutboundChannel;
    private final MqttProperties mqttProperties;
    private final ObjectMapper objectMapper;

    private String prefix() {
        return mqttProperties.getProcessed().getPrefix();
    }

    // ─── Publish helpers ───

    private void publish(String topic, Object payload) {
        try {
            String json = objectMapper.writeValueAsString(payload);
            mqttOutboundChannel.send(
                    MessageBuilder.withPayload(json)
                            .setHeader(MqttHeaders.TOPIC, topic)
                            .setHeader(MqttHeaders.QOS, 1)
                            .build()
            );
            log.debug("Published to {}", topic);
        } catch (JsonProcessingException e) {
            log.error("JSON serialization error for topic {}: {}", topic, e.getMessage());
        }
    }

    // ─── Train Status ───

    public void publishStatus(String trainId, Map<String, Object> data) {
        publish(prefix() + "/trains/status/" + trainId, data);
    }

    // ─── Configuration ───

    public void publishConfiguration(String trainId, Map<String, Object> data) {
        publish(prefix() + "/trains/configuration/" + trainId, data);
    }

    // ─── Media Databases ───

    public void publishMediaDatabases(Map<String, Object> data) {
        publish(prefix() + "/trains/media_databases", data);
    }

    // ─── Messages ───

    public void publishMessage(String trainId, Map<String, Object> data) {
        publish(prefix() + "/trains/message/" + trainId, data);
    }

    // ─── Alerts ───

    public void publishAlerts(List<Alert> alerts) {
        for (Alert alert : alerts) {
            String topic = prefix() + "/trains/alerts/" + alert.getTrainId();
            publish(topic, alert);
            log.info("ALERT [{}] {} on {}: {}",
                    alert.getSeverity(), alert.getAlertType(),
                    alert.getTrainId(), alert.getMessage());
        }
    }

    // ─── Fleet Overview ───

    public void publishFleetOverview(Map<String, Object> overview) {
        publish(prefix() + "/trains/fleet/overview", overview);
    }
}
