import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

// Allows only unauthenticated users. If authenticated, redirect to /home.
export const guestGuard: CanActivateFn = async (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  try {
    const authenticated = await authService.isAuthenticated();
    if (authenticated) {
      await router.navigate(['/home']);
      return false;
    }
    return true;
  } catch (error) {
    // If any error occurs, treat as guest (allow access to landing)
    return true;
  }
};
