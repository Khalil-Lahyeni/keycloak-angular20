import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth/auth.service';
import { UserManagementService, KeycloakUser, UserCreateRequest } from './user-management.service';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  private authService = inject(AuthService);
  private userManagementService = inject(UserManagementService);

  users: KeycloakUser[] = [];
  selectedUser: KeycloakUser | null = null;
  showCreateUserForm = false;
  isTenantAdmin = false;
  isLoading = false;
  isCreating = false;
  errorMessage = '';
  successMessage = '';

  newUser: UserCreateRequest = {
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    temporaryPassword: true,
    enabled: true,
    emailVerified: false
  };

  async ngOnInit() {
    await this.checkTenantAdminRole();
    if (this.isTenantAdmin) {
      await this.loadUsers();
    }
  }

  private async checkTenantAdminRole() {
    try {
      this.isTenantAdmin = await this.authService.isTenantAdmin();
    } catch (error) {
      console.error('Error checking tenant admin role:', error);
      this.isTenantAdmin = false;
    }
  }

  async loadUsers() {
    if (!this.isTenantAdmin) {
      this.errorMessage = 'Access denied. Tenant admin role required.';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    try {
      this.users = await this.userManagementService.getUsers();
      this.successMessage = `Loaded ${this.users.length} users successfully.`;
    } catch (error) {
      console.error('Error loading users:', error);
      this.errorMessage = 'Failed to load users. Please check your permissions and try again.';
    } finally {
      this.isLoading = false;
    }
  }

  async createUser() {
    if (!this.isTenantAdmin) {
      this.errorMessage = 'Access denied. Tenant admin role required.';
      return;
    }

    this.isCreating = true;
    this.errorMessage = '';

    try {
      const userId = await this.userManagementService.createUser(this.newUser);
      this.successMessage = `User "${this.newUser.username}" created successfully.`;
      
      // Reset form
      this.newUser = {
        username: '',
        email: '',
        firstName: '',
        lastName: '',
        password: '',
        temporaryPassword: true,
        enabled: true,
        emailVerified: false
      };
      
      this.showCreateUserForm = false;
      
      // Reload users list
      await this.loadUsers();
    } catch (error: any) {
      console.error('Error creating user:', error);
      
      // Handle specific error cases
      if (error?.status === 409) {
        this.errorMessage = 'A user with this email already exists. Please use a different email address.';
      } else if (error?.error?.errorMessage) {
        this.errorMessage = `Failed to create user: ${error.error.errorMessage}`;
      } else if (error?.message) {
        this.errorMessage = `Failed to create user: ${error.message}`;
      } else {
        this.errorMessage = 'Failed to create user. Please check the information and try again.';
      }
    } finally {
      this.isCreating = false;
    }
  }

  cancelCreateUser() {
    this.showCreateUserForm = false;
    this.newUser = {
      username: '',
      email: '',
      firstName: '',
      lastName: '',
      password: '',
      temporaryPassword: true,
      enabled: true,
      emailVerified: false
    };
  }

  viewUser(user: KeycloakUser) {
    this.selectedUser = user;
  }

  closeUserDetails() {
    this.selectedUser = null;
  }

  async resetPassword(user: KeycloakUser) {
    if (!this.isTenantAdmin) {
      this.errorMessage = 'Access denied. Tenant admin role required.';
      return;
    }

    const newPassword = prompt(`Enter new password for user "${user.username}":`);
    if (!newPassword) return;

    const temporary = confirm('Should this be a temporary password? (User will be required to change it on next login)');

    try {
      await this.userManagementService.resetUserPassword(user.id!, newPassword, temporary);
      this.successMessage = `Password reset successfully for user "${user.username}".`;
    } catch (error) {
      console.error('Error resetting password:', error);
      this.errorMessage = 'Failed to reset password. Please try again.';
    }
  }

  async deleteUser(user: KeycloakUser) {
    if (!this.isTenantAdmin) {
      this.errorMessage = 'Access denied. Tenant admin role required.';
      return;
    }

    const confirmed = confirm(`Are you sure you want to delete user "${user.username}"? This action cannot be undone.`);
    if (!confirmed) return;

    try {
      await this.userManagementService.deleteUser(user.id!);
      this.successMessage = `User "${user.username}" deleted successfully.`;
      await this.loadUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
      this.errorMessage = 'Failed to delete user. Please try again.';
    }
  }

  async openKeycloakAdmin() {
    try {
      await this.userManagementService.openKeycloakAdminConsole();
    } catch (error) {
      console.error('Error opening Keycloak admin console:', error);
      this.errorMessage = 'Failed to open Keycloak admin console. Please check your permissions.';
    }
  }
}
