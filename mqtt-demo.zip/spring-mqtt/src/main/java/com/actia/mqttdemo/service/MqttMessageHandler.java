package com.actia.mqttdemo.service;

import com.actia.mqttdemo.model.SensorData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Service;

@Service
public class MqttMessageHandler {

    private static final Logger log = LoggerFactory.getLogger(MqttMessageHandler.class);

    private final ObjectMapper objectMapper;

    // Simple counters for stats
    private long messageCount = 0;
    private long errorCount = 0;

    public MqttMessageHandler() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @ServiceActivator(inputChannel = "mqttInputChannel")
    public void handleMessage(Message<?> message) {
        messageCount++;
        String topic = extractTopic(message.getHeaders());
        String payload = message.getPayload().toString();

        log.info("═══════════════════════════════════════════════");
        log.info("📨 MQTT Message Received  [#{}]", messageCount);
        log.info("📌 Topic   : {}", topic);
        log.info("📦 Raw     : {}", payload);

        try {
            SensorData data = objectMapper.readValue(payload, SensorData.class);
            processSensorData(topic, data);
        } catch (Exception e) {
            errorCount++;
            log.error("❌ Failed to parse message: {}", e.getMessage());
        }

        log.info("═══════════════════════════════════════════════\n");
    }

    private void processSensorData(String topic, SensorData data) {
        String type = data.getSensorType();

        switch (type) {
            case "temperature" -> {
                log.info("🌡️  TEMPERATURE");
                log.info("   Device    : {}", data.getDeviceId());
                log.info("   Value     : {} {}", data.getValue(), data.getUnit());
                log.info("   Timestamp : {}", data.getTimestamp());
                if (data.getValue() > 40) {
                    log.warn("🔥 ALERT: High temperature detected! ({} {})",
                            data.getValue(), data.getUnit());
                }
            }
            case "humidity" -> {
                log.info("💧 HUMIDITY");
                log.info("   Device    : {}", data.getDeviceId());
                log.info("   Value     : {} {}", data.getValue(), data.getUnit());
                log.info("   Timestamp : {}", data.getTimestamp());
                if (data.getValue() > 80) {
                    log.warn("💦 ALERT: High humidity detected! ({} {})",
                            data.getValue(), data.getUnit());
                }
            }
            case "gps" -> {
                log.info("📍 GPS LOCATION");
                log.info("   Device    : {}", data.getDeviceId());
                log.info("   Lat/Lng   : {}, {}", data.getLatitude(), data.getLongitude());
                log.info("   Timestamp : {}", data.getTimestamp());
            }
            case "status" -> {
                log.info("📊 DEVICE STATUS");
                log.info("   Device    : {}", data.getDeviceId());
                log.info("   Status    : {}", data.getStatus());
                log.info("   Timestamp : {}", data.getTimestamp());
                if ("ERROR".equals(data.getStatus())) {
                    log.error("🚨 ALERT: Device {} reported ERROR status!", data.getDeviceId());
                }
            }
            default -> {
                log.info("📝 UNKNOWN SENSOR TYPE: {}", type);
                log.info("   Payload: {}", data);
            }
        }

        // Stats every 10 messages
        if (messageCount % 10 == 0) {
            log.info("📈 Stats: {} messages received, {} errors", messageCount, errorCount);
        }
    }

    private String extractTopic(MessageHeaders headers) {
        Object topic = headers.get("mqtt_receivedTopic");
        return topic != null ? topic.toString() : "unknown";
    }
}
