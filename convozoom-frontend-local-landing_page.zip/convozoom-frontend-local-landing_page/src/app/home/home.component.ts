import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { CommonModule, AsyncPipe } from '@angular/common';
import { BehaviorSubject } from 'rxjs';
import { DragDropModule, CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { TotalLeadsWidgetComponent } from './widgets/total-leads-widget/total-leads-widget';
import { MyLeadsWidgetComponent } from './widgets/my-leads-widget/my-leads-widget';
import { DemographyWidgetComponent } from './widgets/demography-widget/demography-widget';
import { PipelineWidgetComponent } from './widgets/pipeline-widget/pipeline-widget';
import { MeetingWidgetComponent } from './widgets/meeting-widget/meeting-widget';
import { MyDealsWidgetComponent } from './widgets/my-deals-widget/my-deals-widget';

interface Widget {
  id: string;
  type: 'total-leads' | 'my-leads' | 'my-deals' | 'meetings' | 'demography' | 'pipeline';
  visible: boolean;
  column: 1 | 2 | 3;
}

type WidgetType = Widget['type'];

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    AsyncPipe,
    DragDropModule,
    TotalLeadsWidgetComponent,
    MyLeadsWidgetComponent,
    DemographyWidgetComponent,
    PipelineWidgetComponent,
    MeetingWidgetComponent,
    MyDealsWidgetComponent
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  private authService = inject(AuthService);
  private router = inject(Router);
  isAuthenticated = false;
  isLoading$ = new BehaviorSubject<boolean>(true);
  isSalesManager = false;
  isSuperAdmin = false;
  userName = 'User name';
  
  // Dashboard edit mode
  editMode = false;
  availableWidgets: Widget[] = [];
  
  // Widgets organized by column
  column1: Widget[] = [];
  column2: Widget[] = [];
  column3: Widget[] = [];

  // Get all widgets for compatibility
  get allWidgets(): Widget[] {
    return [...this.column1, ...this.column2, ...this.column3];
  }

  async ngOnInit(): Promise<void> {
    await this.checkAuthStatus();
    await this.loadUserName();
    this.loadWidgets();
    this.isLoading$.next(false);
    console.log('HomeComponent - isAuthenticated:', this.isAuthenticated, 'userName:', this.userName);
  }

  private async checkAuthStatus() {
    try {
      this.isAuthenticated = await this.authService.isAuthenticated();
      console.log('HomeComponent - checkAuthStatus result:', this.isAuthenticated);
      if (this.isAuthenticated) {
        this.isSalesManager = await this.authService.isSalesManager();
        this.isSuperAdmin = await this.authService.isSuperAdmin();
      }
    } catch (error) {
      console.error('Error checking auth status:', error);
      this.isAuthenticated = false;
      this.isSalesManager = false;
      this.isSuperAdmin = false;
    }
  }

  private async loadUserName(): Promise<void> {
    try {
      const profile = await this.authService.getUserProfile();
      if (profile?.firstName) {
        this.userName = profile.firstName;
      }
    } catch (err) {
      console.error('Error loading user profile:', err);
    }
  }

  private loadWidgets(): void {
    // Widget types that should be hidden for superadmin
    const hiddenTypesForSuperAdmin: Widget['type'][] = ['total-leads', 'my-leads', 'my-deals'];

    // Clear localStorage for superadmin to enforce filtering
    if (this.isSuperAdmin) {
      localStorage.removeItem('dashboard-widgets');
    }

    // Load from localStorage or use defaults
    const saved = localStorage.getItem('dashboard-widgets');
    if (saved) {
      const parsed = JSON.parse(saved);
      this.column1 = parsed.column1 || [];
      this.column2 = parsed.column2 || [];
      this.column3 = parsed.column3 || [];
      this.availableWidgets = parsed.availableWidgets || [];
      
      // Migration: if old format (widgets array), convert to new format
      if (parsed.widgets && !parsed.column1) {
        const widgets = parsed.widgets as Widget[];
        this.column1 = [];
        this.column2 = [];
        this.column3 = [];
        widgets.forEach((w, i) => {
          w.column = ((i % 3) + 1) as 1 | 2 | 3;
          if (w.column === 1) this.column1.push(w);
          else if (w.column === 2) this.column2.push(w);
          else this.column3.push(w);
        });
      }
    } else {
      // Default widgets - different for superadmin vs regular users
      if (this.isSuperAdmin) {
        this.column1 = [
          { id: 'meetings', type: 'meetings', visible: true, column: 1 }
        ];
        this.column2 = [
          { id: 'demography', type: 'demography', visible: true, column: 2 }
        ];
        this.column3 = [];
        this.availableWidgets = [
          { id: 'pipeline', type: 'pipeline', visible: false, column: 1 }
        ];
      } else {
        this.column1 = [
          { id: 'meetings', type: 'meetings', visible: true, column: 1 }
        ];
        this.column2 = [
          { id: 'my-deals', type: 'my-deals', visible: true, column: 2 },
          { id: 'my-leads', type: 'my-leads', visible: true, column: 2 }
        ];
        this.column3 = [
          { id: 'demography', type: 'demography', visible: true, column: 3 },
          { id: 'total-leads', type: 'total-leads', visible: true, column: 3 },
          { id: 'pipeline', type: 'pipeline', visible: true, column: 3 }
        ];
        this.availableWidgets = [];
      }
    }

    // Filter out lead/deal widgets for superadmin (in case they were loaded from localStorage)
    if (this.isSuperAdmin) {
      this.column1 = this.column1.filter(w => !hiddenTypesForSuperAdmin.includes(w.type));
      this.column2 = this.column2.filter(w => !hiddenTypesForSuperAdmin.includes(w.type));
      this.column3 = this.column3.filter(w => !hiddenTypesForSuperAdmin.includes(w.type));
      this.availableWidgets = this.availableWidgets.filter(w => !hiddenTypesForSuperAdmin.includes(w.type));
    }
  }

  private saveWidgets(): void {
    localStorage.setItem('dashboard-widgets', JSON.stringify({
      column1: this.column1,
      column2: this.column2,
      column3: this.column3,
      availableWidgets: this.availableWidgets
    }));
  }

  // Edit mode methods
  toggleEditMode(): void {
    this.editMode = !this.editMode;
  }

  onDrop(event: CdkDragDrop<Widget[]>): void {
    if (event.previousContainer === event.container) {
      // Reorder within the same column
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      // Transfer between columns
      const widget = event.previousContainer.data[event.previousIndex];
      // Update widget's column based on target container
      if (event.container.data === this.column1) widget.column = 1;
      else if (event.container.data === this.column2) widget.column = 2;
      else if (event.container.data === this.column3) widget.column = 3;
      
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
    this.saveWidgets();
  }

  removeWidget(widgetId: string): void {
    // Find and remove from whichever column it's in
    let widget: Widget | undefined;
    
    const idx1 = this.column1.findIndex(w => w.id === widgetId);
    if (idx1 !== -1) {
      widget = this.column1.splice(idx1, 1)[0];
    }
    
    const idx2 = this.column2.findIndex(w => w.id === widgetId);
    if (idx2 !== -1) {
      widget = this.column2.splice(idx2, 1)[0];
    }
    
    const idx3 = this.column3.findIndex(w => w.id === widgetId);
    if (idx3 !== -1) {
      widget = this.column3.splice(idx3, 1)[0];
    }
    
    if (widget) {
      widget.visible = false;
      this.availableWidgets.push(widget);
      this.saveWidgets();
    }
  }

  addWidget(widget: Widget): void {
    widget.visible = true;
    // Add to the column with fewest widgets
    const counts = [this.column1.length, this.column2.length, this.column3.length];
    const minCount = Math.min(...counts);
    if (counts[0] === minCount) {
      widget.column = 1;
      this.column1.push(widget);
    } else if (counts[1] === minCount) {
      widget.column = 2;
      this.column2.push(widget);
    } else {
      widget.column = 3;
      this.column3.push(widget);
    }
    this.availableWidgets = this.availableWidgets.filter(w => w.id !== widget.id);
    this.saveWidgets();
  }

  getWidgetLabel(type: string): string {
    const labels: { [key: string]: string } = {
      'total-leads': 'Total Leads',
      'my-leads': 'My Leads',
      'my-deals': 'My Deals',
      'meetings': 'Meetings',
      'demography': 'Demography',
      'pipeline': 'Pipeline Value'
    };
    return labels[type] || type;
  }

  doneEditing(): void {
    this.saveWidgets();
    this.editMode = false;
  }

  trackByWidgetId(index: number, widget: Widget): string {
    return widget.id;
  }

  hasAnyWidgets(): boolean {
    return this.column1.length > 0 || this.column2.length > 0 || this.column3.length > 0;
  }

  isMeetingAloneInColumn(columnWidgets: Widget[]): boolean {
    return columnWidgets.length === 1 && columnWidgets[0].type === 'meetings';
  }

  onLeadClick(leadId: string): void {
    console.log('Lead clicked:', leadId);
    // Navigate to lead detail or open modal
  }
}
