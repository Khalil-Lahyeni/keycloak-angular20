import { PlanDTO } from "./plan.model";
import { TenantDTO } from "./tenant.model";


export interface PlanItemDTO {
  id?: string;
  startDate: string;
  endDate: string;
  finalPrice: number;
  enable: boolean;
  plan: PlanDTO;
  tenant: TenantDTO;
}