#!/usr/bin/env node

/**
 * Configuration Injection Script
 * This script reads environment variables and injects them into the config-injector.js file
 * 
 * Usage: node inject-config.js [config-file] [output-file]
 */

const fs = require('fs');
const path = require('path');

// Default values
const configFile = process.argv[2] || 'src/assets/config-injector.js';
const outputFile = process.argv[3] || 'dist/convozoom-front/assets/config-injector.js';

// Environment variables to inject
const envVars = {
  KEYCLOAK_URL: process.env.KEYCLOAK_URL || 'http://localhost:8080',
  KEYCLOAK_REALM: process.env.KEYCLOAK_REALM || 'agency_01',
  KEYCLOAK_CLIENT_ID: process.env.KEYCLOAK_CLIENT_ID || 'convozoom-frontEnd_client_01',
  API_BASE_URL: process.env.API_BASE_URL || 'http://localhost:3000/api',
  ENVIRONMENT: process.env.ENVIRONMENT || 'production',
  DEBUG_MODE: process.env.DEBUG_MODE || 'false'
};

function injectConfig() {
  try {
    // Read the template file
    const template = fs.readFileSync(configFile, 'utf8');
    
    // Replace placeholders with environment variables
    let injected = template;
    Object.entries(envVars).forEach(([key, value]) => {
      const placeholder = `{{${key}}}`;
      injected = injected.replace(new RegExp(placeholder, 'g'), value);
    });
    
    // Ensure output directory exists
    const outputDir = path.dirname(outputFile);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    // Write the injected configuration
    fs.writeFileSync(outputFile, injected, 'utf8');
    
    console.log('Configuration injected successfully!');
    console.log('Output file:', outputFile);
    console.log('Injected values:', envVars);
    
  } catch (error) {
    console.error('Error injecting configuration:', error.message);
    process.exit(1);
  }
}

// Run the injection
injectConfig();
