import { Injectable } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { Breadcrumb } from '../models/breadCrumb.model';

@Injectable({
  providedIn: 'root'
})
export class BreadcrumbService {

  breadcrumbs: Breadcrumb[] = [];

  constructor(private router: Router, private route: ActivatedRoute) {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.breadcrumbs = this.buildBreadcrumbs(this.route.root);
      });
  }

  private buildBreadcrumbs(
    route: ActivatedRoute,
    url: string = '',
    breadcrumbs: Breadcrumb[] = []
  ): Breadcrumb[] {

    const label = route.snapshot.data['breadcrumb'];
    const path = route.snapshot.routeConfig?.path;

    if (path && label) {
      url += `/${path}`;
      breadcrumbs.push({ label, url });
    }

    route.children.forEach(child => {
      this.buildBreadcrumbs(child, url, breadcrumbs);
    });

    return breadcrumbs;
  }
}
