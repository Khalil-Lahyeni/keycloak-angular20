import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnInit, OnChanges, SimpleChanges, HostListener } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Deal, DealStage } from '../models/deal.model';
import { DealService } from '../services/deal-service';

@Component({
  selector: 'app-deal-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './deal-list.html',
  styleUrls: ['./deal-list.css']
})
export class DealList implements OnInit, OnChanges {
  @Input() groupedDeals: { key: string, items: Deal[] }[] = [];
  @Input() deals: Deal[] = [];
  @Output() openDeal = new EventEmitter<string>();

  protected readonly DealStage = DealStage;

  // Toolbar state
  @Input() sortBy: 'Updated' | 'Created' | 'Name' | 'Stage' = 'Updated';
  @Input() groupBy: 'Stage' | 'Priority' | 'Source'  | null = null;

  // Track which groups are expanded
  expandedGroups = new Set<string>();

  constructor(
    private dealService: DealService,

  ) { }


ngOnInit() {
  this.expandAllGroups();
}

ngOnChanges(changes: SimpleChanges) {
  if (changes['groupedDeals'] || changes['groupBy']) {
    this.expandAllGroups();
  }
}

private expandAllGroups() {
  this.expandedGroups.clear();
  this.grouped.forEach(g => this.expandedGroups.add(g.key));
}



  trackById(_idx: number, item: Deal) {
    return item.id || _idx;
  }

  onRowClick(deal?: Deal) {
    if (deal?.id) {
      this.openDeal.emit(deal.id);
    }
  }

  getRelativeDate(dateString: string): { time: string; date: string } {
    if (!dateString) return { time: '—', date: '' };
    const date = new Date(dateString);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const dealDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    const time = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

    let dateLabel: string;
    if (dealDate.getTime() === today.getTime()) {
      dateLabel = 'today';
    } else if (dealDate.getTime() === yesterday.getTime()) {
      dateLabel = 'yesterday';
    } else {
      dateLabel = date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    return { time, date: dateLabel };
  }

  getStageClass(stage?: DealStage | string): string {
    if (!stage) return '';
    const stageStr = typeof stage === 'string' ? stage : stage;
    switch (stageStr) {
      case DealStage.PROSPECTING:
      case 'Prospecting':
        return 'pf-m-blue';
      case DealStage.NEGOTIATION:
      case 'Negotiation':
        return 'pf-m-orange';
      case DealStage.CLOSED_WON:
      case 'ClosedWon':
        return 'pf-m-green';
      default:
        return '';
    }
  }

  toggleGroup(key: string) {
    if (this.expandedGroups.has(key)) {
      this.expandedGroups.delete(key);
    } else {
      this.expandedGroups.add(key);
    }
  }



  getStageLabel(stage?: DealStage): string {
    switch (stage) {
      case DealStage.PROSPECTING: return 'Prospecting';
      case DealStage.NEGOTIATION: return 'Negotiation';
      case DealStage.CLOSED_WON: return 'Closed Won';
      default: return 'Unknown';
    }
  }

  // Utilisez simplement les données fournies
  get sorted(): Deal[] {
    return this.deals;
  }

  // Utilisez groupedDeals si fourni, sinon calculez localement
  get grouped(): Array<{ key: string; items: Deal[] }> {
    if (this.groupedDeals && this.groupedDeals.length > 0) {
      return this.groupedDeals;
    }
    
    if (!this.groupBy) return [];
    
    const list = this.deals;
    const map = new Map<string, Deal[]>();
    
    for (const deal of list) {
      let key: string;
      
      switch (this.groupBy) {
        case 'Stage':
          key = this.getStageLabel(deal.stage);
          break;
        case 'Priority':
          key = deal.lead?.priority || 'No priority';
          break;
        case 'Source':
          key = deal.lead?.source || 'Unknown';
          break;
        default:
          key = 'Unknown';
      }
      
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(deal);
    }

    let groups = Array.from(map.entries()).map(([key, items]) => ({ key, items }));
    
    // Trier les groupes selon le type
    if (this.groupBy === 'Stage') {
      const order = ['Prospecting', 'Negotiation', 'Closed Won'];
      groups.sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key));
    } else {
      groups.sort((a, b) => a.key.localeCompare(b.key));
    }

    return groups;
  }

  formatCurrency(amount?: number, currency?: string): string {
    if (amount === undefined || amount === null) return '—';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  }

  formatDate(dateString?: string): string {
    if (!dateString) return '—';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  // Méthode pour vérifier s'il y a des résultats
  get hasResults(): boolean {
    if (this.groupBy) {
      return this.grouped.some(g => g.items.length > 0);
    }
    return this.sorted.length > 0;
  }


  // Loading state
  isLoading = false;


  searchQuery = '';
  isSearchOpen = false;
  isSortOpen = false;
  isGroupOpen = false;

  // Selection state
  selectedDeals = new Set<string>();



  // Check if all deals are selected
  get isAllSelected(): boolean {
    const allDeals = this.sorted;
    return allDeals.length > 0 && allDeals.every(d => d.id && this.selectedDeals.has(d.id));
  }

  // Check if some deals are selected (for indeterminate state)
  get isSomeSelected(): boolean {
    const allDeals = this.sorted;
    const selectedCount = allDeals.filter(d => d.id && this.selectedDeals.has(d.id)).length;
    return selectedCount > 0 && selectedCount < allDeals.length;
  }

  // Toggle all deals selection
  toggleSelectAll() {
    if (this.isAllSelected) {
      this.selectedDeals.clear();
    } else {
      this.sorted.forEach(d => {
        if (d.id) this.selectedDeals.add(d.id);
      });
    }
  }

  // Toggle single deal selection
  toggleDealSelection(deal: Deal, event: Event) {
    event.stopPropagation();
    if (deal.id) {
      if (this.selectedDeals.has(deal.id)) {
        this.selectedDeals.delete(deal.id);
      } else {
        this.selectedDeals.add(deal.id);
      }
    }
  }

  // Check if a deal is selected
  isDealSelected(deal: Deal): boolean {
    return deal.id ? this.selectedDeals.has(deal.id) : false;
  }

  // Getter to use searchQuery instead of query input
  get query(): string {
    return this.searchQuery;
  }

  get filtered(): Deal[] {
    const q = (this.query || '').toLowerCase().trim();
    if (!q) return this.deals;
    return this.deals.filter(d =>
      (d.title || '').toLowerCase().includes(q) ||
      (d.lead?.fullName || '').toLowerCase().includes(q) ||
      (d.lead?.company || '').toLowerCase().includes(q) ||
      (d.assignedTo || '').toLowerCase().includes(q) ||
      (d.stage || '').toLowerCase().includes(q)
    );
  }

  loadDeals() {
    this.isLoading = true;
    this.dealService.getAllDeals().subscribe({
      next: (deals) => {
        this.deals = deals;
        this.isLoading = false;
        if (this.groupBy) {
          this.grouped.forEach(g => this.expandedGroups.add(g.key));
        }
      },
      error: (err) => {
        console.error('Error loading deals:', err);
        this.isLoading = false;
      }
    });
  }

  private toDate(val?: string): number {
    try { return val ? new Date(val).getTime() : 0; } catch { return 0; }
  }

  private stageOrder(stage?: DealStage): number {
    if (!stage) return Number.MAX_SAFE_INTEGER;
    const order = [DealStage.PROSPECTING, DealStage.NEGOTIATION, DealStage.CLOSED_WON];
    const idx = order.indexOf(stage);
    return idx === -1 ? Number.MAX_SAFE_INTEGER : idx;
  }


  // Toolbar methods
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.toolbar-dropdown') && !target.closest('.search-wrapper')) {
      this.isSortOpen = false;
      this.isGroupOpen = false;
      if (this.isSearchOpen && !this.searchQuery) {
        this.isSearchOpen = false;
      }
    }
  }

  toggleSort(event: Event) {
    event.stopPropagation();
    this.isSortOpen = !this.isSortOpen;
    this.isGroupOpen = false;
  }

  toggleGroupDropdown(event: Event) {
    event.stopPropagation();
    this.isGroupOpen = !this.isGroupOpen;
    this.isSortOpen = false;
  }

  selectSort(sort: 'Updated' | 'Created' | 'Name' | 'Stage') {
    this.sortBy = sort;
    this.isSortOpen = false;
  }



  exportDeals() {
    const data = this.sorted;
    const csvContent = this.convertToCSV(data);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `deals_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  isGroupExpanded(key: string): boolean {
    return this.expandedGroups.has(key);
  }

  private convertToCSV(deals: Deal[]): string {
    const headers = ['Title', 'Lead', 'Amount', 'Currency', 'Stage', 'Assignee', 'Expected Close', 'Created'];
    const rows = deals.map(d => [
      d.title || '',
      d.lead?.fullName || '',
      d.amount?.toString() || '',
      d.currency || '',
      d.stage || '',
      d.assignedTo || 'Unassigned',
      d.expectedCloseDate || '',
      d.createdAt || ''
    ]);
    return [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
  }
}
