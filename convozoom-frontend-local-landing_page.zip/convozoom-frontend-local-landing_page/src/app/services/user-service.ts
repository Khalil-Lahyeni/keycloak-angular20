import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { UserDTO } from '../models/user.model';
import { AppConfigService } from '../config/app-config.service';
import { ErrorHandlerService } from './error-handler.service';

@Injectable({ providedIn: 'root' })
export class UserService {
  appConfigService = inject(AppConfigService);
  private base: string | undefined;

  constructor(private http: HttpClient, private errorHandler: ErrorHandlerService) {
    this.appConfigService.getApiBaseUrl().subscribe(url => {
      this.base = url;
    });
  }


  getAllUsers(): Observable<UserDTO[]> {
    return this.http.get<UserDTO[]>(`${this.base}/users`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getAllUsers');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving users');
        return throwError(() => errorInfo);
      })
    );
  }

  getUsersByTenant(tenantId: string): Observable<UserDTO[]> {
    return this.http.get<UserDTO[]>(`${this.base}/users/tenant/${tenantId}`).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'getUsersByTenant');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error retrieving users by tenant');
        return throwError(() => errorInfo);
      })
    );
  }

  createUser(user: UserDTO): Observable<UserDTO> {
    return this.http.post<UserDTO>(`${this.base}/users`, user).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'createUser');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error creating the user');
        return throwError(() => errorInfo);
      })
    );
  }


  addUser(user: UserDTO): Observable<UserDTO> {
    return this.http.post<UserDTO>(`${this.base}/users/create`, user).pipe(
      catchError((err: HttpErrorResponse) => {
        this.errorHandler.logError(err, 'addUser');
        const errorInfo = this.errorHandler.extractErrorMessage(err, 'Error adding the user');
        return throwError(() => errorInfo);
      })
    );
  }
}
