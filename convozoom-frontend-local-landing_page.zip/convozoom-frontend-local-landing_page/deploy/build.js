#!/usr/bin/env node

/**
 * Production Build Script
 * This script builds the Angular application and injects environment variables
 * Usage: node deploy/build.js
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Load environment variables from .env file
function loadEnvFile() {
  const envPath = path.join(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const envContent = fs.readFileSync(envPath, 'utf8');
    const envVars = {};
    
    envContent.split('\n').forEach(line => {
      const trimmedLine = line.trim();
      if (trimmedLine && !trimmedLine.startsWith('#')) {
        const [key, ...valueParts] = trimmedLine.split('=');
        if (key && valueParts.length > 0) {
          envVars[key.trim()] = valueParts.join('=').trim();
        }
      }
    });
    
    // Set environment variables
    Object.entries(envVars).forEach(([key, value]) => {
      process.env[key] = value;
    });
    
    console.log('Environment variables loaded from .env file');
    return envVars;
  }
  
  console.log('No .env file found, using system environment variables');
  return {};
}

// Inject configuration into the built application
function injectConfig() {
  const configFile = 'src/assets/config-injector.js';
  const outputFile = 'dist/convozoom-front/assets/config-injector.js';
  
  if (!fs.existsSync(configFile)) {
    console.error('Config template file not found:', configFile);
    process.exit(1);
  }
  
  // Environment variables to inject
  const envVars = {
    KEYCLOAK_URL: process.env.KEYCLOAK_URL || 'http://localhost:8080',
    KEYCLOAK_REALM: process.env.KEYCLOAK_REALM || 'agency_01',
    KEYCLOAK_CLIENT_ID: process.env.KEYCLOAK_CLIENT_ID || 'convozoom-frontEnd_client_01',
    API_BASE_URL: process.env.API_BASE_URL || 'http://localhost:3000/api',
    ENVIRONMENT: process.env.ENVIRONMENT || 'production',
    DEBUG_MODE: process.env.DEBUG_MODE || 'false'
  };
  
  try {
    // Read the template file
    const template = fs.readFileSync(configFile, 'utf8');
    
    // Replace placeholders with environment variables
    let injected = template;
    Object.entries(envVars).forEach(([key, value]) => {
      const placeholder = `{{${key}}}`;
      injected = injected.replace(new RegExp(placeholder, 'g'), value);
    });
    
    // Ensure output directory exists
    const outputDir = path.dirname(outputFile);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    // Write the injected configuration
    fs.writeFileSync(outputFile, injected, 'utf8');
    
    console.log('Configuration injected successfully!');
    console.log('Output file:', outputFile);
    console.log('Injected values:', envVars);
    
  } catch (error) {
    console.error('Error injecting configuration:', error.message);
    process.exit(1);
  }
}

// Main build process
function build() {
  try {
    console.log('Starting production build...');
    
    // Load environment variables
    const envVars = loadEnvFile();
    
    // Build the Angular application
    console.log('Building Angular application...');
    execSync('ng build --configuration production', { stdio: 'inherit' });
    
    // Inject configuration
    console.log('Injecting configuration...');
    injectConfig();
    
    console.log('Build completed successfully!');
    console.log('Output directory: dist/convozoom-front');
    
  } catch (error) {
    console.error('Build failed:', error.message);
    process.exit(1);
  }
}

// Run the build
build();
