package com.railway.collector.service.rules;

import com.railway.collector.config.RulesProperties;
import com.railway.collector.model.Alert;
import com.railway.collector.model.Alert.Severity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Couche 3 — Moteur de Règles Métier.
 * Applique les règles ferroviaires et génère les alertes.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RulesEngineService {

    private final RulesProperties rulesProperties;

    // Cache d'état des trains pour les règles temporelles
    private final Map<String, TrainState> trainStateCache = new ConcurrentHashMap<>();

    // ─── État interne d'un train ───
    private static class TrainState {
        String lastSeen;
        int consecutiveErrors = 0;
        Map<String, String> previousStatuses = new HashMap<>();
    }

    private TrainState getOrCreateState(String trainId) {
        return trainStateCache.computeIfAbsent(trainId, k -> new TrainState());
    }

    // ═══════════════════════════════════════════════
    // Règles pour train/status
    // ═══════════════════════════════════════════════

    public List<Alert> applyStatusRules(String trainId, Map<String, Object> data) {
        List<Alert> alerts = new ArrayList<>();

        alerts.addAll(checkHeartbeat(trainId, data));
        alerts.addAll(checkSystemStatuses(trainId, data));

        return alerts;
    }

    /**
     * Règle 1: Heartbeat — lastSeen trop ancien.
     */
    private List<Alert> checkHeartbeat(String trainId, Map<String, Object> data) {
        String lastSeenStr = (String) data.get("lastSeen");
        if (lastSeenStr == null) return List.of();

        TrainState state = getOrCreateState(trainId);
        state.lastSeen = lastSeenStr;

        try {
            Instant lastSeen = Instant.parse(lastSeenStr);
            long deltaSeconds = Duration.between(lastSeen, Instant.now()).getSeconds();

            if (deltaSeconds > rulesProperties.getHeartbeatTimeoutSeconds()) {
                return List.of(Alert.builder()
                        .alertType("HEARTBEAT_LOST")
                        .severity(Severity.WARNING)
                        .trainId(trainId)
                        .message(String.format(
                                "Train %s not seen for %ds (threshold: %ds)",
                                trainId, deltaSeconds,
                                rulesProperties.getHeartbeatTimeoutSeconds()))
                        .details(String.format(
                                "{\"lastSeen\":\"%s\",\"deltaSeconds\":%d}",
                                lastSeenStr, deltaSeconds))
                        .build());
            }
        } catch (Exception e) {
            log.warn("Cannot parse lastSeen for heartbeat check: {}", lastSeenStr);
        }
        return List.of();
    }

    /**
     * Règle 2: Statuts systèmes — PACIS, CCTV, RearView.
     */
    private List<Alert> checkSystemStatuses(String trainId, Map<String, Object> data) {
        List<Alert> alerts = new ArrayList<>();
        TrainState state = getOrCreateState(trainId);

        Map<String, SystemRule> systemRules = Map.of(
                "pacisStatus", new SystemRule("PACIS_FAILURE", "PACIS system", Severity.CRITICAL),
                "cctvStatus", new SystemRule("CCTV_DEGRADED", "CCTV system", Severity.WARNING),
                "rearViewStatus", new SystemRule("REARVIEW_FAILURE", "Rear view system", Severity.CRITICAL)
        );

        for (var entry : systemRules.entrySet()) {
            String field = entry.getKey();
            SystemRule rule = entry.getValue();
            String status = (String) data.getOrDefault(field, "unknown");
            String previousStatus = state.previousStatuses.get(field);

            if (rulesProperties.getCriticalStatuses().contains(status)) {
                Severity severity = rule.defaultSeverity;

                // Escalade si erreurs consécutives
                if (previousStatus != null
                        && rulesProperties.getCriticalStatuses().contains(previousStatus)) {
                    state.consecutiveErrors++;
                    if (state.consecutiveErrors >= 3) {
                        severity = Severity.EMERGENCY;
                    }
                }

                alerts.add(Alert.builder()
                        .alertType(rule.alertType)
                        .severity(severity)
                        .trainId(trainId)
                        .message(String.format(
                                "%s is '%s' on train %s",
                                rule.systemName, status, trainId))
                        .details(String.format(
                                "{\"field\":\"%s\",\"status\":\"%s\",\"consecutiveErrors\":%d}",
                                field, status, state.consecutiveErrors))
                        .build());
            } else {
                // Reset si le système revient à la normale
                if (previousStatus != null
                        && rulesProperties.getCriticalStatuses().contains(previousStatus)) {
                    state.consecutiveErrors = 0;
                }
            }
            state.previousStatuses.put(field, status);
        }
        return alerts;
    }

    // ═══════════════════════════════════════════════
    // Règles pour train/configuration
    // ═══════════════════════════════════════════════

    public List<Alert> applyConfigRules(String trainId, Map<String, Object> data) {
        List<Alert> alerts = new ArrayList<>();

        if (!Boolean.TRUE.equals(data.get("visible"))) {
            alerts.add(Alert.builder()
                    .alertType("TRAIN_HIDDEN")
                    .severity(Severity.INFO)
                    .trainId(trainId)
                    .message(String.format("Train %s is set to invisible", trainId))
                    .details("{\"visible\":false}")
                    .build());
        }

        if (data.get("ccu1Ip") == null) {
            alerts.add(Alert.builder()
                    .alertType("INVALID_CCU_IP")
                    .severity(Severity.WARNING)
                    .trainId(trainId)
                    .message(String.format("Train %s has invalid CCU1 IP", trainId))
                    .build());
        }

        if (data.get("ccu2Ip") == null) {
            alerts.add(Alert.builder()
                    .alertType("INVALID_CCU_IP")
                    .severity(Severity.WARNING)
                    .trainId(trainId)
                    .message(String.format("Train %s has invalid CCU2 IP", trainId))
                    .build());
        }

        return alerts;
    }

    // ═══════════════════════════════════════════════
    // Règles pour media_databases
    // ═══════════════════════════════════════════════

    @SuppressWarnings("unchecked")
    public List<Alert> applyMediaDbRules(Map<String, Object> data) {
        List<Alert> alerts = new ArrayList<>();
        String dbName = (String) data.getOrDefault("name", "unknown");
        List<Map<String, Object>> versions =
                (List<Map<String, Object>>) data.getOrDefault("versions", List.of());

        long activeCount = versions.stream()
                .filter(v -> Boolean.TRUE.equals(v.get("is_active")))
                .count();

        if (activeCount == 0) {
            alerts.add(Alert.builder()
                    .alertType("NO_ACTIVE_DB_VERSION")
                    .severity(Severity.WARNING)
                    .trainId("FLEET")
                    .message(String.format(
                            "Media database '%s' has no active version", dbName))
                    .details(String.format(
                            "{\"database\":\"%s\",\"totalVersions\":%d}",
                            dbName, versions.size()))
                    .build());
        }

        if (activeCount > 1) {
            alerts.add(Alert.builder()
                    .alertType("MULTIPLE_ACTIVE_VERSIONS")
                    .severity(Severity.WARNING)
                    .trainId("FLEET")
                    .message(String.format(
                            "Media database '%s' has %d active versions",
                            dbName, activeCount))
                    .build());
        }

        return alerts;
    }

    // ═══════════════════════════════════════════════
    // Health Score
    // ═══════════════════════════════════════════════

    public int computeHealthScore(String trainId, Map<String, Object> data) {
        int score = 100;

        score -= statusPenalty((String) data.get("pacisStatus"),
                Map.of("ok", 0, "degraded", 15, "error", 40, "unknown", 10));
        score -= statusPenalty((String) data.get("cctvStatus"),
                Map.of("ok", 0, "partially_ok", 10, "nok", 30, "unknown", 10));
        score -= statusPenalty((String) data.get("rearViewStatus"),
                Map.of("ok", 0, "nok", 35, "unknown", 10));

        TrainState state = getOrCreateState(trainId);
        score -= Math.min(state.consecutiveErrors * 5, 25);

        return Math.max(0, Math.min(100, score));
    }

    private int statusPenalty(String status, Map<String, Integer> penalties) {
        if (status == null) return 10;
        return penalties.getOrDefault(status, 10);
    }

    // ─── Helper ───
    private record SystemRule(String alertType, String systemName, Severity defaultSeverity) {}
}
