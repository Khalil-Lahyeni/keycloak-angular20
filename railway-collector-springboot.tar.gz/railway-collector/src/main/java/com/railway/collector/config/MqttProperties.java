package com.railway.collector.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "mqtt")
public class MqttProperties {

    private Broker broker = new Broker();
    private Client client = new Client();
    private Topics topics = new Topics();
    private Processed processed = new Processed();

    @Data
    public static class Broker {
        private String url = "tcp://localhost:1883";
        private String username = "";
        private String password = "";
    }

    @Data
    public static class Client {
        private String id = "railway-collector";
    }

    @Data
    public static class Topics {
        private List<String> raw = List.of(
                "trains/status/+",
                "trains/configuration/+",
                "trains/media_databases",
                "trains/message/+"
        );
    }

    @Data
    public static class Processed {
        private String prefix = "processed";
    }
}
