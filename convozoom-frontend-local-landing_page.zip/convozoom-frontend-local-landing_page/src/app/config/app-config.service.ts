import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, shareReplay, map } from 'rxjs/operators';
import { AppConfig, EnvConfig } from './app.config.interface';

@Injectable({
  providedIn: 'root'
})
export class AppConfigService {
  private config$: Observable<AppConfig>;
  private config: AppConfig | null = null;

  constructor(private http: HttpClient) {
    this.config$ = this.loadConfig().pipe(
      shareReplay(1)
    );
  }

  private loadConfig(): Observable<AppConfig> {
    // First try to load from environment variables
    const envConfig = this.loadFromEnvironment();
    if (envConfig) {
      console.log('Configuration loaded from environment variables');
      return of(envConfig);
    }

    // Fallback to config.json
    return this.http.get<AppConfig>('/assets/config.json').pipe(
      catchError((error) => {
        console.error('Failed to load config.json, using fallback configuration:', error);
        // Return a fallback configuration if config.json fails to load
        return of(this.getFallbackConfig());
      })
    );
  }

  private loadFromEnvironment(): AppConfig | null {
    try {
      // Check multiple sources for environment variables
      const env = (window as any).__ENV__ || 
                  (window as any).env || 
                  (window as any).ENV || {};
      
      // Check for runtime-injected configuration
      const runtimeConfig = (window as any).__RUNTIME_CONFIG__ || {};
      
      // Also check for environment variables that might be injected by the deployment script
      const keycloakUrl = runtimeConfig.KEYCLOAK_URL || 
                          env.KEYCLOAK_URL || 
                          (window as any).KEYCLOAK_URL;
      const keycloakRealm = runtimeConfig.KEYCLOAK_REALM || 
                            env.KEYCLOAK_REALM || 
                            (window as any).KEYCLOAK_REALM;
      const keycloakClientId = runtimeConfig.KEYCLOAK_CLIENT_ID || 
                               env.KEYCLOAK_CLIENT_ID || 
                               (window as any).KEYCLOAK_CLIENT_ID;
      const apiBaseUrl = runtimeConfig.API_BASE_URL || 
                         env.API_BASE_URL || 
                         (window as any).API_BASE_URL;
      const apiAiBaseUrl = runtimeConfig.API_AI_BASE_URL || 
                           env.API_AI_BASE_URL || 
                           (window as any).API_AI_BASE_URL;
      
      if (keycloakUrl && keycloakRealm && keycloakClientId) {
        console.log('Configuration loaded from runtime environment:', {
          keycloakUrl,
          keycloakRealm,
          keycloakClientId,
          apiBaseUrl,
          apiAiBaseUrl
        });
        
        return {
          keycloak: {
            url: keycloakUrl,
            realm: keycloakRealm,
            clientId: keycloakClientId
          },
          api: {
            baseUrl: apiBaseUrl,
            aiBaseUrl: apiAiBaseUrl
          },
          features: {
            debugMode: (runtimeConfig.DEBUG_MODE || env.DEBUG_MODE || (window as any).DEBUG_MODE) === 'true'
          },
          environment: runtimeConfig.ENVIRONMENT || env.ENVIRONMENT || (window as any).ENVIRONMENT || 'production'
        };
      }
    } catch (error) {
      console.warn('Could not load environment variables:', error);
    }
    
    return null;
  }

  private getFallbackConfig(): AppConfig {
    return {
      keycloak: {
                url: 'http://localhost:8080',
        realm: 'agency_01',
        clientId: 'convozoom-frontEnd_client_01'
      },
      api: {
        baseUrl: 'http://localhost:3000/api'
      },
      features: {
        debugMode: false
      },
      environment: 'development'
    };
  }

  getConfig(): Observable<AppConfig> {
    return this.config$;
  }

  getConfigSync(): AppConfig | null {
    return this.config;
  }

  setConfig(config: AppConfig): void {
    this.config = config;
  }

  // Convenience methods for specific config values
  getKeycloakUrl(): Observable<string> {
    return this.config$.pipe(
      map(config => config.keycloak.url)
    );
  }

  getKeycloakRealm(): Observable<string> {
    return this.config$.pipe(
      map(config => config.keycloak.realm)
    );
  }

  getKeycloakClientId(): Observable<string> {
    return this.config$.pipe(
      map(config => config.keycloak.clientId)
    );
  }

  getApiBaseUrl(): Observable<string | undefined> {
    return this.config$.pipe(
      map(config => config.api?.baseUrl)
    );
  }

  getApiAiBaseUrl(): Observable<string | undefined> {
    return this.config$.pipe(
      map(config => config.api?.aiBaseUrl)
    );
  }

  getEnvironment(): Observable<string | undefined> {
    return this.config$.pipe(
      map(config => config.environment)
    );
  }

  isDebugMode(): Observable<boolean> {
    return this.config$.pipe(
      map(config => config.features?.['debugMode'] || false)
    );
  }
}
