package com.railway.collector.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrainStatus {

    private String lastSeen;
    private String pacisStatus;
    private String cctvStatus;
    private String rearViewStatus;
    private String mission;
    private String currentStation;
    private String nextStation;
    private String destination;
    private String baseline;
    private String diversity;
    private String database;
    private String updateStatus;
}
