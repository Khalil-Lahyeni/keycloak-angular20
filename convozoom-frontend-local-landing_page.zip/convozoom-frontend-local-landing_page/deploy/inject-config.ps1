#!/usr/bin/env pwsh

<#
.SYNOPSIS
    Configuration Injection Script for PowerShell
.DESCRIPTION
    This script reads environment variables and injects them into the config-injector.js file
.PARAMETER ConfigFile
    Path to the source config file (default: src/assets/config-injector.js)
.PARAMETER OutputFile
    Path to the output config file (default: dist/convozoom-front/assets/config-injector.js)
.EXAMPLE
    .\inject-config.ps1
.EXAMPLE
    .\inject-config.ps1 -ConfigFile "custom-config.js" -OutputFile "output.js"
#>

param(
    [string]$ConfigFile = "src/assets/config-injector.js",
    [string]$OutputFile = "dist/convozoom-front/assets/config-injector.js"
)

# Set default environment variables if not already set
$envVars = @{
    KEYCLOAK_URL = if ($env:KEYCLOAK_URL) { $env:KEYCLOAK_URL } else { "http://localhost:8080" }
    KEYCLOAK_REALM = if ($env:KEYCLOAK_REALM) { $env:KEYCLOAK_REALM } else { "agency_01" }
    KEYCLOAK_CLIENT_ID = if ($env:KEYCLOAK_CLIENT_ID) { $env:KEYCLOAK_CLIENT_ID } else { "convozoom-frontEnd_client_01" }
    API_BASE_URL = if ($env:API_BASE_URL) { $env:API_BASE_URL } else { "http://localhost:3000/api" }
    ENVIRONMENT = if ($env:ENVIRONMENT) { $env:ENVIRONMENT } else { "production" }
    DEBUG_MODE = if ($env:DEBUG_MODE) { $env:DEBUG_MODE } else { "false" }
}

Write-Host "Configuration Injection Script for PowerShell" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host "Config File: $ConfigFile" -ForegroundColor Yellow
Write-Host "Output File: $OutputFile" -ForegroundColor Yellow
Write-Host ""

Write-Host "Environment Variables:" -ForegroundColor Cyan
foreach ($key in $envVars.Keys) {
    Write-Host "  $key`: $($envVars[$key])" -ForegroundColor White
}
Write-Host ""

# Check if config file exists
if (-not (Test-Path $ConfigFile)) {
    Write-Error "Config file not found: $ConfigFile"
    exit 1
}

# Create output directory
$outputDir = Split-Path $OutputFile -Parent
if (-not (Test-Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
}

try {
    # Read the template file
    $template = Get-Content $ConfigFile -Raw
    
    # Replace placeholders with environment variables
    $injected = $template
    foreach ($key in $envVars.Keys) {
        $placeholder = "{{$key}}"
        $injected = $injected -replace [regex]::Escape($placeholder), $envVars[$key]
    }
    
    # Write the injected configuration
    $injected | Out-File -FilePath $OutputFile -Encoding UTF8
    
    Write-Host "Configuration injected successfully!" -ForegroundColor Green
    Write-Host "Output file: $OutputFile" -ForegroundColor Yellow
    
} catch {
    Write-Error "Error injecting configuration: $($_.Exception.Message)"
    exit 1
}
