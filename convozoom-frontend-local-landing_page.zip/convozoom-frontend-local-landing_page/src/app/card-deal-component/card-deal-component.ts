import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Deal } from '../models/deal.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-card-deal-component',
  imports: [CommonModule, FormsModule],
  standalone: true,
  templateUrl: './card-deal-component.html',
  styleUrl: './card-deal-component.css'
})
export class CardDealComponent {
  @Input() deal!: Deal;
  @Input() color!: string;
  @Output() clicked = new EventEmitter<Deal>();
  showDetails: boolean = false;

  onCardClick() {
    this.clicked.emit(this.deal);
  }

  getBadgeClass(priority: string | undefined): string {
    switch (priority) {
      case 'Urgent': return 'badge-urgent';
      case 'Moderate': return 'badge-moderate';
      case 'Low': return 'badge-low';
      default: return 'badge-default';
    }
  }

  getPriorityIcon(priority?: string): string {
    switch (priority) {
      case 'Urgent':
        return 'assets/lead/Flag.svg';
      case 'Moderate':
        return 'assets/lead/Flag-orange.svg';
      case 'Low':
        return 'assets/lead/Flag-green.svg';
      default:
        return 'assets/lead/Flag.svg';
    }
  }
  toggleDetails(event: Event) {
    event.stopPropagation();
    this.showDetails = !this.showDetails;
  }
}